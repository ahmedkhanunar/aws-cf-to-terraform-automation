import json
import boto3
import os
region_name =  os.environ['region_name']
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime


dynamodb = boto3.resource('dynamodb', region_name=region_name)

benefittable = os.environ['benefittable']
planProgramtable = os.environ['planProgramtable']
# enrolTable = os.environ['enrolTable']
benefittable =  dynamodb.Table(benefittable) 
planProgramtable =  dynamodb.Table(planProgramtable) 
member_mapping_table = dynamodb.Table(os.environ["MiddlewareMemberMappingTable"])
# enrolTable =  dynamodb.Table(enrolTable)

headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Allow": "GET, OPTIONS, POST",
    "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
    "Access-Control-Allow-Headers": "*"
}

def lambda_handler(event, context):
    paramdata = event['queryStringParameters']
    uuid = paramdata.get("UUID", "")
    
    member_search_response = member_mapping_table.query(KeyConditionExpression=Key('uuid').eq(uuid))

    if len(member_search_response.get("Items",[])) == 1:
        department_id = member_search_response.get("Items",[])[0].get("departmentId", "")
    else:
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({'message': 'user not found','errors': 'user not found'}),
        } 
    
    contract_id = paramdata.get('Contractid', '')
    subgroup_id = paramdata.get('SubGroup_ID', '')
    group_id = paramdata.get("GroupID","")
    pbp_id = paramdata.get("PBP","")
    plan_id = paramdata.get("PlanId","")
    metal_level = paramdata.get("MetalLevel","")

    data = fetchBenefit(department_id, contract_id, group_id, subgroup_id, pbp_id, plan_id, metal_level)
    
    newData =[]
    for rec in data:
        procdata = {}
        if 'benefit' in rec:
            procdata['isURL'] = rec.get('isURL', '')
            procdata['benefit'] = rec.get('benefit', '')
            procdata['description'] = rec.get('description', '')
            procdata['program'] = rec.get('program', '')
            procdata['benefit_amt'] = rec.get('benefit_amt', '')
            procdata['sortOrder'] = rec.get('row_id', '')
            planName = rec.get('benefit', '')
            fetchedData = fetchPlan(rec['row_id'])
            newData.append(procdata)
            newData.extend(fetchedData)
        else:
            newData = data
        
        data = json.dumps(newData,cls=DecimalEncoder)


    return {
        'statusCode': "200",
        "headers": headers,
        'body': json.dumps(newData,cls=DecimalEncoder)
        
    }

def fetchPlan(planLookupId):
    plan_data = {}
    retData =[]
    fe = Key('plan_lookup_id').eq(planLookupId) 
    response = planProgramtable.scan(FilterExpression=fe)
    if len(response['Items'])  > 0:
        resdata = response['Items']

        for resp in resdata:
            
            plan_data['isURL'] ='0'
            plan_data['benefit'] = resp['benefit']
            plan_data['description'] = resp['description']
            plan_data['program'] = resp.get('program', "")
            plan_data['benefit_amt'] = resp['benefit_amt']
            plan_data['sortOrder'] = resp['row_id']
            retData.append(plan_data)
            plan_data = {}
    return retData


import os
import json

def generate_benefit_query(department_id, plan_data):
    #path = "nvirginia-prod/5170568595690779/FileStore/tables/Customer/Shared/Inputs/benefits_mapping.json"
    #path = "benefits_mapping.json"

    s3 = boto3.client('s3')
    bucket_name = os.getenv('BENEFIT_CONFIG_BUCKET', "hpdatabricksroot")
    key = os.getenv('BENEFITS_CONFIG_PATH', "benefits_mapping.json")
    #key = path
    s3_object = s3.get_object(Bucket=bucket_name, Key=key)
    json_content = s3_object['Body'].read().decode('utf-8')
    config = json.loads(json_content)

    configs = config.get(department_id, {})
    print(configs)
    sorted_query = []
    
    

    year = datetime.now().year 
    today = datetime.today().strftime('%d-%m-%Y')
    iso_today = datetime.today().strftime('%Y-%m-%d')



    configs_sorted_dict = dict(sorted(configs.items()))

    for config_key, config_value in configs_sorted_dict.items(): 
        fe = Attr('department_id').eq(department_id)
        if year > 2024:
            fe = fe & (Attr('benefit_expiration_date').gte(today) | Attr('benefit_expiration_date').gte(iso_today)) & Attr('benefit_year').eq(f'{year}')
        base_ids = config_value
        sorted_dict = dict(sorted(base_ids.items()))
        for key, value in sorted_dict.items():
            #if the value is in the benefits table, its required to match i.e. if there is a group id on the benefit, the member MUST have the same id
            if value != '' and key != 'customer':
                fe = fe & Attr(key).exists() & Attr(key).eq(plan_data.get(key, ''))
            elif value == '':
                fe = fe & (Attr(key).not_exists() | Attr(key).eq(''))

        sorted_query.append({ 'rank': config_key, 'query': fe})
    return sorted_query


def fetchBenefit(department_id, contract_id, group_id, subgroup_id, pbp, plan_id, metal_level):
    data = []

    plan_data = {
        "contract_id": contract_id,
        "GroupID": group_id,
        "SubGroupID": subgroup_id,
        "Pbp": pbp,
        "plan_id": plan_id,
        "metal_level": metal_level
    }

    queries = generate_benefit_query(department_id, plan_data)

    data = []

    for item in queries:
        response = benefittable.scan(FilterExpression=item.get('query', ''))

        if len(response['Items'])  > 0:
            # print(response['Items'])
            response_data = response['Items']
            while 'LastEvaluatedKey' in response:
                print(response['LastEvaluatedKey'])
                response = benefittable.scan(ExclusiveStartKey=response['LastEvaluatedKey'],FilterExpression=item.get('query', ''))
                response_data.extend(response['Items'])

            print(response_data)
            data = response_data
            break;

    return data

# def fetchBenefit(department_id, contract_id, group_id, subgroup_id, pbp, plan_id, metal_level):
#     data = []

#     if str(department_id) == "1" or str(department_id) == "3":
#         if group_id == '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
#         if group_id != '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id) & Attr('SubGroupID').eq(subgroup_id)

#     if str(department_id).lower() == "aetna" or str(department_id) == "5":
#         if pbp == '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
#         if pbp != '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('Pbp').eq(pbp)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('Pbp').eq(pbp) & Attr('SubGroupID').eq(subgroup_id)

#     if str(department_id) == "4":
#         if group_id == '':
#             if subgroup_id == '':
#                 fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id)
#             if subgroup_id != '':
#                 fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
#         if group_id != '':
#             if subgroup_id == '':
#                 fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id)
#             if subgroup_id != '':
#                 fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id) & Attr('SubGroupID').eq(subgroup_id)

#     if str(department_id) == "6" or str(department_id).lower() == "centene":
#         if plan_id == '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
#         if plan_id != '':
#             if subgroup_id == '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('PlanId').eq(plan_id)
#             if subgroup_id != '':
#                 fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('PlanId').eq(plan_id) & Attr('SubGroupID').eq(subgroup_id)
    
#     year = datetime.now().year 
#     today = datetime.today().strftime('%d-%m-%Y')
#     iso_today = datetime.today().strftime('%Y-%m-%d')

#     if year > 2024:
#         fe = fe & (Attr('benefit_expiration_date').gte(today) | Attr('benefit_expiration_date').gte(iso_today)) & Attr('benefit_year').eq(f'{year}')

#     response = benefittable.scan(FilterExpression=fe)

#     if len(response['Items'])  > 0:
#         # print(response['Items'])
#         response_data = response['Items']
#         while 'LastEvaluatedKey' in response:
#             print(response['LastEvaluatedKey'])
#             response = benefittable.scan(ExclusiveStartKey=response['LastEvaluatedKey'],FilterExpression=fe)
#             response_data.extend(response['Items'])

#         print(response_data)
#         data = response_data
#     else:
#         data = []

#     return data

from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return json.JSONEncoder.default(self, obj)
