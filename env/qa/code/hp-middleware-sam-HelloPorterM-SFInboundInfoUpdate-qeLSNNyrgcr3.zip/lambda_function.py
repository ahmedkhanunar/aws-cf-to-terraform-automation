import json
import boto3
import sys
import traceback
from datetime import datetime
from boto3.dynamodb.conditions import Key
import os

dynamodb = boto3.resource('dynamodb')

headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Allow': 'GET, OPTIONS, POST',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Allow-Headers': '*'
}

def lambda_handler(event, context):
    params = json.loads(event.get("body", {}))

    uuid = str(params.get("uuid", ""))
    street = str(params.get("street", ""))
    state_code = str(params.get("statecode", ""))
    city = str(params.get("city", ""))
    zip_code = str(params.get("zip", ""))
    country = str(params.get("country", ""))
    phone = str(params.get("phone", ""))
    email = str(params.get("email", ""))

    if street or state_code or city or zip_code or country:
        update_address_table(uuid, street, state_code, city, zip_code, country)
    if phone or email:
        update_contact_table(uuid, phone, email)

    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps('Successfully updated')
    }

def update_address_table(uuid, street, state_code, city, zip_code, country):
    address_table = dynamodb.Table(os.environ["MemberAddressTable"])

    try:
        address_table.update_item(
            Key={"uuid": uuid, "type": "UserUpdated"},
            UpdateExpression="set City = :city, Street1 = :street, Country = :country, Zip = :zip, #state = :state",
            ExpressionAttributeNames={
                "#state": "State"
            },
            ExpressionAttributeValues={":city": city, ":street": street, ":country": country, ":zip": zip_code, ":state": state_code },
            ReturnValues="UPDATED_NEW"
        )

        return True

    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps('Cannot update member address')
        }

def find_member_details(uuid):
    details_table = dynamodb.Table(os.environ['MemberDetailsTable'])
    
    try:
        response = details_table.query(KeyConditionExpression=Key('uuid').eq(uuid))

        if len(response["Items"]) == 1:
            return response.get("Items", [])[0].get("MemberLifetimeID", "NC")

        return "NC"
            
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Cannot find member')
        }

def update_contact_table(uuid, phone="", email=""):
    contact_table = dynamodb.Table(os.environ['MemberContactTable'])

    mbi = find_member_details(uuid)

    try:
        contact_table.update_item(
            Key={"uuid": uuid, "MBI": mbi},
            UpdateExpression="set UserUpdatedNumber = :phone, UserUpdatedEmail = :email",
            ExpressionAttributeValues={":phone": phone, ":email": email},
            ReturnValues="UPDATED_NEW"
        )

        return True

    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Cannot update member contact')
        }
    
def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )