
import json

import boto3

import os

dynamodb = boto3.client('dynamodb')

def lambda_handler(event, context):

    print("Received event:", json.dumps(event))

    status_code = 200

    headers = {

        'Content-Type': 'application/json',
        
        'Access-Control-Allow-Origin': '*',

        'Allow': 'GET, OPTIONS, POST',

        'Access-Control-Allow-Methods': '*',

        'Access-Control-Allow-Headers': '*'

    }

    try:

        table_name = os.environ.get('EducationalContentFavouritesTable')

        ultra_commerce_account_id = event.get("queryStringParameters", {}).get("ultraCommerceAccountId")

        if not ultra_commerce_account_id:

            raise ValueError("Missing ultraCommerceAccountId in query parameters.")

        response = dynamodb.query(

            TableName=table_name,

            KeyConditionExpression='ultraCommerceAccountId = :ultraCommerceAccountId',

            ExpressionAttributeValues={

                ':ultraCommerceAccountId': {'S': ultra_commerce_account_id}

            },

            ScanIndexForward=False

        )

        body = response.get('Items', [])

    except Exception as e:

        status_code = 400

        body = {'error': str(e)}

    return {

        'statusCode': status_code,

        'headers': headers,

        'body': json.dumps(body)

    }
 