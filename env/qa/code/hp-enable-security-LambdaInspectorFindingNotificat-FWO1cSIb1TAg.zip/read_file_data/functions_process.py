import json
from codecs import getencoder
import datetime
import dateutil.parser
import uuid
import requests
import http.client
import secrets
import string
dynamo_uuid=''
from io import StringIO
import mimetypes
from codecs import encode
import os
import boto3
from boto3.dynamodb.conditions import Key
from pprint import pprint
from dateutil.parser import parse
createEHRFlag = ''

current_data = datetime.datetime.today().strftime('%Y-%m-%d')

def formatDateSF(date) :
    dt =''
    if str(date) == 'None' or str(date) == '' or str(date) is None:
        date=''
    else:
        date = str(date)
        dt = parse(date)
        dt = dt.strftime('%Y-%m-%d')
    return dt

# def createMemberData(row, key_list, dynamo_uuid):
#     member_data = {}
#     dt = parse(str(row['DateOfBirth']))
#     dt = dt.strftime('%Y-%m-%d')
#     member_data['uuid']=str(dynamo_uuid)
#     if 'MBI' in key_list:
#         member_data['MBI'] = str(row['MBI'])
#     if 'FirstName'in key_list:
#         member_data['FirstName'] = str(row['FirstName'])
#     if 'MiddleName' in key_list:
#         member_data['MiddleName'] = str(row['MiddleName'])
#     if 'LastName'in key_list:
#         member_data['LastName'] = str(row['LastName'])
#     if 'DateOfBirth'in key_list:
#         member_data['DateOfBirth'] = dt
#     if 'EmailAddress'in key_list:
#         member_data['EmailAddress'] = str(row['EmailAddress'])
#     if 'Gender'in key_list:
#         member_data['Gender'] = str(row['Gender'])
#     if 'SubscriberId'in key_list:
#         member_data['SubscriberId'] = str(row['SubscriberId'])
#     if 'ClientID'in key_list:
#         member_data['ClientID'] = str(row['ClientID'])
#     if 'ClientMemberID' in key_list:
#         member_data['ClientMemberID'] = str(row['ClientMemberID'])
#     if 'AltClientMemberID' in key_list:
#         member_data['AltClientMemberID'] = str(row['AltClientMemberID'])
#     if 'ClientProviderID' in key_list:
#         member_data['ClientProviderID'] = str(row['ClientProviderID'])
#     if 'Language'in key_list:
#         member_data['Language'] = str(row['Language'])
#     if 'Race'in key_list:
#         member_data['Race'] = str(row['Race'])
#     if 'HICNumber'in key_list:
#         member_data['HICNumber'] = str(row['HICNumber'])
#     if 'EligibilityGroup'in key_list:
#         member_data['EligibilityGroup'] = str(row['EligibilityGroup'])
#     if 'NetworkProvider'in key_list:
#         member_data['NetworkProvider'] = str(row['NetworkProvider'])
#     if 'PlanID'in key_list:
#         member_data['PlanID'] = str(row['PlanID'])
#     if 'MetalLevel'in key_list:
#         member_data['MetalLevel'] = str(row['MetalLevel'])
#     if 'MarketingPlan'in key_list:
#         member_data['MarketingPlan'] = str(row['MarketingPlan'])
#     if 'MediCaidNumber' in key_list:
#         member_data['MediCaidNumber'] = str(row['MediCaidNumber'])
#     if 'CMSNumber' in key_list:
#         member_data['CMSNumber'] = str(row['CMSNumber'])
#     if 'Custom1' in key_list:
#         member_data['Custom1'] = str(row['Custom1'])
#     if 'Custom2' in key_list:
#         member_data['Custom2'] = str(row['Custom2'])
#     if 'Custom3' in key_list:
#         member_data['Custom3'] = str(row['Custom3'])
#     return member_data

# def createEnrollmentData(row, key_list, dynamo_uuid):
#     enrollment_data = {}
#     enrollment_data['uuid']=str(dynamo_uuid)
#     if 'MBI' in key_list:
#         enrollment_data['MBI'] = str(row['MBI'])
#     if 'PCPStartDate'in key_list:
#         enrollment_data['PCPStartDate'] = str(row['PCPStartDate'])
#     if 'PCPEndDate' in key_list:
#         enrollment_data['PCPEndDate'] = str(row['PCPEndDate'])
#     if 'EligibilityStartDate'in key_list:
#         enrollment_data['EligibilityStartDate'] = str(row['EligibilityStartDate'])
#     if 'EligibilityEndDate'in key_list:
#         enrollment_data['EligibilityEndDate'] =  str(row['EligibilityEndDate'])
#     if 'TerminationReason'in key_list:
#         enrollment_data['TerminationReason'] = str(row['TerminationReason'])
#     if 'EligibilityGroup'in key_list:
#         enrollment_data['EligibilityGroup'] = str(row['EligibilityGroup'])
#     if 'NetworkProvider'in key_list:
#         enrollment_data['NetworkProvider'] = str(row['NetworkProvider'])
#     if 'PlanID'in key_list:
#         enrollment_data['PlanID'] = str(row['PlanID'])
#     if 'OtherPlanID' in key_list:
#         enrollment_data['OtherPlanID'] = str(row['OtherPlanID'])
#     if 'MetalLevel' in key_list:
#         enrollment_data['MetalLevel'] = str(row['MetalLevel'])
#     if 'Target' in key_list:
#         enrollment_data['Target'] = str(row['Target'])
#     if 'Language'in key_list:
#         enrollment_data['Language'] = str(row['Language'])
#     if 'Race'in key_list:
#         enrollment_data['Race'] = str(row['Race'])
#     if 'HICNumber'in key_list:
#         enrollment_data['HICNumber'] = str(row['HICNumber'])
#     if 'EligibilityGroup'in key_list:
#         enrollment_data['EligibilityGroup'] = str(row['EligibilityGroup'])
#     if 'NetworkProvider'in key_list:
#         enrollment_data['NetworkProvider'] = str(row['NetworkProvider'])
#     if 'PlanID'in key_list:
#         enrollment_data['PlanID'] = str(row['PlanID'])
#     if 'MetalLevel'in key_list:
#         enrollment_data['MetalLevel'] = str(row['MetalLevel'])
#     if 'PreferredPlanName'in key_list:
#         enrollment_data['PreferredPlanName'] = str(row['PreferredPlanName'])
#     if 'PBPNumber' in key_list:
#         enrollment_data['PBPNumber'] = str(row['PBPNumber'])

#     return enrollment_data



def createMemberData(row, key_list, dynamo_uuid):
    if str(row['DateOfBirth']) != "":
        dt = parse(str(row['DateOfBirth']))
        dt = dt.strftime('%Y-%m-%d')
    member_data = {}
    member_data['uuid']=str(dynamo_uuid)
    if 'MemberLifeID' in key_list:
        member_data['MemberLifetimeID'] = str(row['MemberLifeID'])
    if 'FirstName'in key_list:
        member_data['FirstName'] = str(row['FirstName'])
    if 'MiddleName' in key_list:
        member_data['MiddleName'] = str(row['MiddleName'])
    if 'LastName'in key_list:
        member_data['LastName'] = str(row['LastName'])
    if 'DateOfBirth'in key_list:
        member_data['DateOfBirth'] = str(dt)
    if 'Gender'in key_list:
        member_data['Gender'] = str(row['Gender'])
    if 'Language'in key_list:
        member_data['Language'] = str(row['Language'])
    if 'Race'in key_list:
        member_data['Race'] = str(row['Race'])
    member_data['DateImported'] = str(current_data)
    return member_data



def createEnrollmentData(row, key_list, dynamo_uuid ):
    enrollment_data = {}
    enrollment_data['uuid']=str(dynamo_uuid)
    if 'MBI' in key_list:
        enrollment_data['MBI'] = str(row['MBI'])
    if 'MemberLifeID' in key_list:
        enrollment_data['MemberLifetimeID'] = str(row['MemberLifeID'])
    if 'ClientMemberID' in key_list:
        enrollment_data['MemberID'] = str(row['ClientMemberID'])
    if 'AltClientMemberID' in key_list:
        enrollment_data['AltMemberID'] = str(row['AltClientMemberID'])
    if 'MedicaidNumber' in key_list:
        enrollment_data['MediCaidNumber'] = str(row['MedicaidNumber'])
    if 'SubscriberId'in key_list:
        enrollment_data['SubscriberId'] = str(row['SubscriberId'])
    if 'PBPNumber' in key_list:
        enrollment_data['PBP'] = str(row['PBPNumber'])
    if 'MetalLevel' in key_list:
        enrollment_data['MetalLevel'] = str(row['MetalLevel'])
    if 'CMSNumber' in key_list:
        enrollment_data['ContractID'] = str(row['CMSNumber'])
    if 'GroupID' in key_list:
        enrollment_data['GroupID'] = str(row['GroupID'])
    if 'GroupName' in key_list:
        enrollment_data['GroupName'] = str(row['GroupName'])
    if 'SubGroupID' in key_list:
        enrollment_data['PlanID'] = str(row['SubGroupID'])
    if 'PCPStartDate' in key_list:
        enrollment_data['PCPStartDate'] = formatDateSF(str(row['PCPStartDate']))
    if 'PCPEndDate' in key_list:
        enrollment_data['PCPEndDate'] = formatDateSF(str(row['PCPEndDate']))
    if 'EligibilityStartDate' in key_list:
        enrollment_data['EligibilityStartDate'] = formatDateSF(str(row['EligibilityStartDate']))
    if 'EligibilityEndDate' in key_list:
        enrollment_data['EligibilityEndDate'] = formatDateSF(str(row['EligibilityEndDate']))
    if 'EligibilityGroup' in key_list:
        enrollment_data['EligibilityGroup'] = str(row['EligibilityGroup'])
    if 'PreferredPlanName' in key_list:
        enrollment_data['PreferredPlanName'] = str(row['PreferredPlanName'])
    #if 'PlanID'in key_list:
    #    enrollment_data['PlanID'] = str(row['PlanID'])
    if 'OtherPlanID' in key_list:
        enrollment_data['OtherPlanID'] = str(row['OtherPlanID'])
    if 'ClientProviderID' in key_list:
        enrollment_data['ClientProviderID'] = str(row['ClientProviderID'])
    enrollment_data['DateImported'] = str(current_data)    
    
    return enrollment_data


def createHomeAddData(row, key_list, dynamo_uuid):
    address_data = {}
    address_data['uuid']=str(dynamo_uuid)
    if 'MBI' in key_list:
        address_data['MBI'] = str(row['MBI'])
    if 'HomeStreet1'in key_list:
        address_data['Street1'] = str(row['HomeStreet1'])
    if 'HomeStreet2' in key_list:
        address_data['Street2'] = str(row['HomeStreet2'])
    if 'HomeCity'in key_list:
        address_data['City'] = str(row['HomeCity'])
    if 'HomeCounty'in key_list:
        address_data['County'] = str(row['HomeCounty'])
    if 'HomeState'in key_list:
        address_data['State'] = str(row['HomeState'])
    if 'HomeZip'in key_list:
        address_data['Zip'] = str(row['HomeZip'])
    address_data['type'] = str('HomeAddress')
    return address_data

def createMailingAddData(row, key_list, dynamo_uuid):
    address_data2 = {}
    address_data2['uuid']=str(dynamo_uuid)
    if 'MBI' in key_list:
        address_data2['MBI'] = str(row['MBI'])
    if 'MailingStreet1'in key_list:
        address_data2['Street1'] = str(row['MailingStreet1'])
    if 'MailingStreet2' in key_list:
        address_data2['Street2'] = str(row['MailingStreet2'])
    if 'MailingCity'in key_list:
        address_data2['City'] = str(row['MailingCity'])
    if 'MailingCounty'in key_list:
        address_data2['County'] = str(row['MailingCounty'])
    if 'MailingState'in key_list:
        address_data2['State'] = str(row['MailingState'])
    if 'MailingZip'in key_list:
        address_data2['Zip'] = str(row['MailingZip'])
    address_data2['type'] = 'MailingAddress'
    return address_data2

def createContactData(row, key_list, dynamo_uuid):
    contact_data = {}
    contact_data['uuid']= str(dynamo_uuid)
    if 'MBI' in key_list:
        contact_data['MBI'] = str(row['MBI'])
    if 'TelephoneNumber1'in key_list:
        contact_data['PrimaryNumber'] = str(row['TelephoneNumber1'])
    if 'TelephoneNumber2' in key_list:
        contact_data['TelephoneNumber2'] = str(row['TelephoneNumber2'])
    if 'TelephoneNumber3'in key_list:
        contact_data['TelephoneNumber3'] = str(row['TelephoneNumber3'])
    if 'EmailAddress'in key_list:
        contact_data['EmailAddress'] = str(row['EmailAddress'])
    return contact_data






