import boto3
import os
import json

from cerberus import Validator
import uuid

dynamo = boto3.resource('dynamodb')
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }
schema = { 'questions': { 'type': 'list',"minlength": 1,"maxlength": 10, 'required': True, 'schema': { 'type': 'dict', 'schema': { 'question': {'type': 'string', 'required': True} } } } }




def lambda_handler(event, context):
       
    try:
        bodyData = json.loads(event.get('body')) if event.get('body') != None else {}
            
        validator = Validator(schema,allow_unknown=True)
       

        if not validator.validate(bodyData):
            return failure_response(400,'invalid body',validator.errors)
        questions = bodyData["questions"]
        questionItems = []
        for question in questions:
            questionItems.append({'uuid':str(uuid.uuid4()),'Question':question['question'],'Type':'SECURITY'})

        table = dynamo.Table(os.environ['SecurityQuestionMasterTable'])
        with table.batch_writer() as writer:
            for item in questionItems:
                writer.put_item(Item=item)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Security questions added sucessfully.'}),
            'headers': headers
        }
    except Exception as err:
        return failure_response(error=str(err))
   
def failure_response(statuCode = 400,message='Error while adding security questions.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    }