#!/bin/bash
#
# This script create required S3 bucket and deploy the cloud formation stack to create
# necessory Lambda and Step functions
#
# This script should be run from the repo's deployment directory
# cd deployment
# ./deploy-solution.sh environment aws_cli_profile
#
# Paramenters:
#  - environment: Environment name, possible values are dev, qa and prod
#  - aws_cli_profile: AWS CLI Profile as configured on you local machine
# AKIAYDHUEEJVWWQNJMWV / b3zfastel0M4ZeWWyWfX6yqjWR5Vve4em0iAp7H0

if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Please provide environment and AWS CLI Profile"
    echo "For example: ./deploy-solution.sh prd hp_prd"
    exit 1
fi

# Setup Environment
source .env.$1

# Create S3 Buckets
aws s3 mb s3://$DIST_OUTPUT_BUCKET-$REGION --region $REGION --profile $2
aws s3 mb s3://$DIST_OUTPUT_BUCKET-$SECONDARY_REGION --region $SECONDARY_REGION --profile $2

# Build source code and deploy it on S3
./build-s3-dist.sh $DIST_OUTPUT_BUCKET $SOLUTION_NAME $VERSION

aws s3 cp ./regional-s3-assets/ s3://$DIST_OUTPUT_BUCKET-$REGION/$SOLUTION_NAME/$VERSION/ --recursive --acl bucket-owner-full-control --profile $2
aws s3 cp ./regional-s3-assets/ s3://$DIST_OUTPUT_BUCKET-$SECONDARY_REGION/$SOLUTION_NAME/$VERSION/ --recursive --acl bucket-owner-full-control --profile $2

# Deploy the CloudFormation Stack
echo "    "
echo "*****************************************************************"
echo "Execute below command to deploy the Cognito Export/Import Utility"
echo "*****************************************************************"
echo "    "
echo aws cloudformation deploy --template-file global-s3-assets/cognito-user-profiles-export-reference-architecture.template \
                            --stack-name porter-cognito-export-import \
                            --profile $2 \
                            --capabilities CAPABILITY_IAM CAPABILITY_AUTO_EXPAND CAPABILITY_NAMED_IAM \
                            --parameter-overrides PrimaryUserPoolId=$PRIMARY_USER_POOLID SecondaryRegion=$SECONDARY_REGION NotificationEmail=$NOTIFICATION_EMAIL
echo "    "
echo "    "