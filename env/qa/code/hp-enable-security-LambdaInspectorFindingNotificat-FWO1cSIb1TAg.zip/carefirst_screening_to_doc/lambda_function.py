import boto3
import datetime
today = datetime.date.today()
import json
import docx
import shutil
from docx import Document
from boto3.dynamodb.conditions import Key, Attr
import sys
import datetime
import os
import io
import traceback
from datetime import datetime
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
# import ast
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs
import random
import pandas as pd

null = None

region_name = 'us-east-1'
customer = "Carefirst"
template_file = "cf_hra_template_20240111_updated.docx"
# year_month_day = "20240502"
year_month_day = today.strftime('%Y%m%d')
template_ins = "HRSCF002"
# date_fetch = dbutils.widgets.get("startDate")
# date_end = dbutils.widgets.get("endDate")
department_id = "1"
lambda_client = boto3.client('lambda')

def processCFPdf(cf2024_mapping, templateMapped, completion_date, memberName, memberId, hContract, mbi):
    # s3_path = os.getenv("s3path", "/nvirginia-prod/7413904104309051/FileStore/tables")
    # -------------
    
    s3 = boto3.resource("s3")
    # bucket = s3.Bucket("databricks-workspace-stack-newdev-bucket")
    bucket = s3.Bucket(os.environ['BucketName'])

    object_in_s3 = bucket.Object(f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{customer}/Inputs/templates/{template_file}")
    object_as_streaming_body = object_in_s3.get()["Body"]
    print(f"Type of object_as_streaming_body: {type(object_as_streaming_body)}")
    object_as_bytes = object_as_streaming_body.read()
    print(f"Type of object_as_bytes: {type(object_as_bytes)}")

    # Now we use BytesIO to create a file-like object from our byte-stream
    object_as_file_like = io.BytesIO(object_as_bytes)
    
    # ------------
    # document2 = Document(f"{s3_path}/Customer/{customer}/Inputs/templates/{template_file}")
    document2 = Document(docx=object_as_file_like)
    style = document2.styles['Normal']
    fullText = []
    i = 0
    for para in document2.paragraphs: 
        i+=1
        inline = para.runs
        for run in inline:
           # print(run.text)
            for data in templateMapped:
                if run.text == 'Date: ':
                    run.text = run.text + '\t\t'  +  completion_date # #datetime.strptime(completion_date, "%Y-%m-%d")
                if run.text.strip() == 'Member Name:':
                    run.text = run.text + '\t\t'  + memberName
                if run.text.strip() == 'Member ID:':
                    run.text = run.text + '\t\t'  + memberId
                if run.text == data['question'] and data['type'] == 'Select Single'  : #and data['answer'] is not None
                    run.text = run.text + '\t'  
                    q = para.add_run(data['answer'])
                    q.bold = False
                    q.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text.strip() == data['question'] and data['type'] == 'Yes/No' and  data['answer'] is not None :
                    #print(data['answer'])
                    run.text = run.text   + '\t'
                    r = para.add_run(yn_match(data['answer']))
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text == data['question'] and data['type'] == 'ytd' and  data['answer'] is not None:
                    run.text = run.text   + '\t\t\t\t'
                    k = para.add_run(yes_match(data['answer']))
                    k.bold = False
                    k.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text == data['question'] and data['type'] == 'trouble' and  data['answer'] is not None:
                    run.text = run.text   + '\t\t\t\t'
                    z = para.add_run(trouble_match(data['answer']))
                    z.bold = False
                    z.alignment=WD_ALIGN_PARAGRAPH.LEFT

    batch_date = today.strftime('%Y%m%d%H%M%S')

    filename = f"{customer}_HRA_{mbi}_{hContract}_{batch_date}.docx"
    
    file_path_part = f"{customer}/Outputs/{year_month_day}/docx/{filename}"


    # path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}" PROD
    path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}"
    #print(path) 
    s3 = boto3.client('s3', region_name='us-east-1')
    i = 0

    document2.save(f"/tmp/{filename}")
    try:
        s3.upload_file(f"/tmp/{filename}", os.environ['BucketName'], path)
        return {
            'statusCode': 200,
            'body': 'success',
            'path': path
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('cannot complete request')
        }
   

####
def yes_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes'
    else:
        text_value = '☐  Yes'
    return text_value

def trouble_match(data):
    if data.lower() == 'No trouble' or data.lower() == 'no trouble':
        text_value = '☒  No trouble'
    else:
        text_value = '☐  No trouble'
    return text_value

def yn_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No'
    else:
        text_value = '☐  Yes   ☐  No'
    return text_value
def ynd_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No   ☐  Don’t know'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No   ☐  Don’t know'
    elif  'know' in data.lower() :
        text_value = '☐  Yes   ☐  No   ☒  Don’t know'
    else:
        text_value = '☐  Yes   ☐  No   ☐  Don’t know'
    return text_value
    
def get_templateMapped():
    ##'answer': 'HTN, High cholesterol, Thyroid problems',
    templateMapped = [{'question': 'What is your preferred language for health communications?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.301'},
 {'question': 'Please specify if Other:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': ''},
 {'question': 'How would you rate your overall health?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.71'},
 {'question': 'Do you have a Primary Care Physician (PCP) that you see?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.302'},
 {'question': 'If yes, please provide PCP Name:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.303'},
 {'question': 'PCP Location:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.304'},
 {'question': 'When was your last visit?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.305'},
 {'question': 'Have you fallen in the last 12 months?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.127'},
 {'question': 'If so, how many times and where?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.306'},
 {'question': 'Indicate injury:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.307'},
 {'question': 'Do you use any of the following to get around?',
  'answer': '',
  'type': 'Select Multiple',
  'ehrKey': ''},
 {'question': 'Do you have any planned surgery?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.313'},
 {'question': 'If so, when?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.314'},
 {'question': 'Have you had any recent visits to the Emergency Department?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.315'},
 {'question': 'If so, why?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.316'},
 {'question': 'In the past 12 months, have you stayed overnight as a patient in the hospital for 2 or more nights?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.317'},
 {'question': 'If ‘Yes’, about how many times?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.318'},
 {'question': 'What health conditions do you currently have?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.78'},
 {'question': 'Do you have any questions regarding your medications?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.319'},
 {'question': 'If ‘Yes’, have you talked to your provider?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.320'},
 {'question': 'Would you like to speak to a nurse about your medications?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.321'},
 {'question': 'Do you have any trouble completing the following activities?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': ''},
 {'question': 'Bathing',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.322'},
 {'question': 'Getting dressed',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.323'},
 {'question': 'Standing up from a sitting position',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.324'},
 {'question': 'Getting to and from the toilet',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.325'},
 {'question': 'Getting groceries/food?',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.326'},
 {'question': 'Preparing meals',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.327'},
 {'question': 'Eating',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.328'},
 {'question': 'Using the telephone to get help',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.329'},
 {'question': 'Taking your medications independently',
  'answer': 'None',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.330'},
 {'question': 'What is your smoking status?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.331'},
 {'question': 'How many packs per day do you (or did you) smoke?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.332'},
 {'question': 'For How many years have you (or did you) smoked?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.333'},
 {'question': 'If you drink alcohol, how much do you drink?',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.334'},
 {'question': 'Are you using any street drugs?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.335'},
 {'question': 'If yes, please indicate what you are taking:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.336'},
 {'question': 'In the past four weeks, have you had any pain?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.337'},
 {'question': 'If ‘Yes’ rate 0-10 and where:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': 'LOCAL.338'},
 {'question': 'Are you feeling anxious, depressed, angry, lonely, or socially isolated?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.339'},
 {'question': 'If yes, are you seeing a mental health provider?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.117'},
 {'question': 'Do you need assistance connecting with a mental health provider?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.341'},
 {'question': 'Are you experiencing any issues related to:',
  'answer': '',
  'type': 'Select Single',
  'ehrKey': ''},
 {'question': 'Access to Food?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.342'},
 {'question': 'Access to Housing?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.343'},
 {'question': 'Access to Transportation?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.344'},
 {'question': 'Trouble paying your bills?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.345'},
 {'question': 'Would you like to speak with a Case Manager?',
  'answer': '',
  'type': 'Yes/No',
  'ehrKey': 'LOCAL.346'},
 {'question': 'Cane',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''},
 {'question': 'Walker',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''},
 {'question': 'Wheelchair',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''},
 {'question': 'Prosthetic Device',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''},
 {'question': 'Electric Wheelchair (Scooter)',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''},
 {'question': 'NONE',
  'answer': 'No',
  'type': 'ytd',
  'ehrKey': ''}]
    return templateMapped

def break_multiple(cf2024_mapping):
    for que in cf2024_mapping:
        ans_element = []
        que_list = []

        if que['question'] =='Do you use any of the following to get around?':
            answer = que['answer']
            if '\n' not in  answer:
                que = str(answer)
                ansdata = {}
                ansdata['question'] = que
                ansdata['answer'] = 'Yes'
                ansdata['type'] = 'ytd'
                que_list.append(ansdata)
            elif '\n' in  answer: 
                ans_element = answer.split('\n')
                for ans in ans_element:
                    ansdata = {}
                    ansdata['question'] = ans
                    ansdata['answer'] = 'Yes'
                    ansdata['type'] = 'ytd'
                    que_list.append(ansdata)
            #print(que_list)
            return que_list

def parent_map(que):
    que_child = 1
    jsondata = {}
    jsondata['questionText'] = que['questionText']
    jsondata['questionId'] = que['questionId']
    jsondata['externalquestionId'] = que['externalquestionId']  if 'externalquestionId' in que.keys() else ''
    jsondata['ehrKey'] = que['ehrKey']
    jsondata['answerType'] = que['answerType']
    jsondata['answerDetails'] = que['answerDetails']
    jsondata['answer'] = que['answer']
    jsondata['Finalanswer'] = que['answer'] if que['answer']  is not None else que['answerDetails']

    return jsondata

def generate_docx(raw_data):
    skipped = []
    mbilist = []
    skip = 0
    for data_pro in raw_data:
        print('----------------------')
        # questions = sqsData[0]['screenings'][0]['questions']
        screenings = data_pro['screenings']
        if screenings[0]["templateId"] != template_ins:
            print(screenings[0]["templateId"], "skipping")
            skipped.append(screenings[0]['templateId'])
            skip = 1
            continue

        memberName = data_pro['memberName']
        
        memberId = data_pro['memberId'] if ('memberId' in data_pro.keys() and data_pro['memberId'] is not None) else data_pro['memberLifetimeID']
        
        hContract = data_pro['hContract']  if 'hContract' in data_pro.keys() else ''
        mbi = data_pro['mbi']  if 'mbi' in data_pro.keys() else ''
        mbilist.append(mbi)
        questions = screenings[0]['questions']
        completion_date = screenings[0]['completionDate']
        completion_date = completion_date.split("T")[0]
        final_data = []
        for que in questions:
            dt = parent_map(que)
            final_data.append(dt)
            if que['children'] != None:
                que2 = que['children']
                for que1 in que2:
                    dt = parent_map(que1)
                    final_data.append(dt)
                    if que1['children'] != None:
                        que3 = que1['children']
                        for que4 in que3:
                            dt = parent_map(que4)
                            final_data.append(dt)
            templateMapped = get_templateMapped()
            df = pd.DataFrame(final_data)

    cf2024_mapping = []
    if skip == 0:
        for index, row in df.iterrows():
            data ={}
            data['question'] = row['questionText']
            data['answer'] = row['Finalanswer']
            data['type'] = row['answerType']
            data['ehrKey'] = row['ehrKey']
            cf2024_mapping.append(data)
            if row['questionText'] == 'Please specify if Other:':
                other_language = row['Finalanswer']

        # display(cf2024_mapping)
        for ft in templateMapped:
            for cf in cf2024_mapping:
                # print('1')
                if ft['question'] == cf['question']:
                    ft['answer'] = str(cf['answer'])
        
        # display(templateMapped)
        for ft2 in templateMapped:
            if ft2['question'] == 'What is your preferred language for health communications?' and str(ft2['answer']) == 'Other':
                    ft2['answer'] = other_language 

        multi_data = break_multiple(cf2024_mapping)
        if cf['question'] == 'What is your preferred language for health communications?' and str(cf['answer']) == 'Other':
                    ft['answer'] = other_language 
        print(multi_data)
        for multi in multi_data:
            for ft in templateMapped:
                if ft['question'] == multi['question']:
                    ft['answer'] = str(multi['answer'])
        for q_data in templateMapped:
                if q_data['question'] == "For how many years have you (or did you) smoked?":
                    q_data['question'] = "For How many years have you (or did you) smoked?"
                if q_data['question'] == "If so, why?":
                    q_data['question'] = "If so, whpry"
                if q_data['question'] == "Indicate injury:":
                    q_data['question'] = "Indicate injury:"
        return processCFPdf(cf2024_mapping, templateMapped, completion_date, memberName, memberId, hContract, mbi)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('cannot complete request')
        }

def lambda_handler(event, context):
    try:
        print('inside docx')
        print(event)

        response = generate_docx(event.get("data", ""))
        
        if response.get("statusCode", "") == 200:
            lambda_client.invoke(FunctionName = os.environ['LambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"path": response.get('path', ""), "patient_id": event.get("patient_id", ""), "department_id": event.get("department_id", "")}))
        else:
            return response
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        print("ex: ", ex)
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot generate mhc to docx')
        }
