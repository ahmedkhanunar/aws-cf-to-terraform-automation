const https = require('https');
const zlib = require('zlib');
const jwt = require('jsonwebtoken');

const sf_private_key = process.env.SF_PRIVATE_KEY !== undefined ? process.env.SF_PRIVATE_KEY.replace(/\\n/g, '\n') : "";
const sf_issuer = process.env.SF_ISSUER;
const sf_subject = process.env.SF_SUBJECT;
const sf_token_url = process.env.SF_HOST + "/services/oauth2/token";

function generateSalesforceJWT () {
    const header = {algorithm: "RS256"};
    const claimSet = {
        iss: sf_issuer,
        aud: sf_token_url,
        sub: sf_subject,
        exp: Math.floor(Date.now() / 1000) + (3 * 60)
    }

    const token = jwt.sign(claimSet, sf_private_key, header);
    //console.log (token);
    return token;
}

async function getSalesforceToken () {
    const jwtToken = generateSalesforceJWT();
    const headers = {
        'Accept-Encoding': 'gzip',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    const params = {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": jwtToken
    };
    const response = await postRequest (sf_token_url, params, headers, false);

    //console.log ("getSalesforceToken******");
    //console.log (response);

    return response;
}

function getRequest(url, params, headers, isJson = true) {
    return doRequest (url, 'GET', params, headers, isJson);
}

function postRequest(url, params, headers, isJson = true) {
    return doRequest (url, 'POST', params, headers, isJson);
}

function putRequest(url, params, headers, isJson = true) {
    console.log (headers);
    return doRequest (url, 'PUT', params, headers, isJson);
}

function doRequest (url, method, params, headers, isJson = true) {
    if (isJson) {
        if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
    }
    const options = {
        method: method,
        headers: headers,
    };
    console.log ("URL: ", url);
    console.log ("Headers: ", JSON.stringify(options));

    return new Promise((resolve, reject) => {
        var req = https.request(url, options, (res) => {
            console.log('statusCode:', res.statusCode);
            //console.log('headers:', res.headers);
            
            let chunks = [];

            if (res.headers['content-encoding'] === 'gzip') {
                const gunzip = zlib.createGunzip();
                res.pipe(gunzip);    

                gunzip.on('data', function(data) {
                    chunks.push(data.toString())
                }).on("end", function() {
                    let body = chunks.join("");
                    //console.log(body.toString());

                    try {
                        resolve(JSON.parse(body.toString()));
                    } catch (err) {
                        console.error(err);
                        reject(new Error(err));
                    }

                }).on("error", function(e) {
                    console.error(e);
                })
            }
            else {
                res.on("data", function (chunk) {
                    chunks.push(chunk);
                }).on('end', () => {
                    let body = chunks.join("");
                    //console.log("===="+body.toString());

                    try {
                        resolve(JSON.parse(body.toString()));
                    } catch (err) {
                        console.error(err);
                        reject(new Error(err));
                    }
                });
            }
        });
        
        req.on('error', (e) => {
            console.log(e);
            reject(new Error(e));
        });
        
        if (params !== null) {
            console.log ("Parameters JSON? ", isJson);
            console.log ("Parameters: ", JSON.stringify(params));
            if (isJson) {
                req.write(JSON.stringify(params));
            }
            else {
                const paramNames = Object.keys(params);
                let paramArray = [];
                paramNames.forEach((key, index) => {
                    paramArray.push (key + "=" + encodeURI(params[key]));
                });
                req.write(paramArray.join("&"));
            }
        }
        req.end();
    });
}

function getSalesforceGender (gender) {
    if (gender && gender.toLowerCase() === 'male')
        return 'M';
    else if (gender && gender.toLowerCase() === 'female')
        return 'F';

    return 'Other';
}

module.exports = { getSalesforceToken, getRequest, postRequest, putRequest, getSalesforceGender };