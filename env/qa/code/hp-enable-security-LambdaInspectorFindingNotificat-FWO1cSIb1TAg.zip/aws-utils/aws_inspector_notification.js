var AWS = require('aws-sdk');

exports.handler = function(event, context) {
  try {
    // Extract Inspector finding from the SNS event
    const snsMessage = event.Records[0].Sns.Message;
    const inspectorFinding = JSON.parse(snsMessage);
    //let inspectorFinding = event;
    let colPad = 50;

    // Process Inspector finding
    console.log('Received Inspector finding:');
    //console.log(inspectorFinding);
    
    let emailSubject = "AWS Inspector: " + inspectorFinding.detail.title;
    let emailBody = inspectorFinding.detail.title
    emailBody += "\n============================================\n";
    emailBody += "\nFinding ARN: " + inspectorFinding.detail.findingArn;
    emailBody += "\n\n" + inspectorFinding.detail.description + "\n\n";
    
    emailBody += "Finding Overview";
    emailBody += "\n============================================";
    emailBody += "\nSeverity:".padEnd(colPad) + inspectorFinding.detail.severity;
    emailBody += "\nType".padEnd(colPad) + inspectorFinding.detail.type;
    emailBody += "\nFix Available".padEnd(colPad) + inspectorFinding.detail.fixAvailable;
    emailBody += "\nExploit Available".padEnd(colPad) + inspectorFinding.detail.exploitAvailable;
    if (inspectorFinding.detail.exploitabilityDetails) {
      emailBody += "\nLast known public exploit at".padEnd(colPad) + inspectorFinding.detail.exploitabilityDetails.lastKnownExploitAt;
    }
    emailBody += "\nCreated at".padEnd(colPad) + inspectorFinding.detail.firstObservedAt;

    emailBody += "\n\nAffected Packages";
    emailBody += "\n============================================";
    inspectorFinding.detail.packageVulnerabilityDetails.vulnerablePackages.forEach(function(value){
      emailBody += "\n**Name".padEnd(colPad) + value.name;
      emailBody += "\nInstalled Version".padEnd(colPad) + value.version;
      emailBody += "\nFixed Version".padEnd(colPad) + value.fixedInVersion;
      emailBody += "\nPackage Manager".padEnd(colPad) + value.packageManager;
      emailBody += "\nRemediation".padEnd(colPad) + value.remediation;
      if (value.filePath) {
        emailBody += "\nFile Path".padEnd(colPad) + value.filePath;
      }
      emailBody += "\n";
    });

    emailBody += "\n\nResource Affected";
    emailBody += "\n============================================";
    inspectorFinding.detail.resources.forEach(function(value) {
      emailBody += "\nType".padEnd(colPad) + value.type;
      emailBody += "\nID".padEnd(colPad) + value.id;
    });

    console.log("Subject: " + emailSubject);
    console.log("Body: " + emailBody);

    var sns = new AWS.SNS();
    sns.publish({
      Message: emailBody,
      Subject: emailSubject,
      TopicArn: process.env.TOPIC_ARN
    }, function(err, data) {
      if (err) {
          console.log(err.stack);

          // Notify Lambda that we are finished, but with errors
          context.done(err, 'Error publishing message to SNS!');  
          return;
      }
      console.log('push sent');
      console.log(data);

      // Notify Lambda that we are finished
      context.done(null, 'Message successfully published to SNS');  
    });

  } catch (error) {
    var sns = new AWS.SNS();
    sns.publish({
      Message: JSON.stringify(event, null, 4),
      Subject: "AWS Inspector Finding",
      TopicArn: process.env.TOPIC_ARN
    }, function(err, data) {
      if (err) {
          console.log(err.stack);

          // Notify Lambda that we are finished, but with errors
          context.done(err, 'Error publishing message to SNS!');  
          return;
      }
      console.log('push sent');
      console.log(data);

      // Notify Lambda that we are finished
      context.done(null, 'Message successfully published to SNS');  
    });
    
    console.error('Error:', error);
    //throw new Error('An error occurred');
  }
};