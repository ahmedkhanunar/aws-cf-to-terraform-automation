var AWS = require('aws-sdk');

exports.handler = async (event, context, callback) => {
  try {
    // Extract Inspector finding from the SNS event
    const snsMessage = event.Records[0].Sns.Message;
    const securityHubFinding = JSON.parse(snsMessage);
    
    let colPad = 30;
    
    // Process Security Hub finding
    console.log('Received SecurityHub finding:', securityHubFinding);
    //console.log(inspectorFinding);
    
    let emailSubject = "SecurityHub " + securityHubFinding.detail.findings[0].Severity.Label + " - " + securityHubFinding.detail.findings[0].Title;
    let emailBody = securityHubFinding.detail.findings[0].Title;
    emailBody += "\n\nFinding Overview";
    emailBody += "\n============================================";
    emailBody += "\nSeverity:".padEnd(colPad) + securityHubFinding.detail.findings[0].Severity.Label;
    emailBody += "\nControl:".padEnd(colPad) + securityHubFinding.detail.findings[0].ProductFields.ControlId;
    emailBody += "\nFinding:".padEnd(colPad) + securityHubFinding.detail.findings[0].ProductFields['aws/securityhub/annotation'] || '';
    emailBody += "\nRegion:".padEnd(colPad) + securityHubFinding.detail.findings[0].Region;
    emailBody += "\nFound On:".padEnd(colPad) + securityHubFinding.detail.findings[0].CreatedAt;
    emailBody += "\nLast Observed On:".padEnd(colPad) + securityHubFinding.detail.findings[0].LastObservedAt;
    emailBody += "\nResource Type:".padEnd(colPad) + securityHubFinding.detail.findings[0].Resources[0].Type;
    emailBody += "\nAffected Resource:".padEnd(colPad) + securityHubFinding.detail.findings[0].Resources[0].Id;
    emailBody += "\nAssociated Standards:".padEnd(colPad);
    securityHubFinding.detail.findings[0].Compliance.AssociatedStandards.array.forEach(element => {
      emailBody += "".padEnd(colPad) + element.StandardsId + "\n";
    });
    emailBody += "\nDetailed Link:".padEnd(colPad) + "<a href=\"https://us-east-1.console.aws.amazon.com/securityhub/home?region=us-east-1#" + securityHubFinding.detail.findings[0].GeneratorId + "\">https://us-east-1.console.aws.amazon.com/securityhub/home?region=us-east-1#" + securityHubFinding.detail.findings[0].GeneratorId + "</a>";
      
    console.log("Subject: " + emailSubject);
    console.log("Body: " + emailBody);
  
    var sns = new AWS.SNS();
    await sns.publish({
      Message: emailBody,
      Subject: emailSubject.substring(0, 99),
      TopicArn: process.env.TOPIC_ARN
    }, await function(err, data) {
      if (err) {
          console.log(err.stack);
  
          // Notify Lambda that we are finished, but with errors
          context.done(err, 'Error publishing message to SNS!');  
          return;
      }
      console.log('push sent');
      console.log(data);
  
      // Notify Lambda that we are finished
      context.done(null, 'Message successfully published to SNS');  
    }).promise();
  } catch (error) {
    var sns = new AWS.SNS();
    await sns.publish({
      Message: JSON.stringify(event, null, 4),
      Subject: "AWS SecurityHub Finding",
      TopicArn: process.env.TOPIC_ARN
    }, async function(err, data) {
      if (err) {
          console.log(err.stack);

          // Notify Lambda that we are finished, but with errors
          context.done(err, 'Error publishing message to SNS!');  
          return;
      }
      console.log('push sent');
      console.log(data);

      // Notify Lambda that we are finished
      context.done(null, 'Message successfully published to SNS');  
    }).promise();
    
    console.error('Error:', error);
    //throw new Error('An error occurred');
  }
  
  callback(JSON.stringify({'status': 200, "message": "Success"}));
};
