const { getRequest } = require("./utils");

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};

exports.handler = async (event) => {
    //validate token
    const accountId = getAccountId(event.headers)
    if (!accountId) {
        return {
            statusCode: 401,
            body: "{\"message\": \"Invalid token\"}"
        };
    }
    const orderItemId = event.queryStringParameters? event.queryStringParameters['orderItemId']:null
   if (!orderItemId) {
        return {
            statusCode: 412,
            body: "{\"message\": \"Invalid data.Please pass orderItemId.\"}"
        };
    }

    try {
        // Get UC order Details
        const orderPropList = "propertyIdentifiersList=orderItemStatusType";
        const ucOrderDetails = await getRequest(ucAPIPrefix + "/orderitem/" + orderItemId + "?" + orderPropList, null, ucDefaultHeaders, false);
     
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 200,
            body: JSON.stringify(ucOrderDetails)
        };
    }
    catch (err) {
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 400,
            body: JSON.stringify(err)
        };
    }
};




/**
 * Parse token
 * @param {String} token 
 * @returns payload string
*/
function parseToken(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const buff = Buffer.from(base64, 'base64');
    const payloadinit = buff.toString('ascii');
    const payload = JSON.parse(payloadinit);
    return payload
}

/**
 * Get account id from auth token
 * @param {*} headers 
 * @returns accountId
 */
function getAccountId(headers) {
    if (!headers || !headers.Authorization) {
        return null
    }

    const tokenPayload = parseToken(headers.Authorization)
    const accountId = tokenPayload.accountID
    if (!accountId)
        return null

    return accountId
}


