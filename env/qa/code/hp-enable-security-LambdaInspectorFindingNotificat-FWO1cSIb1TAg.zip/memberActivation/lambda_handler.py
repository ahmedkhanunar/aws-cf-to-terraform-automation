import json
import boto3
import os
from boto3.dynamodb.conditions import Key
import random
import string
import jwt
import sys
import traceback
from datetime import datetime
import botocore.exceptions


def lambda_handler(event, context):
    client = boto3.client("cognito-idp", region_name=os.environ["Region"])
    body = json.loads(event.get('body'))
    hipaa = body['hipaa']
    if hipaa["consent"] != True:
        return {
            'statusCode': "412",
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            'body': json.dumps({"error": "Member must accept Hipaa terms to continue"})
        }

    try:
        response = client.sign_up(
           ClientId=os.environ["ClientId"],    
           Username=body["emailAddress"],
           Password = body["password"],
           UserAttributes = [ 
                {"Name": "given_name", "Value": body['firstName']}, 
                {"Name": "family_name", "Value": body['lastName']}, 
                { "Name": "email", "Value": body['emailAddress'] }, 
                { "Name": "phone_number", "Value": body["phoneNumber"] } ],
        )
       
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
           return {
               'statusCode': response.get("ResponseMetadata").get("HTTPStatusCode"),
               "headers": {
                   'Content-Type': 'application/json',
                   'Access-Control-Allow-Origin': '*',
                   'Allow': 'GET, OPTIONS, POST',
                   'Access-Control-Allow-Methods': '*',
                   'Access-Control-Allow-Headers': '*',
               },
               'body': json.dumps({"error": "An error has occured"})
           } 
    except client.exceptions.InvalidPasswordException:
        return {
           'statusCode': 400,
           "headers": {
               'Content-Type': 'application/json',
               'Access-Control-Allow-Origin': '*',
               'Allow': 'GET, OPTIONS, POST',
               'Access-Control-Allow-Methods': '*',
               'Access-Control-Allow-Headers': '*',
           },
           'body': json.dumps({"error": "Invalid password"})
       } 
    except client.exceptions.UsernameExistsException:
        return {
           'statusCode': 400,
           "headers": {
               'Content-Type': 'application/json',
               'Access-Control-Allow-Origin': '*',
               'Allow': 'GET, OPTIONS, POST',
               'Access-Control-Allow-Methods': '*',
               'Access-Control-Allow-Headers': '*',
           },
           'body': json.dumps({"error": "The provided email already exists"})
       } 
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
           'statusCode': 500,
           "headers": {
               'Content-Type': 'application/json',
               'Access-Control-Allow-Origin': '*',
               'Allow': 'GET, OPTIONS, POST',
               'Access-Control-Allow-Methods': '*',
               'Access-Control-Allow-Headers': '*',
           },
           'body': json.dumps({"error": "An error has occured while creating your user account"})
       } 
        
    try:
        secretId = os.environ["ACTIVATION_SECRET_ID"]
        region_name = os.environ["Region"]
    
        session = boto3.session.Session()
        
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name,
        )
        
        session_token = client.get_secret_value(
            SecretId=secretId
        )
        
        stored_secret = json.loads(session_token["SecretString"]).get("SecretString", "")          
        decoded_payload = jwt.decode(body['uuid'], stored_secret, algorithms=["HS256"])
        setMemberMapping(decoded_payload['uuid'], response["UserSub"])
    except Exception as e:
        print(e)
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': "500",
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            'body': json.dumps({"error": "User not found or another error has occured"})
        } 
        
    try:
        hipaa_result = set_hipaa_consent(hipaa, decoded_payload['uuid'])
        
        if hipaa_result != True:
            return {
                'statusCode': "400",
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
                'body': json.dumps({"error": "No member found"})
            } 
    except Exception as e:
        print(e)
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': "500",
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            'body': json.dumps({"error": "Unable to create hipaa record."})
        } 

    return {
        'statusCode': "200",
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
        'body': json.dumps({"message": "Success"})
    } 
    
def set_hipaa_consent(hipaa, uuid):
    dynamodb = boto3.resource("dynamodb")
    hipaa_data = hipaa
    hipaa_item = {
        "uuid": uuid,#account_data["uuid"],
        "Type": "HIPAA",
        "FirstName": hipaa_data.get("FirstName", ""),
        "LastName": hipaa_data.get("LastName", ""),
        "Individual": hipaa_data.get("Individual", ""),
        "IndividualRelationship": hipaa_data.get("IndividualRelationship", ""),
        "Title": hipaa_data.get("title", ""),
        "Consent": hipaa_data.get("Consent", ""),
        "LegalName": hipaa_data.get("LegalName", ""),
        "ConsentDate": hipaa_data.get("ConsentDate", ""),
        "Version": hipaa_data.get("Version", "1"),
    }
    
    hipaa_table = dynamodb.Table(os.environ['MiddlewareMemberConsentTable'])
    hipaa_table.put_item(Item=hipaa_item)
    return True
    
def setMemberMapping(uuid, cognitoId):
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
    member_search = table.query(KeyConditionExpression=Key('uuid').eq(uuid))
    if (len(member_search["Items"]) > 1 or len(member_search["Items"]) == 0):
        return {
            'statusCode': "300",
            "headers": {
                "Content-Type": "application/json"
            },
            'body' : json.dumps({ "error": "No member found."})
        } 
        
    member_to_update = member_search["Items"][0]
    member_to_update["cognitoId"] = cognitoId
    table.put_item(Item=member_to_update)
    
    
def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
       QueueUrl=url,
       MessageBody=message
    )