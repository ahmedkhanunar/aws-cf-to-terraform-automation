const { getSalesforceToken, getRequest, postRequest, putRequest, getSalesforceGender } = require("./utils");
const moment = require('moment');

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};
const sf_ordersync_url = process.env.SF_API_PREFIX + "/services/data/v54.0/commerce/sale/order";
let sfToken = "";

module.exports.handler  = async (event) => {
    console.log("Input Paylod");
    console.log (event.Records[0].Sns);
    const inputJson = JSON.parse(event.Records[0].Sns.Message);
    console.log (inputJson);

    // Get Salesforce token
    if (sfToken === "") {
        sfToken = await getSalesforceToken();
        console.log('NEW Salesforce Token: ️', sfToken);
    }
    else {
        console.log('USING EXISTING Salesforce Token: ️', sfToken);
    }

    try {
        const date = moment(inputJson.orderOpenDateTime, "MMMM, DD YYYY HH:mm:ss Z");
        let sfPayload = {
            "order": [
                {
                    "attributes": {
                        "type": "Order"
                    },
                    "EffectiveDate": date.format("YYYY-MM-DD"),
                    "Status": "Draft",
                    "accountId": inputJson.account.salesforcePersonIdentifier,
                    "Pricebook2Id": "01s8a000002g8J9AAI",
                    "Health_Sphere_Order_Id__c": inputJson.orderID,
                    "BillingStreet": inputJson.shippingAddress.streetAddress,
                    "BillingCity": inputJson.shippingAddress.city,
                    "BillingState": inputJson.shippingAddress.stateCode,
                    "BillingPostalCode": inputJson.shippingAddress.postalCode,
                    "BillingCountry": inputJson.shippingAddress.countryCode,
                    "ShippingStreet": inputJson.shippingAddress.streetAddress,
                    "ShippingCity": inputJson.shippingAddress.city,
                    "ShippingState": inputJson.shippingAddress.stateCode,
                    "ShippingPostalCode": inputJson.shippingAddress.postalCode,
                    "ShippingCountry": inputJson.shippingAddress.countryCode,
                    "PSC_Order_Total__c": inputJson.calculatedTotal,
                    "Health_Sphere_Order_Number__c": inputJson.orderNumber
                }
            ]
        };

        console.log(JSON.stringify(sfPayload));
        // Call the Salesforce API to update profile
        const sfHeaders = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sfToken.access_token
        }
        const sfResponse = await postRequest (sf_ordersync_url, sfPayload, sfHeaders);
        console.log("Salesforce Response*******");
        console.log(JSON.stringify(sfResponse));

        // Update Salesforce Order ID to Ultra Commerce
        console.log ("Updating Salesforce Order ID in UC");
        const ucSFOrderIdPayload = {
            "salesforceOrderD": sfResponse.records[0].Id
        };
        console.log("UC Salesforce Order ID Payload", JSON.stringify(ucSFOrderIdPayload));
        const ucOrderUpdateRes = await postRequest(ucAPIPrefix + "/order/" + inputJson.orderID, ucSFOrderIdPayload, ucDefaultHeaders);
        console.log('UC Salesforce Order ID Response: ️', ucOrderUpdateRes);
        
        return {
            statusCode: 200,
            body: JSON.stringify(sfResponse)
        };
    }
    catch (err) {
        console.log(err);
        return {
            statusCode: 400,
            body: JSON.stringify(err)
        };
    }
};