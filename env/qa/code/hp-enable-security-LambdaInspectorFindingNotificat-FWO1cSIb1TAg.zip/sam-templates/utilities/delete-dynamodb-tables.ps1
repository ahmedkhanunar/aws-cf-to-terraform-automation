
# function usage {
#     Write-Host "Usage: delete-dynamodb-tables.ps1 -d Y|N -p hp_dev -r aws_region"
#     Write-Host "Delete all DynamoDB tables"
#     Write-Host " -d Y|N  -- Delete Table"
#     Write-Host " -p hp_dev -- AWS Profile configured in AWS CLI (optional)"
#     Write-Host " -r aws_region -- AWS Region (optional)"
#     Write-Host ""
# }

# Retrieve the calling parameters.
param (
    [string]$d,
    [string]$p,
    [string]$r
)

if (-not $d) {
    Write-Host "ERROR: You must provide a confirmation to delete the table. Once deleted, it cannot be undone"
    usage
    exit 1
}

if ($d -ne "Y" -and $d -ne "y" -and $d -ne "N" -and $d -ne "n") { 
    Write-Host "ERROR: You must provide value as Y or N with the -d parameter."
    usage
    exit 1
}

$region_param = ""
if ($r) {
    $region_param = "--region $r"
}

$profile_param = ""
if ($p) {
    $profile_param = "--profile $p"
}

if ($d -eq "Y" -or $d -eq "y") {
    # Delete DynamoDB tables
    $all_dynamodb_tables = (aws dynamodb list-tables --output text --query "TableNames" $profile_param $region_param)
    foreach ($element in $all_dynamodb_tables) {
        Write-Host "Deleting table $element..."
      #  aws dynamodb delete-table --table-name $element $profile_param $region_param
    }

    # # Deregister scalable target
    # $aws_application_autoscaling_output = aws application-autoscaling describe-scalable-targets --output text --query 'ScalableTargets[*].{ResourceId:ResourceId, ScalableDimension:ScalableDimension}' --service-namespace dynamodb $profile_param $region_param
    # $aws_application_autoscaling_output | ForEach-Object {
    #     $scalable_target = $_
    #     $resource_id, $dimension = $scalable_target -split "\t"
    #     Write-Host "Deleting Scalable Target ResourceID: $resource_id, Dimension: $dimension"
    #     aws application-autoscaling deregister-scalable-target --service-namespace dynamodb --resource-id $resource_id --scalable-dimension "$dimension" $profile_param $region_param
    # }

    # # Delete scaling policy
    # $aws_application_autoscaling_output = aws application-autoscaling describe-scaling-policies --service-namespace dynamodb --output text --query 'ScalingPolicies[*].{PolicyName: PolicyName, ResourceId: ResourceId, ScalableDimension: ScalableDimension}' $profile_param $region_param
    # $aws_application_autoscaling_output | ForEach-Object {
    #     $scaling_policy = $_
    #     $policy_name, $resource_id, $dimension = $scaling_policy -split "\t"
    #     Write-Host "Deleting Scaling Policy Policy: $policy_name, ResourceID: $resource_id, Dimension: $dimension ..."
    #     aws application-autoscaling deregister-scalable-target --service-namespace dynamodb --resource-id "$resource_id" --scalable-dimension $dimension $profile_param $region_param
    # }
}
