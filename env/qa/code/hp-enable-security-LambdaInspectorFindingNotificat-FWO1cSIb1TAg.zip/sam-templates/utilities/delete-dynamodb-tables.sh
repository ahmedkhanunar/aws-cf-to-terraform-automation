#!/bin/bash

function usage() {
    echo "Usage: delete-dynamodb-tables -d Y|N -p hp_dev -r aws_region"
    echo "Delete all DynamoDB tables"
    echo " -d Y|N  -- Delete Table"
    echo " -p hp_dev -- AWS Profile configured in AWS CLI (optional)"
    echo " -r aws_region -- AWS Region (optional)"
    echo ""
}

# Retrieve the calling parameters.
while getopts ":d:p:r:e:h" option; do
    case "${option}" in
        d) d="${OPTARG}" ;;
        p) p="${OPTARG}" ;;
        r) r="${OPTARG}" ;;
        h)
        usage
        exit 0
        ;;
        \?)
        echo "Invalid parameter"
        usage
        exit 1
        ;;
    esac
done
shift $((OPTIND-1))

if [[ -z "$d" ]]; then
    echo "ERROR: You must provide a confirmation to delete the table. Once deleted, it cannot be undone"
    usage
    exit 1
fi

if [ "$d" != "Y" ] && [ "$d" != "y" ] && [ "$d" != "N" ] && [ "$d" != "n" ]; then 
    echo "ERROR: You must provide value as Y or N with the -d parameter."
    usage
    exit 1
fi

region_param=""
if [ "$r" != "" ]; then
    region_param="--region ${r}"
fi

profile_param=""
if [ "$p" != "" ]; then
    profile_param="--profile ${p}"
fi

if [ "$d" = "Y" ] || [ "$d" = "y" ]; then
    # Delete DynamoDB tables
    all_dynamodb_tables=( `aws dynamodb list-tables --output text --query "TableNames" ${profile_param} ${region_param}` )
    for element in "${all_dynamodb_tables[@]}"
    do
        echo "Deleting table ${element}..."
        response=( `aws dynamodb delete-table --table-name ${element} ${profile_param} ${region_param}` )
    done

    # Deregister scalable target
    scalable_target=""
    aws application-autoscaling describe-scalable-targets --output text --query 'ScalableTargets[*].{ResourceId:ResourceId, ScalableDimension:ScalableDimension}' --service-namespace dynamodb ${profile_param} ${region_param} |
    while read scalable_target ; do
        read resource_id dimension <<< ${scalable_target}
        echo "Deleting Scalable Target ResourceID: ${resource_id}, Dimension: ${dimension} ..."
        response=( `aws application-autoscaling deregister-scalable-target --service-namespace dynamodb --resource-id "${resource_id}" --scalable-dimension "${dimension}" ${profile_param} ${region_param}` )
    done

    # Delete scaling policy
    scaling_policy=""
    aws application-autoscaling describe-scaling-policies --service-namespace dynamodb --output text --query 'ScalingPolicies[*].{PolicyName: PolicyName, ResourceId: ResourceId, ScalableDimension: ScalableDimension}' ${profile_param} ${region_param} |
    while read scaling_policy ; do
        read policy_name resource_id dimension <<< ${scaling_policy}
        echo "Deleting Scaling Policy Policy: ${policy_name}, ResourceID: ${resource_id}, Dimension: ${dimension} ..."
        response=( `aws application-autoscaling deregister-scalable-target --service-namespace dynamodb --resource-id "${resource_id}" --scalable-dimension "${dimension}" ${profile_param} ${region_param}` )
    done
fi