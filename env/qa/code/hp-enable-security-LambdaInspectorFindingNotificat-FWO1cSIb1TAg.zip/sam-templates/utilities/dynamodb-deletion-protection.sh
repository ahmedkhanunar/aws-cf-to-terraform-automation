#!/bin/bash

function usage() {
    echo "Usage: dynamodb-deletion-protection.sh -d Y|N [-p hp_dev] [-r AWS_Region]"
    echo "Enable/Disable Deletion Protection on all DynamoDB tables"
    echo " -d Y|N  -- Deletion protection on/off."
    echo " -p hp_dev -- AWS Profile configured in AWS CLI (Optional)"
    echo " -r aws_region -- AWS Region (Optional)"
    echo ""
}

# Retrieve the calling parameters.
while getopts ":d:p:r:h" option; do
    case "${option}" in
        d) d="${OPTARG}" ;;
        p) p="${OPTARG}" ;;
        r) r="${OPTARG}" ;;
        h)
        usage
        exit 0
        ;;
        \?)
        echo "Invalid parameter"
        usage
        exit 1
        ;;
    esac
done
shift $((OPTIND-1))

if [[ -z "$d" ]]; then
    echo "ERROR: You must provide a deletion protection Y/N with the -d parameter."
    usage
    exit 1
fi

if [ "$d" != "Y" ] && [ "$d" != "y" ] && [ "$d" != "N" ] && [ "$d" != "n" ]; then 
    echo "ERROR: You must provide value as Y or N with the -d parameter."
    usage
    exit 1
fi

deletion_protection_param="--no-deletion-protection-enabled"
deletion_protection_text="Disabling"
if [ "$d" = "Y" ] || [ "$d" = "y" ]; then
    deletion_protection_param="--deletion-protection-enabled"
    deletion_protection_text="Enabling"
fi

region_param=""
if [ "$r" != "" ]; then
    region_param="--region ${r}"
fi

profile_param=""
if [ "$p" != "" ]; then
    profile_param="--profile ${p}"
fi

all_dynamodb_tables=( `aws dynamodb list-tables --output text --query "TableNames" ${profile_param} ${region_param}` )
for element in "${all_dynamodb_tables[@]}"
do
    echo "${deletion_protection_text} deletion protection for ${element}..."
    #echo "aws dynamodb update-table --table-name ${element} ${deletion_protection_param} --profile ${p}"
    response=( `aws dynamodb update-table --table-name ${element} ${deletion_protection_param} ${profile_param} ${region_param}` )
done