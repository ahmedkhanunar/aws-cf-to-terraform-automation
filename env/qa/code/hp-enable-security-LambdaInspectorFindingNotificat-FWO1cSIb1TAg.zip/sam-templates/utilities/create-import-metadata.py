import json
import os
import subprocess
import sys

def get_scalingpolicy_arn (arn, dimension, aws_profile):
    arn_split = arn.split(':')
    resource_id = arn_split[7].replace('resource/dynamodb/', '')
    print(resource_id)

    result = subprocess.run(['aws', 'application-autoscaling', 'describe-scaling-policies', '--service-namespace', 'dynamodb', '--resource-id', resource_id, '--scalable-dimension', dimension, '--profile', aws_profile], stdout=subprocess.PIPE)
    output_json = json.loads(result.stdout)
    #print(output_json['ScalingPolicies'][0]['PolicyARN'])
    return output_json['ScalingPolicies'][0]['PolicyARN']

def get_secret_manager_arn (arn, aws_profile):
    arn_split = arn.split(':')
    secret_id = arn_split[6].rsplit('-', 1)[0]
    print(secret_id)

    result = subprocess.run(['aws', 'secretsmanager', 'describe-secret', '--secret-id', secret_id, '--profile', aws_profile], stdout=subprocess.PIPE)
    output_json = json.loads(result.stdout)
    #print(output_json['ARN'])
    return output_json['ARN']

if len(sys.argv) < 2:
    sys.exit("ERROR: Please profile AWS Profile")

aws_profile = sys.argv[1]  

#Secret Manager
resources_secret = []
with open('../secretmanager-resource-to-import.txt', 'r') as fr_secret:
    objects = json.load(fr_secret)
    for obj in objects:
        arn = obj['ResourceIdentifier']['Id']

        secret_arn = get_secret_manager_arn(arn, aws_profile)
        obj['ResourceIdentifier']['Id'] = secret_arn
        resources_secret.append(obj)
 
with open('../secretmanager-resource-to-import-' + aws_profile + '.txt', 'w') as fw_secret:
    json.dump(resources_secret, fw_secret, indent = 4)

#DynamoDB
resources_dynamodb = []
with open('../dynamodb-resource-to-import.txt', 'r') as fr_dynamodb:
    objects = json.load(fr_dynamodb)
    for obj in objects:
        if obj['ResourceType'] != 'AWS::ApplicationAutoScaling::ScalingPolicy':
            resources_dynamodb.append(obj)
        else:
            arn = obj['ResourceIdentifier']['Arn']
            dimension = obj['ResourceIdentifier']['ScalableDimension']

            policy_arn = get_scalingpolicy_arn(arn, dimension, aws_profile)
            obj['ResourceIdentifier']['Arn'] = policy_arn
            resources_dynamodb.append(obj)
 
with open('../dynamodb-resource-to-import-' + aws_profile + '.txt', 'w') as fw_dynamodb:
    json.dump(resources_dynamodb, fw_dynamodb, indent = 4)
