#!/bin/bash

function usage() {
    echo "Usage: delete-secrets.sh -d Y|N -p hp_dev -r aws_region"
    echo "Delete all DynamoDB tables"
    echo " -d Y|N  -- Delete Table"
    echo " -p hp_dev -- AWS Profile configured in AWS CLI (optional)"
    echo " -r aws_region -- AWS Region (optional)"
    echo ""
}

# Retrieve the calling parameters.
while getopts ":d:p:r:e:h" option; do
    case "${option}" in
        d) d="${OPTARG}" ;;
        p) p="${OPTARG}" ;;
        r) r="${OPTARG}" ;;
        h)
        usage
        exit 0
        ;;
        \?)
        echo "Invalid parameter"
        usage
        exit 1
        ;;
    esac
done
shift $((OPTIND-1))

if [[ -z "$d" ]]; then
    echo "ERROR: You must provide a confirmation to delete the secret. Once deleted, it cannot be undone"
    usage
    exit 1
fi

if [ "$d" != "Y" ] && [ "$d" != "y" ] && [ "$d" != "N" ] && [ "$d" != "n" ]; then 
    echo "ERROR: You must provide value as Y or N with the -d parameter."
    usage
    exit 1
fi

region_param=""
if [ "$r" != "" ]; then
    region_param="--region ${r}"
fi

profile_param=""
if [ "$p" != "" ]; then
    profile_param="--profile ${p}"
fi

if [ "$d" = "Y" ] || [ "$d" = "y" ]; then
    all_secrets=( `aws secretsmanager list-secrets --output text --query 'SecretList[*].Name' ${profile_param} ${region_param}` )
    for element in "${all_secrets[@]}"
    do
        echo "Deleting secret ${element}..."
        response=( `aws secretsmanager delete-secret --secret-id ${element} --force-delete-without-recovery ${profile_param} ${region_param}` )
    done
fi