const https = require('https');
const zlib = require('zlib');
const sodium = require('libsodium-wrappers')
const AWS = require('aws-sdk')
const { IAMClient, ListUsersCommand, GetUserCommand, ListAccessKeysCommand, CreateAccessKeyCommand, DeleteAccessKeyCommand } = require("@aws-sdk/client-iam");

// Set the AWS Region.
const REGION = process.env.REGION;
// Create an IAM service client object.
const iamClient = new IAMClient({ region: REGION });
const sesClient = new AWS.SES({ region: REGION });
const userNames = process.env.GITHUB_AWS_USERNAME.split(",")
const repositories = process.env.GITHUB_REPOSITORIES.split(",")
const accessKeyAge = process.env.ACCESS_KEY_MAXAGE;
const GitHub_PubKey = process.env.GITHUB_PUBLIC_KEY;
const GITHUB_AWS_ACCESS_KEYID = process.env.GITHUB_AWS_ACCESS_KEYID;
const GITHUB_AWS_ACCESS_KEYSECRET = process.env.GITHUB_AWS_ACCESS_KEYSECRET;
const toAddresses = ['ITOperations@HelloPorter.com'];
const fromAddress = 'ITOperations@HelloPorter.com';
const environment = process.env.ENVIRONMENT;

// Terraform Config
const tfUserName = process.env.TERRAFORM_AWS_USERNAME.split(",")
const TF_TOKEN = process.env.TERRAFORM_API_TOKEN;
const TF_AWS_ACCESS_KEYID = process.env.TF_AWS_ACCESS_KEYID;
const TF_AWS_ACCESS_KEYSECRET = process.env.TF_AWS_ACCESS_KEYSECRET;

exports.handler = async (event, context) => {
  try {
    console.log ("REGION: " + REGION);
    console.log ("userNames: "+JSON.stringify(userNames));
    console.log ("repositories: "+JSON.stringify(repositories));
    console.log ("environment: "+JSON.stringify(environment));
    console.log ("tfUserName: "+JSON.stringify(tfUserName));

    accessKeysToDelete = [];
    newAccessKeys = [];
    today = new Date();
    for (i=0; i < userNames.length; i++) {
      const user = await iamClient.send (new ListAccessKeysCommand({UserName: userNames[i]}))
      const accessKeys = user.AccessKeyMetadata || []
      accessKeys.forEach (function (accessKey) {
        differentDays = Math.ceil(Math.abs(today.getTime() - accessKey.CreateDate.getTime()) / (1000 * 3600 * 24));
        console.log ("Access Key: " + accessKey.AccessKeyId + ", Created: " + accessKey.CreateDate + ", Status: " + accessKey.Status + ", Age: " + differentDays);

        if (differentDays >= accessKeyAge) {
          accessKeysToDelete.push ({"KeyID": accessKey.AccessKeyId, "Username": userNames[i], "Age": differentDays});
        }
      });
      console.log(accessKeysToDelete);
      
      // If there are access keys which are old and needs to be rotated, then delete them and create new one
      if (accessKeysToDelete.length > 0) {
        // Delete old access keys
        for (const accessKey of accessKeysToDelete) {
          console.log("Deleting Key ID " + accessKey.KeyID + " of " + accessKey.Username);
          const accessKeyDeleteRes = await iamClient.send (new DeleteAccessKeyCommand({UserName: accessKey.Username, AccessKeyId: accessKey.KeyID}));
          console.log(JSON.stringify(accessKeyDeleteRes));

          // Create a new access key
          console.log("Creating new access key for " + accessKey.Username);
          const newAccessKeyObj = await iamClient.send (new CreateAccessKeyCommand({UserName: accessKey.Username}));
          const newAccessKey = newAccessKeyObj.AccessKey || []
          newAccessKeys.push ({"Username": newAccessKey.UserName, "KeyID": newAccessKey.AccessKeyId, "KeySecret": newAccessKey.SecretAccessKey});
          console.log("New Key: Username - " + newAccessKey.UserName + ", KeyID - " + newAccessKey.AccessKeyId + ", KeySecret - " + newAccessKey.SecretAccessKey);
        }
      }
    }
    
    //
    // Update AWS Access Key & Secret in GitHub & Terraform
    //
    if (newAccessKeys.length > 0) {
      // Encrypt the access key and secret keys and update to GitHub
      for (const repo of repositories) {
        console.log("Updating secret for repository - " + repo);
        // Get Public Key for the repo for encryptiong GitHub Secrets
        const gitHubPubKey = await getRequest("https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/public-key", null, {"User-Agent": "helloporter/aws-key-rotation/1.0", "Accept": "application/vnd.github+json", "Authorization": "Bearer " + GitHub_PubKey, "X-GitHub-Api-Version": "2022-11-28"}, false);
        console.log('GitHub PubKey: ️', gitHubPubKey);
        
        for (const accessKey of newAccessKeys) {
          let encAccessKeyId, encAccessKeySecret;
          await sodium.ready.then(() => {
            // Convert Secret & Base64 key to Uint8Array.
            let binkey = sodium.from_base64(gitHubPubKey.key, sodium.base64_variants.ORIGINAL);
            let awsAccessKeyId = sodium.from_string(accessKey.KeyID);
            let awsAccessKeySecret = sodium.from_string(accessKey.KeySecret);
        
            //Encrypt the secret using LibSodium
            let awsAccessKeyIdBytes = sodium.crypto_box_seal(awsAccessKeyId, binkey);
            let awsAccessKeySecretBytes = sodium.crypto_box_seal(awsAccessKeySecret, binkey);
        
            // Convert encrypted Uint8Array to Base64
            encAccessKeyId = sodium.to_base64(awsAccessKeyIdBytes, sodium.base64_variants.ORIGINAL);
            encAccessKeySecret = sodium.to_base64(awsAccessKeySecretBytes, sodium.base64_variants.ORIGINAL);  
          });
    
          // Encrypt AWS Key ID and Key Secret
          console.log ("GitHub Pub Key: " + gitHubPubKey.key);
          console.log ("encAccessKeyId: " + encAccessKeyId + ", " + accessKey.KeyID);
          console.log ("encAccessKeySecret: " + encAccessKeySecret + ", " + accessKey.KeySecret);

          // Update GitHub Action Secrets - AWS KEY ID
          const awsKeyIDRes = await putRequest("https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/" + GITHUB_AWS_ACCESS_KEYID, {"key_id": gitHubPubKey.key_id, "encrypted_value": encAccessKeyId}, {"User-Agent": "helloporter/aws-key-rotation/1.0", "Accept": "application/vnd.github+json", "Authorization": "Bearer " + GitHub_PubKey, "X-GitHub-Api-Version": "2022-11-28"}, true);
          console.log('awsKeyIDRes: ️', awsKeyIDRes);

          // Update GitHub Action Secrets - AWS KEY Secret
          const awsKeySecretRes = await putRequest("https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/" + GITHUB_AWS_ACCESS_KEYSECRET, {"key_id": gitHubPubKey.key_id, "encrypted_value": encAccessKeySecret}, {"User-Agent": "helloporter/aws-key-rotation/1.0", "Accept": "application/vnd.github+json", "Authorization": "Bearer " + GitHub_PubKey, "X-GitHub-Api-Version": "2022-11-28"}, true);
          console.log('awsKeySecretRes: ️', awsKeySecretRes);
        }
      }
    }
    
    // For Terraform user
    if (environment.toLowerCase() == 'production') {
      for (i=0; i < tfUserName.length; i++) {
        const user = await iamClient.send (new ListAccessKeysCommand({UserName: tfUserName[i]}))
        const accessKeys = user.AccessKeyMetadata || []
        accessKeys.forEach (function (accessKey) {
          differentDays = Math.ceil(Math.abs(today.getTime() - accessKey.CreateDate.getTime()) / (1000 * 3600 * 24));
          console.log ("TF Access Key: " + accessKey.AccessKeyId + ", Created: " + accessKey.CreateDate + ", Status: " + accessKey.Status + ", Age: " + differentDays);
  
          if (differentDays >= accessKeyAge) {
            accessKeysToDelete.push ({"KeyID": accessKey.AccessKeyId, "Username": tfUserName[i], "Age": differentDays});
          }
        });
  
        // If there are access keys which are old and needs to be rotated, then delete them and create new one
        if (accessKeysToDelete.length > 0) {
          // Delete old access keys
          for (const accessKey of accessKeysToDelete) {
            if (tfUserName.includes (accessKey.Username)) {
              console.log("TF Deleting Key ID " + accessKey.KeyID + " of " + accessKey.Username);
              const accessKeyDeleteRes = await iamClient.send (new DeleteAccessKeyCommand({UserName: accessKey.Username, AccessKeyId: accessKey.KeyID}));
              //console.log(JSON.stringify(accessKeyDeleteRes));
  
              // Create a new access key
              console.log("TF Creating new access key for " + accessKey.Username);
              const newAccessKeyObj = await iamClient.send (new CreateAccessKeyCommand({UserName: accessKey.Username}));
              const newAccessKey = newAccessKeyObj.AccessKey || []
              newAccessKeys.push ({"Username": newAccessKey.UserName, "KeyID": newAccessKey.AccessKeyId, "KeySecret": newAccessKey.SecretAccessKey});
              console.log("TF New Key: Username - " + newAccessKey.UserName + ", KeyID - " + newAccessKey.AccessKeyId + ", KeySecret - " + newAccessKey.SecretAccessKey);
            }
          }
        }
      }
  
      // Update AWS Access Key & Secret in Terraform
      //
      // AWS Access Key ID
      for (const accessKey of newAccessKeys) {
        if (tfUserName.includes (accessKey.Username)) {
          const tfAwsAccessKeyId = await patchRequest("https://app.terraform.io/api/v2/vars/" + TF_AWS_ACCESS_KEYID, {"data":{"id":TF_AWS_ACCESS_KEYID,"attributes":{"value":accessKey.KeyID},"type":"vars"}}, {"Content-Type": "application/vnd.api+json", "Authorization": "Bearer " + TF_TOKEN}, true);
          console.log('tfAwsAccessKeyId: ️', tfAwsAccessKeyId);
  
          const tfAwsAccessKeySecret = await patchRequest("https://app.terraform.io/api/v2/vars/" + TF_AWS_ACCESS_KEYSECRET, {"data":{"id":TF_AWS_ACCESS_KEYSECRET,"attributes":{"value":accessKey.KeySecret},"type":"vars"}}, {"Content-Type": "application/vnd.api+json", "Authorization": "Bearer " + TF_TOKEN}, true);
          console.log('tfAwsAccessKeySecret: ️', tfAwsAccessKeySecret);
        }
      }
    }

    if (accessKeysToDelete.length > 0) {
      console.log("Preparing email body...");
      let html = "Following AWS Access Keys were deleted as they were older than " + accessKeyAge + " days<br/>"
      html += "<table><tr><td>IAM User</td><td>Access Key ID</td><td>Age</td></tr>";
      for (const accessKey of accessKeysToDelete) {
        html += "<tr><td>" + accessKey.Username + "</td><td>" + accessKey.KeyID + "</td><td>" + accessKey.Age + "</td></tr>";
      }
      html += "</table><br/><br/>";

      html += "Follwing new Access Keys were created<br/>";
      html += "<table><tr><td>IAM User</td><td>Access Key ID</td><td>Access Key Secret</td></tr>";
      for (const accessKey of newAccessKeys) {
        html += "<tr><td>" + accessKey.Username + "</td><td>" + accessKey.KeyID + "</td><td>" + accessKey.KeySecret + "</td></tr>";
      }
      html += "</table><br/><br/>";

      console.log(html);
      console.log("Sending emai...")
      await sendMail(environment + ": AWS Automatic Key Rotation", html, toAddresses, fromAddress);
    }
    
  } catch (err) {
    console.log("Exception")
    console.log(err);
  }
};

function getRequest(url, params, headers, isJson = true) {
  return doRequest (url, 'GET', params, headers, isJson);
}

function postRequest(url, params, headers, isJson = true) {
  return doRequest (url, 'POST', params, headers, isJson);
}

function patchRequest(url, params, headers, isJson = true) {
  console.log (headers);
  return doRequest (url, 'PATCH', params, headers, isJson);
}

function putRequest(url, params, headers, isJson = true) {
  console.log (headers);
  return doRequest (url, 'PUT', params, headers, isJson);
}

function doRequest (url, method, params, headers, isJson = true) {
  if (isJson) {
      if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
  }
  const options = {
      method: method,
      headers: headers,
  };
  console.log ("URL: ", url);
  console.log ("Headers: ", JSON.stringify(options));

  return new Promise((resolve, reject) => {
      var req = https.request(url, options, (res) => {
          console.log('statusCode:', res.statusCode);
          //console.log('headers:', res.headers);
          
          let chunks = [];

          if (res.headers['content-encoding'] === 'gzip') {
              const gunzip = zlib.createGunzip();
              res.pipe(gunzip);    

              gunzip.on('data', function(data) {
                  chunks.push(data.toString())
              }).on("end", function() {
                  let body = chunks.join("");
                  console.log("GZip Response: " + body.toString());

                  try {
                      resolve(JSON.parse(body.toString()));
                  } catch (err) {
                      console.error(err);
                      reject(new Error(err));
                  }

              }).on("error", function(e) {
                  console.error(e);
              })
          }
          else {
              res.on("data", function (chunk) {
                  chunks.push(chunk);
              }).on('end', () => {
                  let body = chunks.join("");
                  console.log("Non-GZip Response: "+body.toString());

                  try {
                    if (body.toString() != "") 
                      resolve(JSON.parse(body.toString()));
                    else
                      resolve("Blank Response but success");
                  } catch (err) {
                      console.error(err);
                      reject(new Error(err));
                  }
              });
          }
      });
      
      req.on('error', (e) => {
          console.log(e);
          reject(new Error(e));
      });
      
      if (params !== null) {
          console.log ("Parameters JSON? ", isJson);
          console.log ("Parameters: ", JSON.stringify(params));
          if (isJson) {
              req.write(JSON.stringify(params));
          }
          else {
              const paramNames = Object.keys(params);
              let paramArray = [];
              paramNames.forEach((key, index) => {
                  paramArray.push (key + "=" + encodeURI(params[key]));
              });
              req.write(paramArray.join("&"));
          }
      }
      req.end();
  });
}

async function sendMail(subject, messageBody, toAddresses, fromAddress) {
  const emailParams = {
        Destination: {
          ToAddresses: toAddresses,
        },
        Message: {
          Body: {
            Text: { Data: messageBody },
            Html: { Data: messageBody }
          },
          Subject: { Data: subject },
        },
        Source: fromAddress,
  };
      
  try {
        let key = await sesClient.sendEmail(emailParams).promise();
        console.log("MAIL SENT SUCCESSFULLY!!");
  } catch (e) {
        console.log("FAILURE IN SENDING MAIL!!", e);
      }  
  return;
}