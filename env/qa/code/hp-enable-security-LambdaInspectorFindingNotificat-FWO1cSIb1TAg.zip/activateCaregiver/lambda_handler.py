import json
import os
from datetime import datetime,timezone
import boto3
from boto3.dynamodb.conditions import Key,Attr
import sys
import traceback
import requests
from cerberus import Validator
from sf_generate_token import generateAccessTokenSF
import uuid

dynamo = boto3.resource('dynamodb')
memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }


caregiverSchema = {
            'firstName': {
                'type': 'string',
                'required': True
            },
            'lastName': {
                'type': 'string',
                'required': True
            },
            'emailAddress': {
                'type': 'string',
                'required': True,
                'regex': r'^([A-Za-z0-9_\-\+\.])+\@([A-Za-z0-9_\-\+\.])+\.([A-Za-z]{2,4})$'
            },
            'phoneNumber': {
                'type': 'string',
                'required': True,
                'minlength': 8
            },
             'careReceiverMemberId': {
                'type': 'string',
                'required': True
            },
            'caregiverRequestId': {
                'type': 'string',
                'required': True
            },
            'password': {
                'type': 'string',
                'required': True
            },
            'dateOfBirth':{
                'type': 'datetime',
                'coerce':lambda s: datetime.strptime(s, '%Y-%m-%d'),
                'required': True
    
            },
            'securityAnswers': { 'type': 'list',"minlength": 2,"maxlength": 2, 'required': True, 'schema': { 'type': 'dict', 'schema': { 'questionId': {'type': 'string', 'required': True},'answer': {'type': 'string', 'required': True} } } }
        }
caregiverRequestExpiryInHours = 24

def lambda_handler(event, context):
      
    return create_caregiver_account(event) 
    


def create_caregiver_account(event):

    try:
        bodyData = json.loads(event.get('body')) if event.get('body') != None else {}
            
        validator = Validator(caregiverSchema,allow_unknown=True)
       

        if not validator.validate(bodyData):
            return failure_response(400,'invalid body',validator.errors)
        
        # set timestamp
        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds") 
       
        
        memberWithCaregiverRequestData = fetch_caregiver_request_data(bodyData['careReceiverMemberId'],'CaregiverMappingList',bodyData['caregiverRequestId'])

        if memberWithCaregiverRequestData is None:
            return failure_response(404,'Invalid request data.')

        caregiverRequestDataIndex = memberWithCaregiverRequestData['caregiverRequestDataIndex']

        memberMappingData = memberWithCaregiverRequestData['memberData']

        caregiverRequestData = memberWithCaregiverRequestData['caregiverRequestData']
        # validate link has been already used or not
        if caregiverRequestData.get("IsClicked",False) :
            return failure_response(409,'Request Link has been already used.')
            
        if caregiverRequestData.get("Status",'') != 'INVITE_SENT' :
            return failure_response(404,'Invalid request data.')

        #validate time
        dateTimeDifference = datetime.now(timezone.utc)-datetime.fromisoformat(caregiverRequestData["CreatedDate"])
        #check date time difference is less than 24 hours
        if dateTimeDifference is None or dateTimeDifference.total_seconds() < 0 or dateTimeDifference.total_seconds() / 3600 > caregiverRequestExpiryInHours :
            return failure_response(498,'Request Link is expired.')

        #create salesforce account
        sfCreateAccountRes = create_sf_account(bodyData,caregiverRequestData.get("CarereceiverSFId"),caregiverRequestData.get("Relationship"))
        if sfCreateAccountRes.status_code != 200 :
            return failure_response(400,'Error while Activating account.','')
            
        sfCaregiverAccount = sfCreateAccountRes.json()

        #create cognito account
        cognitoResponse = create_account(bodyData)
         
        if cognitoResponse.get('statusCode') != 200:
            return cognitoResponse
        cognitoId = cognitoResponse.get('cognitoId')
        
       
        
        #update caregiver request status
        caregiverRequestData['FirstName'] = bodyData['firstName']
        caregiverRequestData['LastName'] = bodyData['lastName']
        caregiverRequestData['PhoneNumber'] = bodyData['phoneNumber']
        caregiverRequestData['EmailAddress'] = bodyData['emailAddress']
        caregiverRequestData['DateOfBirth'] = bodyData['dateOfBirth']
        caregiverRequestData['Status'] = 'ACTIVE'
        caregiverRequestData['UpdatedDate'] = dateTimeNow
        caregiverRequestData['IsClicked'] = True
        caregiverRequestData['CaregiverSFId'] = sfCaregiverAccount["caregiverAccountId"]
        caregiverRequestData['RelationshipSFId'] = sfCaregiverAccount["memberCaregiverRelationId"]

        #add member details in mapping and details table
        
        caregiverMemberUUID = add_member_data(bodyData,cognitoId,sfCaregiverAccount)
       
            
        
        caregiverRequestData['CaregiverUUID'] = caregiverMemberUUID
        
        
        update_caregiver_request(caregiverRequestData,caregiverRequestDataIndex)
        

        update_carereciver_data(bodyData['emailAddress'],caregiverMemberUUID,sfCaregiverAccount["caregiverAccountId"])
        

        add_security_answers(bodyData['securityAnswers'],caregiverMemberUUID)
        memberData = get_member_details(caregiverRequestData['CarereceiverUUID'],memberMappingData['cognitoId'])
        if memberData is not None:
            send_invite_accept_email(caregiverRequestData,memberData)

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Caregiver account is created. Please check your email for activating account.'}),
            'headers': headers
        }
            
        

  
    except Exception as err:
      exec_info = sys.exc_info()
      ex = ''.join(traceback.format_exception(*exec_info))
      write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
      return failure_response()
    
def add_security_answers(securityAnswers,memberUUID):
  answerItems = []
  for data in securityAnswers:
    answerItems.append({'uuid':str(uuid.uuid4()),'Answer':data['answer'],'ExternalID':memberUUID,'SecurityQuestionMasterUUID':data['questionId']})

  table = dynamo.Table(os.environ['SecurityAnswerMappingTable'])
  with table.batch_writer() as writer:
      for item in answerItems:
          writer.put_item(Item=item)
    
def send_invite_accept_email(caregiverRequestData,memberData):
   client = boto3.client('ses')
   careGiverName = caregiverRequestData["FirstName"].capitalize()+" "+caregiverRequestData["LastName"][0].capitalize()
   
   url =  os.environ["WebAppUrl"]+"/contact-us"
   
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Good News! Your Caregiver Invite Has Been Accepted.
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""+careGiverName+"""</b> has accepted your invite to be a caregiver of your account. They can now see all your health information and assist you in anyway you need. No further action is needed on your part.

                                    <br/><br/>Didn’t send this invite? Please <a href='"""+url+"""' style="color:#1579D6">contact support</a> immediately or call 1(800) 558-9922.
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                       
									              </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>   """
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"Good News! Your Caregiver Invite Has Been Accepted.",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [memberData['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )
 
def update_carereciver_data(emailAddress,caregiverMemberUUID,caregiverMemberSFId):
    # scan all data with given email address and with blank caregiverUUID
    unlinkedDataforCaregiver = caregiverRequestTable.scan(FilterExpression=Key('EmailAddress').eq(emailAddress))
    
    careReceiverMappingList = []
    if len(unlinkedDataforCaregiver.get("Items",[])) > 0 :
        #update caregiver and carerecevier data with caregiveruuid and caregiversfid
        for caregiverRequest in unlinkedDataforCaregiver.get("Items",[]):
            
            
            requestData = fetch_caregiver_request_data(caregiverRequest['CarereceiverUUID'],'CaregiverMappingList',caregiverRequest['CaregiverRequestUUID'])
            
            if requestData is not None:
                
                caregiverRequestDataIndex = requestData['caregiverRequestDataIndex']
                caregiverRequestData = requestData['caregiverRequestData']
                caregiverRequestData['CaregiverSFId'] = caregiverMemberSFId
                caregiverRequestData['CaregiverUUID'] = caregiverMemberUUID
                update_caregiver_request(caregiverRequestData,caregiverRequestDataIndex)
                careReceiverData = caregiverRequestData.copy()
                memberMappingData = requestData['memberData']
                
                memberData = get_member_details(caregiverRequestData['CarereceiverUUID'],memberMappingData['cognitoId'])
                
                if memberData is not None:
                    #update caregiver data with carereeciver details and update it in member table
                    careReceiverData['FirstName'] = memberData['FirstName']
                    careReceiverData['LastName'] = memberData['LastName']
                    careReceiverData['EmailAddress'] = memberData['EmailAddress']
                    careReceiverData['PhoneNumber'] = ''
                    careReceiverData['DateOfBirth'] = ''
                    careReceiverMappingList.append(careReceiverData)

    #update carereceiver and caregiver member data with it
    
    if len(careReceiverMappingList) > 0 :
        
        memberMappingTable.update_item(
                Key={'uuid': caregiverMemberUUID},
                UpdateExpression="SET #carereceiverMappingList = list_append(if_not_exists(#carereceiverMappingList,:emptyList), :carereceiverData)",
                ExpressionAttributeNames={"#carereceiverMappingList": "CarereceiverMappingList"},
                ExpressionAttributeValues={
                    ":carereceiverData": careReceiverMappingList,
                    ":emptyList":[]
                },
                ReturnValues="UPDATED_NEW"
                )


def fetch_caregiver_request_data(memberUUID,requestTypeListAttribute,caregiverRequestUUID):
    memberMappingItems = memberMappingTable.get_item(Key={'uuid': memberUUID})
    if memberMappingItems is None or memberMappingItems.get("Item") is  None or len(memberMappingItems.get("Item")) == 0:
        return None
            
    memberData = memberMappingItems.get("Item")
    attributeListData = memberData.get(requestTypeListAttribute)

    if attributeListData is None or len(attributeListData) == 0:
        return None
        
    #filter giver caregiver request index
    caregiverRequestDataIndex = [i for i in range(len(attributeListData)) if (attributeListData[i]['CaregiverRequestUUID'] == caregiverRequestUUID and not attributeListData[i].get('IsDeleted',False))] 


    if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
        return None

    caregiverRequestData = attributeListData[caregiverRequestDataIndex[0]]

    return {'memberData':memberData,'caregiverRequestDataIndex':caregiverRequestDataIndex[0],'caregiverRequestData':caregiverRequestData}
    

        
            

def get_member_details(memberUUID,cognitoId):
    memberDetailTable = dynamo.Table(os.environ['MemberDetailsTable'])
    memberDetailResponse = memberDetailTable.query(KeyConditionExpression=Key('uuid').eq(memberUUID))
    if len(memberDetailResponse["Items"]) == 0 or len(memberDetailResponse["Items"]) > 1:
            return None
    memberDetail = memberDetailResponse["Items"][0]
    
    email = get_user_email(cognitoId)

    if email is None:
        return None
    
    memberDetail.update({'EmailAddress':email})
    
    
    return memberDetail

def create_account(bodyData):
    try:
        
        client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
        response = client.sign_up(
           ClientId=os.environ["ClientId"],    
           Username=bodyData["emailAddress"],
           Password = bodyData["password"],
           UserAttributes = [ 
                {"Name": "given_name", "Value": bodyData['firstName']}, 
                {"Name": "family_name", "Value": bodyData['lastName']}, 
                { "Name": "email", "Value": bodyData['emailAddress'] }, 
                { "Name": "phone_number", "Value": bodyData["phoneNumber"] } ],
        )
        
       
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
           return  failure_response(400,'An error has occured while activating account.','')
        else:
            return {'statusCode':200,'cognitoId':response["UserSub"]}

    except client.exceptions.InvalidPasswordException:
        return  failure_response(400,'Invalid password.','An error has occured while activating account.')
    except client.exceptions.UsernameExistsException:
        return  failure_response(400,'Email is already registered.','An error has occured while activating account.')
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return  failure_response(400,'An error has occured while activating account.')
        
   
def create_sf_account(bodyData,memberSFId,relationship):
    sfToken = generateAccessTokenSF()
    phoneNumber = bodyData['phoneNumber'][bodyData['phoneNumber'].startswith('+1') and len('+1'):]

    payload = {
                "memberAccountId": memberSFId, 
                "caregiverAccountId": "",
                "caregiverFirstName": bodyData['firstName'],
                "caregiverLastName": bodyData['lastName'],
                "caregiverRelationship": relationship,
                "caregiverEmail": bodyData['emailAddress'],
                "caregiverPhone": phoneNumber,
                "caregiverDOB": datetime.strptime(bodyData['dateOfBirth'],'%Y-%m-%d').strftime('%m/%d/%Y')
                }
    response = requests.put("https://"+os.environ['SF_API_PREFIX']+"/services/apexrest/caregiver/v1/", data=json.dumps(payload) , headers={
                    'Content-Type': 'application/json', # "application/x-www-form-urlencoded" , #
                    'Authorization': 'Bearer ' + sfToken
                })
    
    
    return response

    

def add_member_data(memberData,cognitoId,sfAccountData):
    #add data in member mapping table
    memberUUID = uuid.uuid4()
  
    memberMappingTable =  dynamo.Table(os.environ['MiddlewareMemberMappingTable']) 
    memberMappingTable.put_item(Item={"uuid" : str(memberUUID),  "ucAccountId" : "NC", "SFAccount" : sfAccountData["caregiverAccountId"], "athenaId" : "NC", "cognitoId": cognitoId})

    #add data in member detail table
    memberDetailTable =  dynamo.Table(os.environ['MemberDetailsTable']) 
    memberDetailTable.put_item(Item=create_member_data(str(memberUUID),memberData))
    memberContactTable = dynamo.Table(os.environ['MemberContactTable'])
    memberContactTable.put_item(Item=create_contact_data(str(memberUUID),memberData))
    
    return str(memberUUID)



def create_member_data(memberUUID,memberData):
    data = {}
    data['uuid']=str(memberUUID)
    data['FirstName'] = str(memberData['firstName'])
    data['LastName'] = str(memberData['lastName'])
    data['DateOfBirth'] = str(memberData['dateOfBirth'])
    data['MemberLifetimeID'] = "NC"
    return data

def create_contact_data(memberUUID,memberData):
    data = {}
    data['uuid']=str(memberUUID)
    data['EmailAddress'] = str(memberData['emailAddress'])
    data['PrimaryNumber'] = str(memberData['phoneNumber'])
    data['MBI'] = "NC"
    return data

def update_caregiver_request(caregiverRequestData,caregiverMemberDataIndex):
      
    
    caregiverRequestTable.put_item(
                   Item= caregiverRequestData
                )
    memberMappingTable.update_item(Key={'uuid': caregiverRequestData['CarereceiverUUID']},
                                   UpdateExpression="set CaregiverMappingList[" + str(caregiverMemberDataIndex) + "] = :caregiverMemberData",
                                   ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                                   ReturnValues="UPDATED_NEW")
  
    
def failure_response(statuCode = 400,message='Error while updating caregiver request.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    }

def get_user_email(cognitoId):
    if cognitoId is None or cognitoId == '':
        return None
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email"],   
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
        
    return response.get("Users")[0].get('Attributes')[0].get("Value",None)
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email"],   
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
        
    return response.get("Users")[0].get('Attributes')[0].get("Value",None)

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
