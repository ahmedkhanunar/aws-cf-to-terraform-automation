import json
import os
import json
from boto3.dynamodb.conditions import Key
from datetime import datetime,timezone
import boto3
from cerberus import Validator
from sf_generate_token import generateAccessTokenSF
import requests
import sys
import traceback

dynamo = boto3.resource('dynamodb')
memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }


caregiverStatusSchema = {
            'status': {
                'type': 'string',
                'required': True,
                'allowed': ['INVITE_ACCEPTED', 'INVITE_REJECTED']

            },
            'careReceiverMemberId': {
                'type': 'string',
                'required': True
            },
            'caregiverRequestId': {
                'type': 'string',
                'required': True
            }
        }
caregiverRequestExpiryInHours = 24


def lambda_handler(event, context):
      
    return update_caregiver_request_status(event) 
    


def update_caregiver_request_status(event):
    try:
        bodyData = json.loads(event.get('body')) if event.get('body') != None else {}
            
        validator = Validator(caregiverStatusSchema,allow_unknown=True)

        if not validator.validate(bodyData):
            return failure_response(400,'invalid body',validator.errors)
        
        # set timestamp
        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds") 
       
        
        memberWithCaregiverRequestData = fetch_caregiver_request_data(bodyData['careReceiverMemberId'],'CaregiverMappingList',bodyData['caregiverRequestId'])

        if memberWithCaregiverRequestData is None:
            return failure_response(404,'Invalid request data.')

        #check request id is valid or not
        memberData = memberWithCaregiverRequestData['memberData']
      
        caregiverRequestDataIndex = memberWithCaregiverRequestData['caregiverRequestDataIndex']

        caregiverRequestData = memberWithCaregiverRequestData['caregiverRequestData']
        # validate link has been already used or not
        if caregiverRequestData.get("IsClicked",False) :
            return failure_response(409,'Request Link has been already used.')
        
        if caregiverRequestData.get("Status",'') != 'INVITE_SENT' :
            return failure_response(404,'Invalid request data.')
            

        #validate time
        dateTimeDifference = datetime.now(timezone.utc)-datetime.fromisoformat(caregiverRequestData["CreatedDate"])
        #check date time difference is less than 24 hours
        if dateTimeDifference is None or dateTimeDifference.total_seconds() < 0 or dateTimeDifference.total_seconds() / 3600 > caregiverRequestExpiryInHours :
            return failure_response(498,'Request Link is expired.')
                

        if bodyData["status"] == "INVITE_REJECTED":
            return reject_request(memberData,caregiverRequestData,caregiverRequestDataIndex,bodyData["status"],dateTimeNow)
            
        else:
            return accept_request(caregiverRequestData,bodyData["status"],dateTimeNow,caregiverRequestDataIndex,bodyData['careReceiverMemberId'],memberData)
            
                            
    except Exception as err:
      exec_info = sys.exc_info()
      ex = ''.join(traceback.format_exception(*exec_info))
      write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))

      return failure_response()


def fetch_caregiver_request_data(memberUUID,requestTypeListAttribute,caregiverRequestUUID):
    memberMappingItems = memberMappingTable.get_item(Key={'uuid': memberUUID})
    if memberMappingItems is None or memberMappingItems.get("Item") is  None or len(memberMappingItems.get("Item")) == 0:
        return None
            
    memberData = memberMappingItems.get("Item")
    attributeListData = memberData.get(requestTypeListAttribute)

    if attributeListData is None or len(attributeListData) == 0:
        return None
        
    #filter giver caregiver request index
    caregiverRequestDataIndex = [i for i in range(len(attributeListData)) if (attributeListData[i]['CaregiverRequestUUID'] == caregiverRequestUUID and not attributeListData[i].get('IsDeleted',False))] 


    if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
        return None

    caregiverRequestData = attributeListData[caregiverRequestDataIndex[0]]

    return {'memberData':memberData,'caregiverRequestDataIndex':caregiverRequestDataIndex[0],'caregiverRequestData':caregiverRequestData}
    
    
            



def get_member_details(memberUUID,cognitoId):
    memberDetailTable = dynamo.Table(os.environ['MemberDetailsTable'])
    memberDetailResponse = memberDetailTable.query(KeyConditionExpression=Key('uuid').eq(memberUUID))
    if len(memberDetailResponse["Items"]) == 0 or len(memberDetailResponse["Items"]) > 1:
            return None
    memberDetail = memberDetailResponse["Items"][0]
    
    email = get_user_email(cognitoId)

    if email is None:
        return None
    
    memberDetail.update({'EmailAddress':email})
    
    
    return memberDetail
    


def send_invite_reject_email(careGiverName,memberDetails):
   client = boto3.client('ses')
   
   url =  os.environ["WebAppUrl"]
   
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Caregiver Invite Declined 
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                    Thank you for sending an invitation to <b>"""+careGiverName+"""</b> to access your Health Portal. 

                                    <br/><br/>Unfortunately, the invite was declined. If you think this was by mistake, you may want to reach out to your caregiver and then <a style="color:#1579D6" href='"""+url+"""' >resend the invite</a>.

                                    <br/><br/>If you have any questions or concerns please feel free to contact your Care Guide at 1-800-558-9922.
                                   
                                        
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                       
									               </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html> """
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"Caregiver Invite Declined",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [memberDetails['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )

def send_invite_accept_email(caregiverRequestData,memberData):
   client = boto3.client('ses')
   
   url =  os.environ["WebAppUrl"]+"/contact-us"
   careGiverName = caregiverRequestData["FirstName"].capitalize()+" "+caregiverRequestData["LastName"][0].capitalize()
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Good News! Your Caregiver Invite Has Been Accepted.
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""+careGiverName+"""</b> has accepted your invite to be a caregiver of your account. They can now see all your health information and assist you in anyway you need. No further action is needed on your part.

                                    <br/><br/>Didn’t send this invite? Please <a href='"""+url+"""' style="color:#1579D6">contact support</a> immediately or call 1(800) 558-9922.
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>   """
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"Good News! Your Caregiver Invite Has Been Accepted.",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [memberData['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )
   

def create_sf_account(bodyData,caregiverAccountId):
    
    sfToken = generateAccessTokenSF()
   
    
    payload = {
                "memberAccountId": bodyData['CarereceiverSFId'], 
                "caregiverAccountId": caregiverAccountId,
                "caregiverFirstName": bodyData['FirstName'],
                "caregiverLastName": bodyData['LastName'],
                "caregiverRelationship": bodyData['Relationship'],
                "caregiverEmail": bodyData['EmailAddress'],
                "caregiverPhone": bodyData['PhoneNumber'],
                "caregiverDOB": ""
                }
    
    response = requests.put("https://"+os.environ['SF_API_PREFIX']+"/services/apexrest/caregiver/v1/", data=json.dumps(payload) , headers={
                    'Content-Type': 'application/json', # "application/x-www-form-urlencoded" , #
                    'Authorization': 'Bearer ' + sfToken
                })
    
    
    return response

def get_member_maping_data(cognitoId):
    memberMappingTable = dynamo.Table(os.environ['MiddlewareMemberMappingTable'])
    memberMappingResponse = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognitoId))
    if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
        return None

    return memberMappingResponse["Items"][0]


def reject_request(memberData,caregiverRequestData,caregiverRequestDataIndex,status,dateTimeNow):
    memberDetails = get_member_details(memberData["uuid"],memberData["cognitoId"])
    if memberDetails is not None:
        send_invite_reject_email(caregiverRequestData["FirstName"].capitalize()+' '+caregiverRequestData["LastName"].capitalize(),memberDetails)
    caregiverRequestData['Status'] = str(status)
    caregiverRequestData['UpdatedDate'] = dateTimeNow
    caregiverRequestData['IsClicked'] = True
    memberMappingTable.update_item(Key={'uuid': memberData["uuid"]},
                      UpdateExpression="set CaregiverMappingList[" + str(caregiverRequestDataIndex) + "] = :caregiverMemberData",
                      ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                      ReturnValues="UPDATED_NEW")
    
    if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
        update_care_receiver_data(caregiverRequestData.get('CaregiverUUID'),caregiverRequestData.get('CaregiverRequestUUID'),{"Status":status,"UpdatedDate":dateTimeNow,"IsClicked":True})
    
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
    caregiverRequestTable.put_item(Item = caregiverRequestData)
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!'}),
        'headers': headers
        }
        

def update_care_receiver_data(memberId,caregiverRequestUUID,updatedData):
    memberWithCarereceiverRequestData = fetch_caregiver_request_data(memberId,'CarereceiverMappingList',caregiverRequestUUID)
    
    if memberWithCarereceiverRequestData is None:
        return failure_response(404,'Invalid request data.')
      
    carereceiverRequestDataIndex = memberWithCarereceiverRequestData['caregiverRequestDataIndex']

    carereceiverRequestData = memberWithCarereceiverRequestData['caregiverRequestData']
    carereceiverRequestData.update(updatedData)
    memberMappingTable.update_item(Key={'uuid': memberId},
                      UpdateExpression="set CarereceiverMappingList[" + str(carereceiverRequestDataIndex) + "] = :carereceiverMemberData",
                      ExpressionAttributeValues={':carereceiverMemberData': carereceiverRequestData},
                      ReturnValues="UPDATED_NEW")
        

    

def accept_request(caregiverRequestData,status,dateTimeNow,caregiverMemberDataIndex,careReceiverMemberId,memberData):
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    emailAddress = caregiverRequestData.get("EmailAddress")
    response = client.list_users (
        UserPoolId=os.environ["UserPoolId"], 
        AttributesToGet= ["email"],   
        Limit=1,
        Filter = f"email = \"{emailAddress}\""
        )
        
                    
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
        return failure_response()
                    
    #get user data with mapping ids and update care giver request table
    if response.get("Users") is None or len(response.get("Users")) == 0 :
        return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status will update after activation!','relationShipCreated':False}),
        'headers': headers
        }

    caregiverCognitoId = response.get("Users")[0].get("Username")
    caregiverMemberMappingData = get_member_maping_data(caregiverCognitoId)
                            
    if caregiverMemberMappingData is None :
        return failure_response()
                
    sfCreateAccountRes = create_sf_account(caregiverRequestData,caregiverMemberMappingData['SFAccount'])
    if sfCreateAccountRes.status_code != 200 :
        return failure_response()
            
    sfCaregiverAccount = sfCreateAccountRes.json()
    caregiverRequestData['Status'] = 'ACTIVE'
    caregiverRequestData['UpdatedDate'] = dateTimeNow
    caregiverRequestData['IsClicked'] = True
    caregiverRequestData['CaregiverUUID'] = caregiverMemberMappingData['uuid']
    caregiverRequestData['CaregiverSFId'] = caregiverMemberMappingData['SFAccount']
    caregiverRequestData['RelationshipSFId'] = sfCaregiverAccount["memberCaregiverRelationId"]



    memberMappingTable.update_item(Key={'uuid': careReceiverMemberId},
                                   UpdateExpression="set CaregiverMappingList[" + str(caregiverMemberDataIndex) + "] = :caregiverMemberData",
                                   ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                                   ReturnValues="UPDATED_NEW")
    
    update_care_receiver_data(caregiverMemberMappingData['uuid'],caregiverRequestData['CaregiverRequestUUID'],{"Status":'ACTIVE',"UpdatedDate":dateTimeNow,"IsClicked":True,"RelationshipSFId":sfCaregiverAccount["memberCaregiverRelationId"]})
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
    caregiverRequestTable.put_item(Item = caregiverRequestData)
    memberDetails = get_member_details(careReceiverMemberId,memberData['cognitoId'])
    if memberDetails is not None:
        send_invite_accept_email(caregiverRequestData,memberDetails)

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!','relationShipCreated':True}),
        'headers': headers
        }



def failure_response(statuCode = 400,message='Error while updating caregiver request.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    } 

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
def get_user_email(cognitoId):
    if cognitoId is None or cognitoId == '':
        return None
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email"],   
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
        
    return response.get("Users")[0].get('Attributes')[0].get("Value",None)
