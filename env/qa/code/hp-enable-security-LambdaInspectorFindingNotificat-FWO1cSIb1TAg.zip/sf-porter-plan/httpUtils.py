from auth import client_authentication 
from auth import get_auth_header
from auth import generate_access_token_sf
import urllib.parse
import json
import os
import urllib3
import base64


def request(route, method, payload, scope, connection, event, customHeader,isSFConnection = False):
    
    if isSFConnection:
        auth_response = generate_access_token_sf()
    else:
        auth_response = client_authentication(scope, payload.get('cognitoId', ""))
        
        
    if auth_response['statusCode']  != 200:
            return auth_response
    header = get_auth_header(auth_response['token'])

    
    
    for key in customHeader:
        header[key] = customHeader[key]
    
   
    if method != 'PUT' and method != 'PATCH':
        connection.request(method, route, urllib.parse.urlencode(payload.get('data') or {}), headers=header)
    else:
        connection.request(method, route, json.dumps(payload.get('data') or {}), headers=header)
        
        

    res = connection.getresponse()
    json_response = json.loads(res.read())
    
    return {
        'statusCode': res.status,
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        'body' : json.dumps(json_response)
    } 

def not_found(action, message = ''):
    return { 
        "statusCode": 404,
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        "body": json.dumps({ "error": message or f"The provided api call, {action}, was not found or is not configured.", "status": 404})
    }
