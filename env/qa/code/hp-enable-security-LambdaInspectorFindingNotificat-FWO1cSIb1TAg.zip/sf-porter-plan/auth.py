import json
import os
import http
import math 
import urllib.parse
from base64 import b64encode
from boto3.dynamodb.conditions import Key
import time
import boto3
from datetime import datetime, timedelta
import hashlib
import uuid
#import cryptography
import requests
#from cryptography.fernet import Fernet
#from cryptography.fernet import Fernet
import jwt
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs
dynamodb = boto3.resource("dynamodb")

def basic_auth(username, password):
    token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
    return f'Basic {token}'
    
def get_secret():
    secretId = os.environ["ATHENA_ID"]
    region_name = os.environ["REGION"]

    session = boto3.session.Session()
    
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )
    
    session_token = client.get_secret_value(
        SecretId=secretId
    )
    
    return json.loads(session_token["SecretString"]).get(secretId, "")
    
def create_user_session_token(member,cognito_id, token, expires_in): 
    now = datetime.now()
    expires = now + timedelta(seconds=int(expires_in))

    member["token_created"] = datetime.strftime(now, "%Y-%m-%d %H:%M:%S")
    member["cognitoId"] = cognito_id
    member["expires_on"] = datetime.strftime(expires, "%Y-%m-%d %H:%M:%S")
    member["token"] = token
    
    table = dynamodb.Table(os.environ["CognitoUserSessionTable"])
    table.put_item(Item=member)

def get_user_session_member(cognito_id):
    default_member = { 'cognitoId': '', 'expires_on': None, 'token_created': '', 'token': ''}

        
    table = dynamodb.Table(os.environ["CognitoUserSessionTable"])
    member_search = table.query(KeyConditionExpression=Key('cognitoId').eq(cognito_id))
    
    if len(member_search["Items"]) == 0:
        return default_member
    
        
    return member_search["Items"][0]
    
def is_member_token_expired(member):
    if member.get("expires_on",None) == None:
        return True
    
    if datetime.strptime(member.get("expires_on", ""), "%Y-%m-%d %H:%M:%S") <= datetime.now():
        return True
        
    return False
    
def is_token_expired(data):
    if data.get("expires_on",None) == None:
        return True
    
    if datetime.strptime(data.get("expires_on", ""), "%Y-%m-%d %H:%M:%S") <= datetime.now():
        return True
        
    return False
    
def get_api_token(auth_path, params, headers, cognitoId, auth_connection):
    try:
        secretId = os.environ["API_TOKEN_ID"]
        region_name = os.environ["REGION"]
    
        session = boto3.session.Session()
        
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name,
        )
        
        session_token = client.get_secret_value(
            SecretId=secretId
        )
        
        stored_secret = json.loads(session_token["SecretString"])
        now = datetime.now()
        
        try:
            token_data = json.loads(json.dumps(stored_secret))
        except Exception as e:
            token_data = {
                "access_token": "",
                "expires_in": "",
                "expires_on": datetime.strftime(now, "%Y-%m-%d %H:%M:%S"),
                "created_on": datetime.strftime(now, "%Y-%m-%d %H:%M:%S") 
            }
        

        #check if token is expired
        if is_token_expired(token_data):
            response = get_athena_api_token(auth_path, params, headers, auth_connection)

            if response["statusCode"] != 200:
                return response
        
            put_secret_response = client.put_secret_value(
                SecretId=secretId,
                ClientRequestToken=str(uuid.uuid4()),
                SecretString=json.dumps(response["response"]),
            )
            
            if put_secret_response["ResponseMetadata"]['HTTPStatusCode'] != 200:
                return {
                  'statusCode': put_secret_response["ResponseMetadata"]['HTTPStatusCode'],
                  'reason': "",
                  'token' : ""
                } 
            
            return {
              'statusCode': 200,
              'reason': "",
              'token' : response["response"].get("access_token", "")
            } 
        
        return {
          'statusCode': 200,
          'reason': "",
          'token' : token_data["access_token"]
        } 
    except Exception as e:
        write_excpetion_to_sqs({"Exception": "Secrest Manager Excpetion, reverting to session fallback", "Date": datetime.now(), "User": cognitoId})
        if cognitoId == "" or cognitoId == None:
            return {
                "statusCode": 401,
                "reason": "Not Authorized",
                "token": ""
            }
        
        token = ''
        member = get_user_session_member(cognitoId)
                    
        secretId = os.environ["SESSION_SECRET_ID"]
        region_name = os.environ["REGION"]
    
        session = boto3.session.Session()
        
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name,
        )
        
        session_token = client.get_secret_value(
            SecretId=secretId
        )
    
        if is_member_token_expired(member):
            response = get_athena_api_token(auth_path, params, headers, auth_connection)
            
            if response["statusCode"] != 200:
                return response
            
            token = response["response"].get("access_token", "")
            
            stored_secret = json.loads(session_token["SecretString"]).get("SecretString", "")
            encoded_token = jwt.encode({ "token": token}, stored_secret, algorithm="HS256")
            
            create_user_session_token(member, cognitoId, encoded_token,response["response"].get("expires_in", "") )
        else:
            stored = encoded_token = jwt.decode(member["token"], stored_secret, algorithm="HS256")
            return stored["token"]
        
        return {
          'statusCode': 200,
          'reason': "",
          'token' : token
        } 


def client_authentication(scope, cognitoId):
    #DSTU4 and athena scope: 'athena/service/Athenanet.MDP.*'
    #R4 Scope: depends on request
    #get_api_token()
    auth_host = os.environ['EHR_AUTH_URL']
    auth_path =  '/oauth2/v1/token'
  
    clientId = os.environ['EHR_CLIENT_ID']
    secret = get_secret()
   
    auth_data = {
       'grant_type': 'client_credentials',
       'scope': scope,
    };
   
    params = urllib.parse.urlencode(auth_data)
       
    auth_connection = http.client.HTTPSConnection(auth_host)
   
    headers = { 
       'Authorization' : basic_auth(clientId, secret),
       'content-type': "application/x-www-form-urlencoded"
    }
      
    response = get_api_token(auth_path, params, headers, cognitoId, auth_connection)
        
    if response.get("statusCode", 500) != 200:
        return response
        
    token = response.get("token", "")
        
  #  member = get_user_session_member(cognitoId)
   # token = ''
    
    #if is_token_expired(member):
     #   response = get_athena_api_token(auth_path, params, headers, auth_connection)
        
      #  if response.get("statusCode", 500) != 200:
       #     return response
            
        #token = response.get("token", "")
        #create_user_session_token(member, cognitoId, token,response.get("expires_in", "") )
    #else:
     #   token = member["token"]
    
    return {
      'statusCode': 200,
      'reason': "",
      'token' : token
    }      

def get_athena_api_token(auth_path, params, headers, auth_connection):
    auth_connection.request('POST', auth_path, params, headers)

    res = auth_connection.getresponse()
    json_response = json.loads(res.read())

    if res.status != 200:
        return {
            'statusCode': res.status,
            'reason': res.reason,  
            'body': json.dumps(json_response)
         }
    
    token = json_response["access_token"]
    expires_in = json_response["expires_in"]
    
    now = datetime.now()
    expires = now + timedelta(seconds=int(expires_in))
    
    json_response["expires_on"] = datetime.strftime(expires, "%Y-%m-%d %H:%M:%S")
    json_response["created"] = datetime.strftime(now, "%Y-%m-%d %H:%M:%S")
    
    return {
      'statusCode': 200,
      'reason': "",
      'response': json_response
    }      

def get_auth_header(token):
    return { 
       'Authorization' : f'Bearer {token}'
    }


def get_sf_secrets():
    secretId = os.environ["SF_SECRETS_NAME"]
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=os.environ["REGION"],
    )
    session_token = client.get_secret_value(
        SecretId=secretId
    )
    return json.loads(session_token["SecretString"])

def generate_access_token_sf(): 
    try:
        secrets = get_sf_secrets()
        claimSet = { "iss": secrets['SF_ISSUER'], "aud": "https://"+secrets['SF_HOST']+"/services/oauth2/token", "sub": secrets['SF_SUBJECT'], "exp": math.floor(int(datetime.now().timestamp()) + (3 * 600)) } 
        jwtToken = jwt.encode(claimSet, secrets["SF_PRIVATE_KEY"].replace("\\n", "\n"), algorithm='RS256') 
        headers = { 'Accept-Encoding': 'gzip', 'Content-Type': 'application/x-www-form-urlencoded' } 
        params = { "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": jwtToken } 
        response = requests.post("https://"+secrets['SF_HOST']+ "/services/oauth2/token", data=params , headers=headers) 
        response = response.text 
        jsonResponse = json.loads(response)
        return {
            "statusCode": 200,
            "token": jsonResponse['access_token'] 
        } 
    except Exception as e:
        
        write_excpetion_to_sqs(json.dumps({"Exception": str(e), "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            "statusCode": 500,
            "error": "Failed to generate access token",
            "token": ""
        }
