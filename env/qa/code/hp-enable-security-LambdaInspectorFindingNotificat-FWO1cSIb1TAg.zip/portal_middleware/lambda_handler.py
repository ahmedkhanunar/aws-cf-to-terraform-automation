from httpUtils import not_found
from patient import lambda_handler as patient_api_handler
from caregiver import lambda_handler as caregiver_api_handler
from learn_favorites import lambda_handler as learn_api_handler
from profile import lambda_handler as profile_handler
from mybenefits import get_my_benefits as my_benefit_handler
import json
import boto3
from boto3.dynamodb.conditions import Key
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs
from datetime import datetime
import traceback
import sys
import os

dynamodb = boto3.resource("dynamodb")

headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def lambda_handler(event, context):
    try:
        
        payload = event.get('body','{}')
        path = event.get('path').rsplit('/', 1)[-1]
        
        if payload != None:
            method = json.loads(payload).get('httpMethod', event.get('httpMethod'))
        else:
            payload = '{}'
            method = event.get('httpMethod')
        
        if json.loads(payload).get('bypass', "") != 'yes':
        # method = payload["httpMethod"] or event.get("httpMethod")
            claims = event['requestContext']['authorizer']['claims']
            if claims.get('username'):
                cognito_id = claims['username']
                userData = get_user_data(cognito_id,payload)
                payload = userData['payload']
                parsedPayload = json.loads(payload)
                parsedPayload['cognitoId'] = cognito_id
                payload = json.dumps(parsedPayload)
                userUUID =  userData['id']
                
            
            # validate carereceiver data for caregiver view
            carereceiverId = json.loads(payload).get('carereceiverId', "")
            if carereceiverId != '':
                table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
                carereceiverResponse = table.query( KeyConditionExpression=Key('uuid').eq(carereceiverId))
                if len(carereceiverResponse["Items"]) == 0:
                    return failure_response(403,"Access denied.",'')
                    
                    
                caregiverMappingItems = carereceiverResponse["Items"][0]["CaregiverMappingList"]
                
                if caregiverMappingItems is  None or len(caregiverMappingItems) == 0:
                    return failure_response(403,"Access denied.",'')
                
                caregiverRequestDataIndex = [i for i in range(len(caregiverMappingItems)) if caregiverMappingItems[i]['CaregiverUUID'] == userUUID] 

                
                if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
                    return failure_response(403,"Access denied.",'')
                
                caregiverRequestData = caregiverMappingItems[caregiverRequestDataIndex[0]]
                

                if caregiverRequestData.get("EnableAccess",False) != True or caregiverRequestData.get("Status","") != "ACTIVE":
                    return failure_response(403,"Access denied.",'')
                
                userData = get_user_data(carereceiverResponse["Items"][0]['cognitoId'],payload)

                payload =  userData['payload']
                
        action = get_action(method,path)
        
        
        if action:
            event['method'] = method
            event['payload'] = payload
            event['action'] = action
            if path == "learn-favorite":
                data = learn_api_handler(event,context)
            elif path == 'my-benefits':
                data = my_benefit_handler(event,context)
            elif path == 'update-password' or path == 'user-profile' or path == 'update-user-profile':
                data = profile_handler(event, context)
            elif path == 'caregivers' or path == 'my-caregivers' or path == 'caregiver-status' or path == 'my-carereceivers' or path == 'caregiver-request-status':
                data = caregiver_api_handler(event, context)
            else: 
                data = patient_api_handler(event,context) 
            return data
        else:
            return not_found('', f'The provided request method, {method} is not supported') 
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return failure_response()
    
    
    
def get_user_data(cognito_id,payload):
    
    parsed_payload = json.loads(payload)
    table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
    response = table.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))
    account_data = {}
    if(response["Items"]):
        account_data = response["Items"][0]

    md_table = dynamodb.Table(os.environ['MemberDetailsTable'])
    #md_response = md_table.query(IndexName='ClientMemberId-index',KeyConditionExpression=Key('ClientMemberID').eq(account_data['ClientMemberId']))
    uuid = account_data.get("uuid", "")
    md_response = md_table.query(KeyConditionExpression=Key('uuid').eq(uuid))

    md_data = {}
   
    if(md_response["Items"]):
        md_data = md_response["Items"][0]

    if account_data:
        parsed_payload['salesForceAccount'] = account_data.get("SFAccount","")
        #parsed_payload['patientId'] = ""#account_data.get("athenaId","") 
        parsed_payload['patientId'] = account_data.get("athenaId","")
        parsed_payload['departmentId'] = account_data.get("departmentId",-1)

    if md_data:
        parsed_payload['contract_id'] = md_data.get("CMSNumber","") 
        
    data = {}
    data["payload"] = json.dumps(parsed_payload)
    data["id"] = uuid
    return data
   


def get_action(method,path):
    if method == 'GET':
        return get_method_actions(path)
    elif method == 'POST':
        return post_method_actions(path)
    elif method == 'PUT':   
        return put_method_actions(path)
    elif method == 'DELETE':   
        return delete_method_actions(path)


def get_method_actions(path):
    if path == 'patient':
        return 'GetPatient'
    elif path == 'appointments':
        return 'GetPatientAppointments'
    elif path == 'appointment-detail':
        return 'GetPatientAppointment'
    elif path == 'visits':
        return 'GetPatientVisits'
    elif path == 'visit-notes':
        return 'GetPatientVisitNotes'
    elif path == 'insurances':
        return 'GetPatientInsurances'
    elif path == 'encounters':
        return 'GetPatientEncounters'
    elif path == 'encounter-detail':
        return 'GetPatientEncounter'
    elif path == 'medications':
        return 'GetPatientMedications'
    elif path == 'medications':
        return 'GetPatientMedications'
    elif path == 'learn-favorite':
        return 'GetLearnFavorite'
    elif path == 'create-pcp':
        return 'CreatePCP'
    elif path == 'medical-reports':
        return "GetPatientMedicalReports"
    elif path == 'report':
        return "GetPatientReport"
    elif path == 'visit-charts':
        return "GetPatientVisitCharts"
    elif path == 'visit-chart':
        return "GetPatientVisitChart"
    elif path == 'follow-ups':
        return "GetPatientFollowUps"
    elif path == 'user-profile':
        return 'GetUserProfile'
    elif path == 'resource-recommendations':
        return 'GetResourceRecommendations'
    elif path == 'my-benefits':
        return 'GetMyBenefit'
    elif path == 'my-caregivers':
        return 'GetMyCaregivers'
    elif path == 'my-carereceivers':
        return 'GetMyCarereceivers'
    else:
        return None
    
def post_method_actions(path):
    if path == 'patient':
        return 'CreatePatient'
    elif path == 'learn-favorite':
        return 'AddLearnFavorite'
    elif path == 'medications':
        return 'GetPatientMedications'
    elif path == 'create-pcp':
        return 'CreatePCP'
    elif path == 'porter-plan':
        return 'GetPatientPorterPlan'
    elif path == 'caregivers':
        return 'AddCaregiver'
    elif path == 'caregiver-status':
        return 'UpdateCaregiverStatus'
    elif path == 'caregiver-request-status':
        return 'UpdateCaregiverRequestStatus'
    elif path == 'update-user-profile':
        return 'UpdateUserProfile'
    
    else:
        return None
    
def put_method_actions(path):
    if path == 'patient':
        return 'UpdatePatient'
    elif path == 'update-password':
        return 'UpdatePassword' 
    elif path == 'resource-recommendations':
        return 'UpdateResourceRecommendations' 
    elif path == 'follow-ups':
        return 'UpdateFollowUps' 
    else:
        return None
    
def delete_method_actions(path):
    if path == 'learn-favorite':
        return 'DeleteLearnFavorite'
    else:
        return None
    
def failure_response(statuCode = 400,message='Error while processing request.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    } 