import json
import os
import json
from httpUtils import not_found, request
from datetime import datetime,timezone
import uuid
import boto3
from cerberus import Validator
from boto3.dynamodb.conditions import Key
import http
import sys
import traceback
import requests
from auth import generate_access_token_sf

dynamo = boto3.resource('dynamodb')
caregiverRequestExpiryInHours = 24

memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

caregiverSchema = {
            'firstName': {
                'type': 'string',
                'required': True
            },
            'lastName': {
                'type': 'string',
                'required': True
            },
            'emailAddress': {
                'type': 'string',
                'required': True,
                'regex': r'^([A-Za-z0-9_\-\+\.])+\@([A-Za-z0-9_\-\+\.])+\.([A-Za-z]{2,4})$'
            },
            'phoneNumber': {
                'type': 'string',
                'required': False
                #'minlength': 8,
            },
            'relationship': {
                'type': 'string',
                'required': True
            },
            'enableAccess':{
                'type':'boolean',
                'required':True
            }
        }

caregiverStatusSchema = {
            'status': {
                'type': 'string',
                'required': True,
                'allowed': ['ACTIVE', 'INACTIVE','REMOVED','RESEND_INVITE']

            },
            'caregiverRequestId': {
                'type': 'string',
                'required': True
            },
            'notifyCaregiver': {
                'type': 'boolean',
                'required': False
            }
        }
caregiverRequestStatusSchema = {
            'status': {
                'type': 'string',
                'required': True,
                'allowed': ['INVITE_ACCEPTED', 'INVITE_REJECTED','REMOVED']

            },
            'caregiverRequestId': {
                'type': 'string',
                'required': True
            }
        }

def lambda_handler(event, context):
    method = event.get('method')
    
    path = event.get('path').rsplit('/', 1)[-1]
        
    if path == 'caregivers':
        if method == 'POST':
            return add_caregiver(event)
    elif path == 'my-caregivers':
        if method == 'GET':
            return get_caregivers(event)
    elif path == 'my-carereceivers':
        if method == 'GET':
            return get_carereceivers(event)
    elif path == 'caregiver-status':
        if method == 'POST':
            return update_caregiver_status(event)
    elif path == 'caregiver-request-status':
        if method == 'POST':
            return update_caregiver_request_status(event)
        
   
     
     
    return not_found('', f'The provided request method, {method} is not supported for request ') 




def add_caregiver(event):
    try:
        
        cognitoId = event['requestContext']['authorizer']['claims']['username']

        
        bodyData = json.loads(event['payload'])
        validator = Validator(caregiverSchema,allow_unknown=True)
       

        if not validator.validate(bodyData):
            return {
                    'statusCode': 400,
                    "headers": headers,
                    'body' : json.dumps({'message':'invalid body','errors': validator.errors})
            } 
        keyMap = {'firstName': 'FirstName', 'lastName': 'LastName','emailAddress':'EmailAddress','relationship':'Relationship','enableAccess':'EnableAccess'}
        careGiverData = {newkey: bodyData[oldkey] for (oldkey, newkey) in keyMap.items()}
        careGiverData['PhoneNumber']= bodyData.get('phoneNumber','')
        careGiverData['Status'] = 'INVITE_SENT'
        careGiverData['IsClicked'] = False
        careGiverData['IsDeleted'] = False

        # set timestamp
        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds")
        careGiverData['CreatedDate'] = dateTimeNow
        careGiverData['UpdatedDate'] = dateTimeNow

        # uuid for request
        careGiverData['CaregiverRequestUUID'] = str(uuid.uuid4())
        # uuid for member from which request is generated
        
        memberData = get_member_data(cognitoId)
        if already_invite_exists(memberData['MemberMapping'],careGiverData['EmailAddress']):
            return failure_response(409,'Caregiver request is already exists for given EmailAddress or already processed.','')
        
        if memberData['MemberDetails']['EmailAddress'].lower() == careGiverData['EmailAddress'].lower():
            return failure_response(404,'You can not add self as caregiver.','')
        
        careGiverData['CarereceiverUUID'] = memberData['MemberMapping']['uuid']
        careGiverData['CarereceiverSFId'] = memberData['MemberMapping']['SFAccount']
        careGiverData['CaregiverUUID'] = ''
        careGiverData['CaregiverSFId'] = ''

        #check if caregiver is already user or not
        client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
        response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email"],   
            Limit=1,
            Filter = f"email = \"{careGiverData['EmailAddress']}\""
            )
                    
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 :
            return failure_response()
                    
           #get user data with mapping ids and update care giver member and care receiver member details
        if len(response.get("Users")) > 0: 
            caregiverCognitoId = response.get("Users")[0].get("Username")
            caregiverMemberData = get_member_data(caregiverCognitoId)
            if caregiverMemberData is None:
                return failure_response()

            careGiverData['CaregiverUUID'] = caregiverMemberData['MemberMapping']['uuid']
            careGiverData['CaregiverSFId'] = caregiverMemberData['MemberMapping']['SFAccount']
            careReceiverData = careGiverData.copy()
            careReceiverData['FirstName'] = memberData['MemberDetails']['FirstName']
            careReceiverData['LastName'] = memberData['MemberDetails']['LastName']
            careReceiverData['EmailAddress'] = memberData['MemberDetails']['EmailAddress']
            careReceiverData['PhoneNumber'] = ''
            careReceiverData['DateOfBirth'] = ''
  
            memberMappingTable.update_item(
                Key={'uuid': caregiverMemberData['MemberMapping']['uuid']},
                UpdateExpression="SET #carereceiverMappingList = list_append(if_not_exists(#carereceiverMappingList,:emptyList), :carereceiverData)",
                ExpressionAttributeNames={"#carereceiverMappingList": "CarereceiverMappingList"},
                ExpressionAttributeValues={
                    ":carereceiverData": [careReceiverData],
                    ":emptyList":[]
                },
                ReturnValues="UPDATED_NEW"
                )
        
        memberMappingTable.update_item(
            Key={'uuid': memberData['MemberMapping']['uuid']},
            UpdateExpression="SET #caregiverMappingList = list_append(if_not_exists(#caregiverMappingList,:emptyList), :caregiverData)",
            ExpressionAttributeNames={"#caregiverMappingList": "CaregiverMappingList"},
            ExpressionAttributeValues={
                ":caregiverData": [careGiverData],
                ":emptyList":[]
            },
            ReturnValues="UPDATED_NEW"
            )
        
        #add data in caregiver request table as caregiver is still not registered and we want to link those requests once user is activated
        
        caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
        caregiverRequestTable.put_item(Item = careGiverData)
            
        
        send_invite_email(careGiverData,memberData["MemberDetails"])
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Caregiver request added successfully!','caregiverRequestId':careGiverData['CaregiverRequestUUID']}),
            'headers': headers
        }
        
    except Exception as err:
        return failure_response()
     

  


def already_invite_exists(memberMappingData,emailAddress):
    if memberMappingData is None or len(memberMappingData.get('CaregiverMappingList',[])) == 0:
        return False
    
    existingCaregiverMappingList = memberMappingData.get('CaregiverMappingList')
    caregiverRequestDataIndex = [i for i in range(len(existingCaregiverMappingList)) if (existingCaregiverMappingList[i]['EmailAddress'] == emailAddress and not existingCaregiverMappingList[i].get('IsDeleted',False))] 
    if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
        return False
    
    caregiverRequestData = existingCaregiverMappingList[caregiverRequestDataIndex[0]]

    if caregiverRequestData.get('Status','') == 'REMOVED':
        return False
    
    return True


def get_member_data(id):
   memberMappingResponse = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(id))
   
       
   if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
        return None
   
   memberDetailResponse = get_member_details(memberMappingResponse["Items"][0]["uuid"],memberMappingResponse["Items"][0]["cognitoId"])
   
   if memberDetailResponse is None:
       return None
   
   response = {}
   response['MemberDetails']= memberDetailResponse
   response['MemberMapping']= memberMappingResponse["Items"][0]
   return response

def get_member_details(memberUUID,cognitoId):
    memberDetailTable = dynamo.Table(os.environ['MemberDetailsTable'])
    memberDetailResponse = memberDetailTable.query(KeyConditionExpression=Key('uuid').eq(memberUUID))
    if len(memberDetailResponse["Items"]) == 0 or len(memberDetailResponse["Items"]) > 1:
            return None
    memberDetail = memberDetailResponse["Items"][0]
    
    email = get_user_email(cognitoId)

    if email is None:
        return None
    
    memberDetail.update({'EmailAddress':email})
    
    return memberDetail

def send_invite_email(bodyData,memberData):
   client = boto3.client('ses')
   requester_name = memberData["FirstName"].capitalize() + " " + memberData["LastName"][0].capitalize()
   accept_url =  os.environ["WebAppUrl"]+"/"+bodyData['CarereceiverUUID']+"/caregiver/"+bodyData['CaregiverRequestUUID']+"/?status=INVITE_ACCEPTED&name="+requester_name
   reject_url =  os.environ["WebAppUrl"]+"/"+bodyData['CarereceiverUUID']+"/caregiver/"+bodyData['CaregiverRequestUUID']+"/?status=INVITE_REJECTED&name="+requester_name 
   
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      """+ memberData["FirstName"].capitalize()+""" Has Invited You to be Their Caregiver on Porter!
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""+requester_name+""".</b> has invited you to be their caregiver on Porter. This means you’ll be able to view and assist with appointments, visit notes, medical reports and much more! Click the button below to accept the invite and create your account.
                                        <br/><br/>If you received this email by mistake, please ignore it and delete the email. 
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                        <a style="font-weight: normal; text-align: center; background:#726F81; color: #fff; padding: 16px 32px;margin-right:20px; border-radius: 100px;" href='"""+reject_url+"""' class="btn org">Decline</a>
									<a style="font-weight: normal; text-align: center; background:#ED7100; color: #fff; padding: 16px 32px; border-radius: 100px;" href='"""+accept_url+"""' class="btn org">Accept Invite</a>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>"""
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': memberData["FirstName"].capitalize()+ " Has Invited You to be Their Caregiver on Porter!",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [bodyData['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )
   
def failure_response(statuCode = 400,message='Error while adding caregiver request.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    }

def get_caregivers(event):
    cognitoId = event['requestContext']['authorizer']['claims']['username']

    try:
        memberData = get_member_data(cognitoId)
        if memberData is None:
            return failure_response(404,'Invalid account id','')
        
        caregiverList = memberData['MemberMapping'].get('CaregiverMappingList',[])
        filteredList = []
        for caregiver in caregiverList:
            #validate time
            dateTimeDifference = datetime.now(timezone.utc)-datetime.fromisoformat(caregiver["CreatedDate"])
            #check date time difference is less than 24 hours
            if (dateTimeDifference is None or dateTimeDifference.total_seconds() < 0 or dateTimeDifference.total_seconds() / 3600 > caregiverRequestExpiryInHours) and caregiver['Status'] == "INVITE_SENT" :
                caregiver['Status'] = 'INVITE_EXPIRED'
            if caregiver['Status'] != 'REMOVED' and not caregiver.get('IsDeleted',False):
                filteredList.append(caregiver)
            
        
        filteredList = sorted(filteredList, key=lambda x: datetime.fromisoformat(f"{x['CreatedDate']}"),reverse=True)
        return {
            'statusCode': 200,
            'body': json.dumps({'data':filteredList }),
            'headers': headers
        }
    except Exception as err:
        return failure_response(400,'Error while getting care giver data','')
    
def get_carereceivers(event):
    cognitoId = event['requestContext']['authorizer']['claims']['username']

    try:
        memberData = get_member_data(cognitoId)
        if memberData is None:
            return failure_response(404,'Invalid account id','')
        carereceiverList = memberData['MemberMapping'].get('CarereceiverMappingList',[])
        filteredList = []
        for carereceiver in carereceiverList:
            #validate time
            dateTimeDifference = datetime.now(timezone.utc)-datetime.fromisoformat(carereceiver["CreatedDate"])
            #check date time difference is less than 24 hours
            if (dateTimeDifference is None or dateTimeDifference.total_seconds() < 0 or dateTimeDifference.total_seconds() / 3600 > caregiverRequestExpiryInHours) and  carereceiver['Status'] == "INVITE_SENT":
                carereceiver['Status'] = 'INVITE_EXPIRED'
            if carereceiver['Status'] != 'INVITE_EXPIRED' and carereceiver['Status'] != 'INVITE_REJECTED' and not carereceiver.get('IsDeleted',False):
                filteredList.append(carereceiver)
                
        return {
            'statusCode': 200,
            'body': json.dumps({'data':filteredList}),
            'headers': headers
        }
    except Exception as err:
        return failure_response(400,'Error while getting care giver data','')

def update_caregiver_request_status(event):
    try:
        cognitoId = event['requestContext']['authorizer']['claims']['username']

        
        bodyData = json.loads(event['payload'])
        validator = Validator(caregiverRequestStatusSchema,allow_unknown=True)
       

      
        if not validator.validate(bodyData):
            return failure_response(400,'invalid body',validator.errors)
        
        # set timestamp
        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds") 
       
        
        memberWithCarereceiverRequestData = fetch_caregiver_request_data(cognitoId,'CarereceiverMappingList',bodyData['caregiverRequestId'],True)

        if memberWithCarereceiverRequestData is None:
            return failure_response(404,'Invalid request data.')
        if bodyData["status"] != 'REMOVED' and memberWithCarereceiverRequestData['caregiverRequestData']['Status'] != 'INVITE_SENT':
            return failure_response(404,'Invalid request.You can only accept or reject pending request.')
        
        memberWithCaregiverRequestData = fetch_caregiver_request_data(memberWithCarereceiverRequestData['caregiverRequestData']['CarereceiverUUID'],'CaregiverMappingList',bodyData['caregiverRequestId'],False)


        if memberWithCaregiverRequestData is None:
            return failure_response(404,'Invalid request data.')

        #check request id is valid or not
        memberData = memberWithCaregiverRequestData['memberData']
        caregiverRequestDataIndex = memberWithCaregiverRequestData['caregiverRequestDataIndex']

        caregiverRequestData = memberWithCaregiverRequestData['caregiverRequestData']
  
        if bodyData["status"] == "INVITE_REJECTED":
            return reject_request(memberData,caregiverRequestData,caregiverRequestDataIndex,bodyData["status"],dateTimeNow)
        elif bodyData["status"] == "INVITE_ACCEPTED":
            return accept_request(caregiverRequestData,'ACTIVE',dateTimeNow,caregiverRequestDataIndex,caregiverRequestData['CarereceiverUUID'],memberData)
        else:
            return delete_request(memberWithCarereceiverRequestData,memberWithCaregiverRequestData)
            
                  
                            
    except Exception as err:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        return failure_response(400,'Error while updating caregiver request status.',error=str(ex))
    
def delete_request(memberWithCarereceiverRequestData,memberWithCaregiverRequestData):
    dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds") 


    #update carereciver CaregiverMappingList data
    caregiverRequestData = memberWithCaregiverRequestData['caregiverRequestData']
    caregiverRequestData['UpdatedDate'] = dateTimeNow
    caregiverRequestData['IsDeleted'] = True
    memberMappingTable.update_item(Key={'uuid': memberWithCaregiverRequestData['memberData']['uuid']},
                                   UpdateExpression="set CaregiverMappingList[" + str(memberWithCaregiverRequestData['caregiverRequestDataIndex']) + "] = :caregiverMemberData",
                                   ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                                   ReturnValues="UPDATED_NEW")
    
    #update caregiver carereceiverMemberData data
    carereceiverRequestData = memberWithCarereceiverRequestData['caregiverRequestData']
    carereceiverRequestData['UpdatedDate'] = dateTimeNow
    carereceiverRequestData['IsDeleted'] = True
    
    
    memberMappingTable.update_item(Key={'uuid': memberWithCarereceiverRequestData['memberData']['uuid']},
                                       UpdateExpression="set CarereceiverMappingList[" + str(memberWithCarereceiverRequestData['caregiverRequestDataIndex']) + "] = :carereceiverMemberData",
                                       ExpressionAttributeValues={':carereceiverMemberData': carereceiverRequestData},
                                       ReturnValues="UPDATED_NEW")
    

    #update caregiver request data
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])

    caregiverRequestTable.put_item(Item = caregiverRequestData)
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!','relationShipCreated':True}),
        'headers': headers
        }

    
def accept_request(caregiverRequestData,status,dateTimeNow,caregiverMemberDataIndex,careReceiverMemberId,memberData):
    
                
    sfCreateAccountRes = create_sf_account(caregiverRequestData,caregiverRequestData['CaregiverSFId'])
    if sfCreateAccountRes.status_code != 200 :
        return failure_response()
            
    sfCaregiverAccount = sfCreateAccountRes.json()
    caregiverRequestData['Status'] = 'ACTIVE'
    caregiverRequestData['UpdatedDate'] = dateTimeNow
    caregiverRequestData['IsClicked'] = True
    caregiverRequestData['RelationshipSFId'] = sfCaregiverAccount["memberCaregiverRelationId"]



    memberMappingTable.update_item(Key={'uuid': careReceiverMemberId},
                                   UpdateExpression="set CaregiverMappingList[" + str(caregiverMemberDataIndex) + "] = :caregiverMemberData",
                                   ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                                   ReturnValues="UPDATED_NEW")
    
    update_care_receiver_data(caregiverRequestData['CaregiverUUID'],caregiverRequestData['CaregiverRequestUUID'],{"Status":status,"UpdatedDate":dateTimeNow,"IsClicked":True,"RelationshipSFId":sfCaregiverAccount["memberCaregiverRelationId"]})
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
    caregiverRequestTable.put_item(Item = caregiverRequestData)
    memberDetails = get_member_details(careReceiverMemberId,memberData['cognitoId'])
    if memberDetails is not None:
        send_invite_accept_email(caregiverRequestData,memberDetails)
               
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!','relationShipCreated':True}),
        'headers': headers
        }

def send_invite_accept_email(caregiverRequestData,memberData):
   client = boto3.client('ses')
   
   url =  os.environ["WebAppUrl"]+"/contact-us"
   careGiverName = caregiverRequestData["FirstName"].capitalize()+" "+caregiverRequestData["LastName"][0].capitalize()
   
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Good News! Your Caregiver Invite Has Been Accepted.
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""+careGiverName+"""</b> has accepted your invite to be a caregiver of your account. They can now see all your health information and assist you in anyway you need. No further action is needed on your part.

                                    <br/><br/>Didn’t send this invite? Please <a href='"""+url+"""' style="color:#1579D6">contact support</a> immediately or call 1(800) 558-9922.
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>   """
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"Good News! Your Caregiver Invite Has Been Accepted.",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [memberData['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )
   

def create_sf_account(bodyData,caregiverAccountId):
    
    sfToken = generate_access_token_sf()
   
    
    payload = {
                "memberAccountId": bodyData['CarereceiverSFId'], 
                "caregiverAccountId": caregiverAccountId,
                "caregiverFirstName": bodyData['FirstName'],
                "caregiverLastName": bodyData['LastName'],
                "caregiverRelationship": bodyData['Relationship'],
                "caregiverEmail": bodyData['EmailAddress'],
                "caregiverPhone": bodyData['PhoneNumber'],
                "caregiverDOB": ""
                }
    
    response = requests.put("https://"+os.environ['SF_API_PREFIX']+"/services/apexrest/caregiver/v1/", data=json.dumps(payload) , headers={
                    'Content-Type': 'application/json', # "application/x-www-form-urlencoded" , #
                    'Authorization': 'Bearer ' + sfToken['token']
                })
    
    
    return response


def reject_request(memberData,caregiverRequestData,caregiverRequestDataIndex,status,dateTimeNow):
    memberDetails = get_member_details(memberData["uuid"],memberData['cognitoId'])
    if memberDetails is not None:
        send_invite_reject_email(caregiverRequestData["FirstName"].capitalize()+' '+caregiverRequestData["LastName"].capitalize(),memberDetails)
    caregiverRequestData['Status'] = str(status)
    caregiverRequestData['UpdatedDate'] = dateTimeNow
    caregiverRequestData['IsClicked'] = True
    memberMappingTable.update_item(Key={'uuid': memberData["uuid"]},
                      UpdateExpression="set CaregiverMappingList[" + str(caregiverRequestDataIndex) + "] = :caregiverMemberData",
                      ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                      ReturnValues="UPDATED_NEW")
    
    if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
        update_care_receiver_data(caregiverRequestData.get('CaregiverUUID'),caregiverRequestData.get('CaregiverRequestUUID'),{"Status":status,"UpdatedDate":dateTimeNow,"IsClicked":True})
    
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
    caregiverRequestTable.put_item(Item = caregiverRequestData)
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!'}),
        'headers': headers
        }
        
def send_invite_reject_email(careGiverName,memberDetails):
   client = boto3.client('ses')
   
   url =  os.environ["WebAppUrl"]
   
   body_html = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Caregiver Invite Declined 
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                    Thank you for sending an invitation to <b>"""+careGiverName+"""</b> to access your Health Portal. 

                                    <br/><br/>Unfortunately, the invite was declined. If you think this was by mistake, you may want to reach out to your caregiver and then <a style="color:#1579D6" href='"""+url+"""' >resend the invite</a>.

                                    <br/><br/>If you have any questions or concerns please feel free to contact your Care Guide at 1-800-558-9922.
                                   
                                        
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                       
									               </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>   """
   email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"Caregiver Invite Declined",
        },
    }
   ses_response = client.send_email(
        Destination={
            'ToAddresses': [memberDetails['EmailAddress']],
        },
        Message=email_message,
        Source='no-reply@helloporter.com',
    )
     
def update_caregiver_status(event):
    try:
        cognitoId = event['requestContext']['authorizer']['claims']['username']

        
        bodyData = json.loads(event['payload'])
        validator = Validator(caregiverStatusSchema,allow_unknown=True)
       

      
        if not validator.validate(bodyData):
            return failure_response(400,'invalid body',validator.errors)
        
        # set timestamp
        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds") 
       
        
        memberWithCaregiverRequestData = fetch_caregiver_request_data(cognitoId,'CaregiverMappingList',bodyData['caregiverRequestId'],True)

        if memberWithCaregiverRequestData is None:
            return failure_response(404,'Invalid request data.')


        caregiverRequestDataIndex = memberWithCaregiverRequestData['caregiverRequestDataIndex']

        caregiverRequestData = memberWithCaregiverRequestData['caregiverRequestData']
        memberMappingData = memberWithCaregiverRequestData['memberData']

        #check existing status for RESEND_INVITE
        if bodyData["status"] == "RESEND_INVITE" and not (caregiverRequestData['Status'] == 'INVITE_SENT' or caregiverRequestData['Status'] == 'INVITE_REJECTED'):
            return failure_response(400,'You can resend invite only for pending caregiver invitation.')
 
        if (bodyData["status"] == 'ACTIVE' and caregiverRequestData['Status'] != 'INACTIVE') or (bodyData["status"] == 'INACTIVE' and caregiverRequestData['Status'] != 'ACTIVE'):
            return failure_response(400,'You can not change caregiver request status to provided status.')
         
        if (bodyData["status"] == 'REMOVED' and caregiverRequestData['Status'] == 'REMOVED'):
            return failure_response(400,'You can not remove already removed caregiver request.')
          
        return update_request(caregiverRequestData,bodyData["status"],dateTimeNow,caregiverRequestDataIndex,bodyData.get('notifyCaregiver',False),memberMappingData)
                  
                            
    except Exception as err:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        return failure_response(400,'Error while updating caregiver request.',error=str(ex))
        
  

def fetch_caregiver_request_data(id,requestTypeListAttribute,caregiverRequestUUID,isCognitoId=False):
    if isCognitoId :
        memberMappingItems = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(id))
        if memberMappingItems is None or memberMappingItems.get("Items") is  None or len(memberMappingItems.get("Items")) == 0:
            return None
        memberData = memberMappingItems.get("Items")[0]
    else :
        memberMappingItems = memberMappingItems = memberMappingTable.get_item(Key={'uuid': id})
        if memberMappingItems is None or memberMappingItems.get("Item") is  None or len(memberMappingItems.get("Item")) == 0:
            return None
        memberData = memberMappingItems.get("Item")
        
    attributeListData = memberData.get(requestTypeListAttribute)

    if attributeListData is None or len(attributeListData) == 0:
        return None
        
    #filter giver caregiver request index
    caregiverRequestDataIndex = [i for i in range(len(attributeListData)) if (attributeListData[i]['CaregiverRequestUUID'] == caregiverRequestUUID and not attributeListData[i].get('IsDeleted',False))] 


    if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
        return None

    caregiverRequestData = attributeListData[caregiverRequestDataIndex[0]]

    return {'memberData':memberData,'caregiverRequestDataIndex':caregiverRequestDataIndex[0],'caregiverRequestData':caregiverRequestData}
 
def update_request(caregiverRequestData,status,dateTimeNow,caregiverMemberDataIndex,notifyCaregiver,memberMappingData):
   
    if status == "RESEND_INVITE":
        caregiverRequestData["Status"] = "INVITE_SENT"
        caregiverRequestData["IsClicked"] = False
        caregiverRequestData["CreatedDate"] = dateTimeNow
    else:
        caregiverRequestData['Status'] = str(status)
        
    caregiverRequestData['UpdatedDate'] = dateTimeNow
 

  
    memberMappingTable.update_item(Key={'uuid': caregiverRequestData['CarereceiverUUID']},
                                   UpdateExpression="set CaregiverMappingList[" + str(caregiverMemberDataIndex) + "] = :caregiverMemberData",
                                   ExpressionAttributeValues={':caregiverMemberData': caregiverRequestData},
                                   ReturnValues="UPDATED_NEW")
    
    if status == "RESEND_INVITE":
        if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
            update_care_receiver_data(
            caregiverRequestData["CaregiverUUID"],
            caregiverRequestData["CaregiverRequestUUID"],
            {
                "Status": "INVITE_SENT",
                "CreatedDate": dateTimeNow,
                "UpdatedDate": dateTimeNow,
                "IsClicked": False,
            },
            )
        memberData = get_member_details(caregiverRequestData["CarereceiverUUID"],memberMappingData['cognitoId'])
        if memberData is not None:
            send_invite_email(caregiverRequestData, memberData)
    else:
        if status == "REMOVED":
          memberData = get_member_details(caregiverRequestData["CarereceiverUUID"],memberMappingData['cognitoId'])
          if memberData is not None:
              if notifyCaregiver:
                send_removal_email(caregiverRequestData, memberData)
              
              send_self_notification_email(memberData)
        if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
            update_care_receiver_data(caregiverRequestData['CaregiverUUID'],caregiverRequestData['CaregiverRequestUUID'],{"Status":status,"UpdatedDate":dateTimeNow})
    
    #update caregiver request table
    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])

    
    caregiverRequestTable.put_item(Item = caregiverRequestData)

    if status != "RESEND_INVITE":
        if caregiverRequestData.get('CaregiverSFId') is not None and caregiverRequestData.get('CaregiverSFId') != '' and caregiverRequestData.get('RelationshipSFId','') != '': 
          salesforce_response = update_caregiver_sf_status(caregiverRequestData["CarereceiverSFId"],caregiverRequestData["CaregiverSFId"],status) 
          if salesforce_response["statusCode"] != 200:
              return failure_response(400,'Error while updating caregiver status.','')    
          
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Caregiver request status updated successfully!'}),
        'headers': headers
        }

def update_care_receiver_data(memberId,caregiverRequestUUID,updatedData):
    memberWithCarereceiverRequestData = fetch_caregiver_request_data(memberId,'CarereceiverMappingList',caregiverRequestUUID,False)
    
    if memberWithCarereceiverRequestData is None:
        return failure_response(404,'Invalid request data.')
      
    carereceiverRequestDataIndex = memberWithCarereceiverRequestData['caregiverRequestDataIndex']

    carereceiverRequestData = memberWithCarereceiverRequestData['caregiverRequestData']
    carereceiverRequestData.update(updatedData)
  
    memberMappingTable.update_item(Key={'uuid': memberId},
                                       UpdateExpression="set CarereceiverMappingList[" + str(carereceiverRequestDataIndex) + "] = :carereceiverMemberData",
                                       ExpressionAttributeValues={':carereceiverMemberData': carereceiverRequestData},
                                       ReturnValues="UPDATED_NEW")
    
def update_caregiver_sf_status(memberId,caregiverId,status):
    payload = {}
    sfStatus = status if status == 'ACTIVE' else 'INACTIVE'
    payload['data'] = {"memberId":memberId,"caregiverId": caregiverId,"status":sfStatus}
    salesforceHost = os.environ['SF_API_PREFIX']
    salesforce_connection = http.client.HTTPSConnection(salesforceHost)
    return request(f'/services/apexrest/caregiver/v1', 'PATCH', payload, {}, salesforce_connection, {},{},True)

def send_removal_email(bodyData, memberData):
    client = boto3.client("ses")
    requester_name = memberData["FirstName"].capitalize() + " " + memberData["LastName"][0].capitalize()
    body_html = (
        """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Caregiver Access Removed 
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       """
        + """This email is to notify you that <b>"""+requester_name+"""</b> has removed your caregiver access to their health dashboard.""" 
        + """</br></br> 
                                        No further action is needed from you at this point. If you feel this was by mistake, please reach out to the member.
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                         </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>"""
    )
    email_message = {
        "Body": {
            "Html": {
                "Charset": "utf-8",
                "Data": body_html,
            },
        },
        "Subject": {
            "Charset": "utf-8",
            "Data": f"Caregiver Access Removed",
        },
    }
    ses_response = client.send_email(
        Destination={
            "ToAddresses": [bodyData["EmailAddress"]],
        },
        Message=email_message,
        Source="no-reply@helloporter.com",
    )

def send_self_notification_email(memberData):
    client = boto3.client("ses")
    url =  os.environ["WebAppUrl"]+"/contact-us"
    body_html = (
        """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      Caregiver Removed From Account 
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       This email is to notify you that one of your caregivers has been successfully removed from your account. If this was not done by you, please <a href='"""+url+"""' style="color:#1579D6">contact support</a>
 and we recommend you login and change your password immediately. 
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                         </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              400 NW 26th St. Miami, FL 33127<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>"""
    )
    email_message = {
        "Body": {
            "Html": {
                "Charset": "utf-8",
                "Data": body_html,
            },
        },
        "Subject": {
            "Charset": "utf-8",
            "Data": f"Caregiver Removed From Account",
        },
    }
    ses_response = client.send_email(
        Destination={
            "ToAddresses": [memberData["EmailAddress"]],
        },
        Message=email_message,
        Source="no-reply@helloporter.com",
    )

def get_user_email(cognitoId):
    if cognitoId is None or cognitoId == '':
        return None
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email"],   
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
        
    return response.get("Users")[0].get('Attributes')[0].get("Value",None)

    

