import json
import boto3
import os
import json
from httpUtils import request, not_found
import sys
import traceback
from datetime import datetime
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs
from boto3.dynamodb.conditions import Key,Attr


dynamo = boto3.resource('dynamodb')
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])

def lambda_handler(event, context):
   
    method = event.get('method')
    cognitoId = event['requestContext']['authorizer']['claims']['username']

    if method == 'GET':
        return get_favorites(event,cognitoId)
    if method == 'POST':
        return add_favorite(event,cognitoId)
    if method == 'DELETE':
        return delete_favorite(event)
    
    return not_found('', f'The provided request method, {method} is not supported for request {action}') 

def delete_favorite(event):
    payload = json.loads(event['payload'])
    body = None
    statusCode = 200
    

    try:
        table = dynamo.Table(os.environ["LearnFavouritesPatientPortalTable"])
        body = table.delete_item(
            Key={
                        "cognitoId": payload['cognitoId'],
                        "createdDate":payload['createdDate']
                }
        )
        body = {'message': 'Favorite removed successfully!'}
       
    except Exception as err:
        statusCode = 400
        body = str(err)
    finally:
        body = json.dumps(body)

    return {
        'statusCode': statusCode,
        'body': body,
        'headers': headers
    }

def get_favorites(event,cognitoId):
    body = None
    statusCode = 200
    bodyData = event.get('queryStringParameters') if event.get('queryStringParameters') != None else {}
    
    if bodyData.get('carereceiverId','') != '':
        
        memberData = get_member_data(bodyData.get('carereceiverId',''))
        
        if memberData is not None:
            cognitoId = memberData['cognitoId']
    try:
        table = dynamo.Table(os.environ["LearnFavouritesPatientPortalTable"])
        body = table.query(
            KeyConditionExpression=Key('cognitoId').eq(cognitoId)
        )
    except Exception as err:
        statusCode = 400
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        body = "An error has occured while trying to get Favorite"
        

    return {
        'statusCode': statusCode,
        'body': json.dumps(body, cls=DecimalEncoder),
        'headers': headers
    }

def get_member_data(id):
    memberMappingResponse = memberMappingTable.query(KeyConditionExpression=Key('uuid').eq(id))
    if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
            return None
    return memberMappingResponse["Items"][0]
  
def add_favorite(event,cognitoId):
    body = None
    statusCode = 200
   

    try:
        bodyData = json.loads(event['payload'])
        
        table = dynamo.Table(os.environ["LearnFavouritesPatientPortalTable"])
        response = table.query(
            KeyConditionExpression=Key('cognitoId').eq(cognitoId),
            FilterExpression=Attr('contentId').eq(bodyData['contentId']),
        )

        if response['Count'] > 0:
            body = {'message': 'Favorite already added!'}
        else:
            table.put_item(
                Item=bodyData
            )
            body = {'message': 'Favorite added successfully!'}
    except Exception as err:
        statusCode = 400
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        body = "An error has occurred while trying to add Favorite"
    finally:
        body = json.dumps(body)

    return {
        'statusCode': statusCode,
        'body': body,
        'headers': headers
    }

from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, Decimal):
      return str(obj)
    return json.JSONEncoder.default(self, obj)