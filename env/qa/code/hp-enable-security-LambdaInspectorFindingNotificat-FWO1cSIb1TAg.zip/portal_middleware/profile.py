import boto3
import os
import json
import botocore.exceptions
from boto3.dynamodb.conditions import Key
from datetime import datetime
from httpUtils import  not_found
import sys
import traceback

dynamodb = boto3.resource("dynamodb")

headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def lambda_handler(event, context):
    method = event.get('method')
    action = event.get('action')
    token = get_token(event['headers']['Authorization'])
    if method == 'GET':
        return get_profile_data(event['requestContext']['authorizer']['claims']['username'])
    elif method == 'PUT':
        return update_password(event,token)
    elif method == 'POST' and action == 'UpdateUserProfile':
        return update_user_profile(event)
    
    return not_found('', f'The provided request method, {method} is not supported for request {action}') 
    
def get_token(header):
    PREFIX = 'Bearer'
    bearer, _, token = header.partition(' ')
    if bearer != PREFIX:
        raise ValueError('Invalid token')

    return token
    
def update_password(event, token):
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    
    payload = json.loads(event.get('payload'))
    original_password = payload["originalPassword"]
    new_password = payload["newPassowrd"]
    try:
        response = client.change_password(
            PreviousPassword=original_password,
            ProposedPassword=new_password,
            AccessToken=token
        )
    except client.exceptions.NotAuthorizedException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Invalid old password."})
        }
    except client.exceptions.LimitExceededException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Limit exceeded.Please try after sometime."})
        }
    except client.exceptions.TooManyRequestsException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Too many attempts.Please try after sometime."})
        }
    
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
        return {
            'statusCode': response.get("ResponseMetadata").get("HTTPStatusCode"),
            "headers": headers,
            'body': json.dumps(response)
        } 
    
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Successfully updated password."}),
        "headers": headers
    }
    
def update_user_profile(event):
    try:
        client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
        payload = json.loads(event.get('payload'))

        cognito_id = event['requestContext']['authorizer']['claims']['username']
        mappingtable =  dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
        
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))

        if (response["Items"]):
            update_response = client.admin_update_user_attributes(
                UserPoolId=os.environ["UserPoolId"],
                Username=str(cognito_id),
                UserAttributes=[
                    {
                        "Name": "email",
                        "Value": payload["emailAddress"]
                    },
                    {
                        "Name": "email_verified",
                        "Value": "true"
                    },
                    {
                        "Name": "phone_number",
                        "Value": payload["primaryNumber"]
                    }
                ]
            )

    except client.exceptions.AliasExistsException as e:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": str(e), "message": "An account with given email already exists"}),
            "headers": headers
        }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            "statusCode": 400,
            "body": json.dumps({"message": 'An Error Has Occurred'}),
            "headers": headers
        }
        
    if update_response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
        return {
            'statusCode': response.get("ResponseMetadata").get("HTTPStatusCode"),
            "headers": headers,
            'body': json.dumps(response)
        } 

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Update Successfully"}),
        "headers": headers
    }
def get_profile_data(cognito_id):
    try:
        profileData = {}
        cognito_id = str(cognito_id)
        membertable = dynamodb.Table(os.environ['MemberDetailsTable'])
        addresstable =  dynamodb.Table(os.environ['MemberAddressTable'])
        mappingtable =  dynamodb.Table(os.environ['MiddlewareMemberMappingTable']) 
        consenttable =  dynamodb.Table(os.environ['MiddlewareMemberConsentTable'])
        contacttable =  dynamodb.Table(os.environ['MemberContactTable']) 
        
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))
        account_data = {}
        if (response["Items"]):
            print(response["Items"])
            uuid = response["Items"][0]['uuid']
            memberDetail = membertable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            contactDetail = get_user_detail_from_cognito(cognito_id)
            addDetail = addresstable.scan(FilterExpression=Key('uuid').eq(uuid) & (Key('type').eq('HomeAddress')))
            constable = consenttable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            
            print(memberDetail["Items"])
            if (memberDetail["Items"] and len(memberDetail["Items"]) > 0):
                data = memberDetail["Items"][0]
                profileData['status'] = "success"
                profileData['uuid'] = uuid
                profileData['Gender'] = data.get('Gender','') 
                profileData['FirstName'] = data.get('FirstName',"") 
                profileData['LastName'] = data.get('LastName',"") 
                profileData['DateOfBirth'] = data.get('DateOfBirth',"")
            if (contactDetail is not None):
                profileData['EmailAddress'] = contactDetail.get('emailAddress',"")
                profileData['PrimaryNumber'] = contactDetail.get('phoneNumber',"") 
            if (addDetail["Items"] and len(addDetail["Items"]) > 0):
                adata = addDetail["Items"][0]
                profileData['Street1'] = adata['Street1'] if (adata['Street1']) else ""
                profileData['Street2'] = adata['Street2'] if (adata['Street2']) else ""
                profileData['City'] = adata['City'] if (adata['City']) else ""
                profileData['State'] = adata['State'] if (adata['State']) else ""
                profileData['Zip'] = adata['Zip'] if (adata['Zip']) else ""
            if (constable["Items"] and len(constable["Items"]) > 0):
                csdata = constable["Items"][0]
                consentData = {}
                consentData['Type'] = csdata['Type'] if (csdata['Type']) else ""
                consentData['Consent'] = csdata['Consent'] if (csdata['Consent']) else ""
                consentData['Individual'] = csdata['Individual'] if (csdata['Individual']) else ""
                consentData['IndividualRelationship'] = csdata['IndividualRelationship'] if (csdata['IndividualRelationship']) else ""
                consentData['LegalName'] = csdata['LegalName'] if (csdata['LegalName']) else ""
                consentData['Title'] = csdata['Title'] if (csdata['Title']) else ""
                consentData['FirstName'] = csdata['FirstName'] if (csdata['FirstName']) else ""
                consentData['LastName'] = csdata['LastName'] if (csdata['LastName']) else ""
                consentData['ConsentDate'] = csdata['ConsentDate'] if (csdata['ConsentDate']) else ""
                profileData['consentData'] = consentData
            else:
                profileData['consentData'] = ''
    
        else:
            profileData['status'] = "Account not found."
    except Exception as err:
      exec_info = sys.exc_info()
      ex = ''.join(traceback.format_exception(*exec_info))
      
        
    return {
        "statusCode": 200,
        "body": json.dumps(profileData,cls=DecimalEncoder),
        "headers": headers
    }

def get_user_detail_from_cognito(cognitoId):
    if cognitoId is None or cognitoId == '':
        return None
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email","phone_number"],
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
    attributes = response.get("Users")[0].get('Attributes')
    data = {}
    for attribute in attributes:
        if attribute.get('Name','') == 'phone_number':
            data['phoneNumber'] = attribute.get('Value')
        elif attribute.get('Name','') == 'email':
            data['emailAddress'] = attribute.get('Value')

    return data
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return json.JSONEncoder.default(self, obj)

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )