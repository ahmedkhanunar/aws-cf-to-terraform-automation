import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import os

dynamodb = boto3.resource("dynamodb")

benefittable = os.environ['benefittable']
planProgramtable = os.environ['planProgramtable']
benefittable =  dynamodb.Table(benefittable) 
planProgramtable =  dynamodb.Table(planProgramtable) 
memberMappingTable = dynamodb.Table(os.environ["MiddlewareMemberMappingTable"])
memberEnrollmentTable = dynamodb.Table(os.environ["EnrollmentDetailsTable"])
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def get_my_benefits(event, context):
    cognitoId = event['requestContext']['authorizer']['claims']['username']
    bodyData = event.get('queryStringParameters') if event.get('queryStringParameters') != None else {}
    
    if bodyData.get('carereceiverId','') != '':
        
        memberData = get_member_data(bodyData.get('carereceiverId',''))
        
        if memberData is not None:
            cognitoId = memberData['cognitoId']
        else:
            return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    else:
        memberData = get_member_data(cognitoId,True)
        if memberData is not None:
            cognitoId = memberData['cognitoId']
        else:
            return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    payload = get_member_plan_data(memberData['uuid'])
    department_id = memberData.get('departmentId', "")

    if payload is None:
        return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    if payload.get("ContractID","") == '' :
        return {
            'statusCode': "204",
            "headers": headers,
            'body': json.dumps({"error": "Benefit Information Not Found"})
        }

            # dynamo_uuid = response['Items'][0]
            # if ((int(time.time())) - (int(dynamo_uuid['ts'])) < 3000): 
            #     access_token = dynamo_uuid['token']
            
    data = fetchBenefit(department_id, payload.get("ContractID",""), payload.get("GroupID",""), payload.get("SubGroupID",""), payload.get("PBP",""), payload.get("PlanId",""), payload.get("MetalLevel",""))
    
    newData =[]
    for rec in data:
        procdata = {}
        if 'benefit' in rec:
            procdata['isURL'] = rec.get('isURL', '')
            procdata['benefit'] = rec.get('benefit', '')
            procdata['description'] = rec.get('description', '')
            procdata['program'] = rec.get('program', '')
            procdata['benefit_amt'] = rec.get('benefit_amt', '')
            procdata['sortOrder'] = rec.get('row_id', '')
            planName = rec.get('benefit', '')
            fetchedData = fetchPlan(rec['row_id'])
            newData.append(procdata)
            newData.extend(fetchedData)
        else:
            newData = data
        
        data = json.dumps(newData,cls=DecimalEncoder)


    return {
        'statusCode': "200",
        "headers": headers,
        'body': json.dumps(newData,cls=DecimalEncoder)
        
}

def get_member_data(id,isCognitoId=False):
    
    if isCognitoId:
        memberMappingResponse = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(id))
    else:
        memberMappingResponse = memberMappingTable.query(KeyConditionExpression=Key('uuid').eq(id))

    if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
            return None
    return memberMappingResponse["Items"][0]

def  get_member_plan_data(uuid):
    response = memberEnrollmentTable.query(KeyConditionExpression=Key('uuid').eq(uuid))
    if len(response["Items"]) == 0:
            return
            
    return response["Items"][0]
    


def fetchPlan(planLookupId):
    plan_data = {}
    retData =[]
    fe = Key('plan_lookup_id').eq(planLookupId) 
    response = planProgramtable.scan(FilterExpression=fe)
    if len(response['Items'])  > 0:
        resdata = response['Items']

        for resp in resdata:
            
            plan_data['isURL'] ='0'
            plan_data['benefit'] = resp['benefit']
            plan_data['description'] = resp['description']
            plan_data['program'] = resp.get('program', "")
            plan_data['benefit_amt'] = resp['benefit_amt']
            plan_data['sortOrder'] = resp['row_id']
            retData.append(plan_data)
            plan_data = {}
    return retData

def fetchBenefit(department_id, contract_id, group_id, subgroup_id, pbp, plan_id, metal_level):
    data = []

    if str(department_id) == "1" or str(department_id) == "3":
        if group_id == '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
        if group_id != '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id) & Attr('SubGroupID').eq(subgroup_id)

    if str(department_id).lower() == "aetna" or str(department_id) == "5":
        if pbp == '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
        if pbp != '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('Pbp').eq(pbp)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('Pbp').eq(pbp) & Attr('SubGroupID').eq(subgroup_id)

    if str(department_id) == "4":
        if group_id == '':
            if subgroup_id == '':
                fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id)
            if subgroup_id != '':
                fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
        if group_id != '':
            if subgroup_id == '':
                fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id)
            if subgroup_id != '':
                fe = Attr('MetalLevel').eq(metal_level) & Attr('department_id').eq(department_id) & Attr('GroupID').eq(group_id) & Attr('SubGroupID').eq(subgroup_id)

    if str(department_id) == "6" or str(department_id).lower() == "centene":
        if plan_id == '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('SubGroupID').eq(subgroup_id)
        if plan_id != '':
            if subgroup_id == '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('PlanId').eq(plan_id)
            if subgroup_id != '':
                fe = Attr('contract_id').eq(contract_id) & Attr('department_id').eq(department_id) & Attr('PlanId').eq(plan_id) & Attr('SubGroupID').eq(subgroup_id)
    
    response = benefittable.scan(FilterExpression=fe)
    if len(response['Items'])  > 0:
        
        data = response['Items']
    else:
        data = []
    return data

from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return json.JSONEncoder.default(self, obj)