import json
import os
import json
from boto3.dynamodb.conditions import Key
from datetime import datetime
import uuid
import boto3
from cerberus import Validator

dynamo = boto3.resource('dynamodb')
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

caregiverSchema = {
            'sfAccountId':{
                'type':'string',
                'required':True
            }
        }



def lambda_handler(event, context):
         
    return get_security_answers(event)
    
     
     
   

def get_security_answers(event):
   
    try:
        
        bodyData = event.get('queryStringParameters') if event.get('queryStringParameters') != None else {}
        validator = Validator(caregiverSchema,allow_unknown=True)
        
       

        if not validator.validate(bodyData):
            return {
                    'statusCode': 400,
                    "headers": headers,
                    'body' : json.dumps({'message':'invalid data','errors': validator.errors})
            }
         
        memberMappingResponse = get_member_data(bodyData["sfAccountId"])

        if memberMappingResponse is None:
            return failure_response(404,'Invalid Account id','')
        
        #fetch security answers data
        securityAnswerMappingTable = dynamo.Table(os.environ['SecurityAnswerMappingTable'])
        securityAnswerMappingResponse = securityAnswerMappingTable.scan(FilterExpression=Key('ExternalID').eq(memberMappingResponse['uuid'] ))
        
        data = []
        if securityAnswerMappingResponse.get("Items") is None or len(securityAnswerMappingResponse.get("Items")) == 0:
            return {
                'statusCode': 200,
                'body': json.dumps({'data':[]}),
                'headers': headers
            }
            
        
       
        for securityAnswerMapping in securityAnswerMappingResponse.get("Items"):
            securityQuestionMasterTable = dynamo.Table(os.environ['SecurityQuestionMasterTable'])
            securityQuestionResponse = securityQuestionMasterTable.get_item(Key={'uuid': securityAnswerMapping['SecurityQuestionMasterUUID'], 'Type': "SECURITY" })
            
            if securityQuestionResponse.get("Item") is not None or len(securityQuestionResponse.get("Item")) > 0:
                data.append({"question":securityQuestionResponse.get("Item").get("Question"),"answer":securityAnswerMapping.get("Answer")})
                
        return {
                'statusCode': 200,
                'body': json.dumps({'data':data}),
                'headers': headers
            }
            


        



    except Exception as err:
       
        return failure_response()
     
   


def get_member_data(id):
    memberMappingTable = dynamo.Table(os.environ['MiddlewareMemberMappingTable'])
   
    memberMappingResponse = memberMappingTable.scan(FilterExpression=Key('SFAccount').eq(id))
    
    if len(memberMappingResponse["Items"]) == 0 :
        return None
    return memberMappingResponse["Items"][0]

def failure_response(statuCode = 400,message='Error while getting security answers.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    }