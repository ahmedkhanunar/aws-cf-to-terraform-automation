import json
import os
import json
from boto3.dynamodb.conditions import Key
from datetime import datetime,timezone

import boto3
from cerberus import Validator
caregiverRequestExpiryInHours = 24
dynamo = boto3.resource('dynamodb')
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

caregiverSchema = {
            'sfAccountId':{
                'type':'string',
                'required':True
            }
        }



def lambda_handler(event, context):
         
    return get_caregivers(event)
    
     
     
   

def get_caregivers(event):
    
    try:
        
        bodyData = event.get('queryStringParameters') if event.get('queryStringParameters') != None else {}
        validator = Validator(caregiverSchema,allow_unknown=True)
       

        if not validator.validate(bodyData):
            return {
                    'statusCode': 400,
                    "headers": headers,
                    'body' : json.dumps({'message':'invalid body','errors': validator.errors})
            } 
        
        memberData = get_member_data(bodyData['sfAccountId'])
        if memberData is None:
            return failure_response(404,'Invalid account id','')
        
        caregiverList = memberData.get('CaregiverMappingList',[])
        filteredList = []
        for caregiver in caregiverList:
            #validate time
            dateTimeDifference = datetime.now(timezone.utc)-datetime.fromisoformat(caregiver["CreatedDate"])
            #check date time difference is less than 24 hours
            if (dateTimeDifference is None or dateTimeDifference.total_seconds() < 0 or dateTimeDifference.total_seconds() / 3600 > caregiverRequestExpiryInHours) and caregiver['Status'] == "INVITE_SENT" :
                caregiver['Status'] = 'INVITE_EXPIRED'

            if caregiver['Status'] != 'REMOVED' and not caregiver.get('IsDeleted',False):
                filteredList.append(caregiver)
            
        
         
        return {
            'statusCode': 200,
            'body': json.dumps({'data':filteredList }),
            'headers': headers
        }
        
      
        
       
    except Exception as err:
        return failure_response(404,'Error while getting caregiver','')
     

   



def get_member_data(id):
   
    memberMappingTable = dynamo.Table(os.environ['MiddlewareMemberMappingTable'])
    memberMappingResponse = memberMappingTable.scan(FilterExpression=Key('SFAccount').eq(id))
   
    
    if len(memberMappingResponse["Items"]) == 0 :
        return None
  
    return memberMappingResponse["Items"][0]
    

def failure_response(statuCode = 400,message='Error while updating caregiver request.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    }