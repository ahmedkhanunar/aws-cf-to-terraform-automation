import json
import boto3
import os
region_name =  os.environ['region_name']
from boto3.dynamodb.conditions import Key


dynamodb = boto3.resource('dynamodb', region_name=region_name)

benefittable = os.environ['benefittable']
planProgramtable = os.environ['planProgramtable']
# enrolTable = os.environ['enrolTable']
benefittable =  dynamodb.Table(benefittable) 
planProgramtable =  dynamodb.Table(planProgramtable) 
# enrolTable =  dynamodb.Table(enrolTable)


def lambda_handler(event, context):
    print(event)
    init_data = event['queryStringParameters']
    print(init_data)
    # paramdata = json.loads
    paramdata = init_data
    contractid = paramdata['contractid']
    SubGroup_ID = paramdata['SubGroup_ID']


    def setGroupID(contractid, SubGroup_ID):
        # fe = Key('contract_id').eq(contractid) and  Key('SubGroupID').eq(SubGroup_ID) 
        fe = Key('contract_id').eq(contractid) and  Key('GroupID').eq(SubGroup_ID)
        # response = enrolTable.scan(FilterExpression=fe)
        response = benefittable.scan(FilterExpression=fe)
        if len(response['Items'])  > 0:
            SubGroup_ID = response['Items'][0]['SubGroupID']
        else:
            SubGroup_ID = str(SubGroup_ID)
        return SubGroup_ID
    SubGroup_ID = setGroupID(contractid, SubGroup_ID)





    
    def fetchPlan(planLookupId):
        plan_data = {}
        retData =[]
        fe = Key('plan_lookup_id').eq(planLookupId) 
        response = planProgramtable.scan(FilterExpression=fe)
        if len(response['Items'])  > 0:
            print(response['Items'])
    
            resdata = response['Items']
            
            for resp in resdata:
                print(resp)
                plan_data['isURL'] ='0'
                plan_data['benefit'] = resp['benefit']
                plan_data['description'] = resp['description']
                plan_data['program'] = resp['program']
                plan_data['benefit_amt'] = resp['benefit_amt']
                retData.append(plan_data)
                plan_data = {}
        return retData
    
    
    
    def fetchBenefit(contractid, SubGroup_ID):
        data = [{"Result" : "No Record found" }]
        fe = Key('contract_id').eq(contractid) and  Key('SubGroupID').eq(SubGroup_ID) 
        response = benefittable.scan(FilterExpression=fe)
        if len(response['Items'])  > 0:
            print(response['Items'])
            data = response['Items']
         
        else:
            data = [{"Result" : "No Record found" }]
        return data
        # dynamo_uuid = response['Items'][0]
        # if ((int(time.time())) - (int(dynamo_uuid['ts'])) < 3000): 
        #     access_token = dynamo_uuid['token']
        
    data = fetchBenefit(contractid, SubGroup_ID)
    print(type(data))
    print(data)
    
    newData =[]
    for rec in data:
        procdata = {}
        if 'benefit' in rec:
            procdata['isURL'] = rec['isURL']
            procdata['benefit'] = rec['benefit']
            procdata['description'] = rec['description']
            procdata['program'] = rec['program']
            procdata['benefit_amt'] = rec['benefit_amt']
            planName = rec['benefit']
            newData = fetchPlan(rec['row_id'])
            newData.append(procdata)
        else:
            newData = data
    print('newData' ,newData)
    data = json.dumps(newData)
    
    
    #print(type(data))
    #print(data)
    # TODO implement   
   
    responseObj = {}
    responseObj['statusCode'] = 200
    responseObj['headers'] = {}
    responseObj['headers']['Content-Type'] = 'application/json'
    responseObj['headers']['Access-Control-Allow-Origin'] = '*'
    responseObj['headers']['Allow'] = 'GET, OPTIONS'
    responseObj['headers']['Access-Control-Allow-Methods'] = '*'
    responseObj['headers']['Access-Control-Allow-Headers'] = '*'
    responseObj['body'] = data
    

    # TODO implement
    return responseObj

