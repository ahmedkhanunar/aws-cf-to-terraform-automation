const {  postRequest } = require("./utils");

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};

exports.handler = async (event) => {
    console.log(JSON.stringify(event))
    //validate token
    const accountId = getAccountId(event.headers)
    if (!accountId) {
        return {
            statusCode: 401,
            body: "{\"message\": \"Invalid token\"}"
        };
    }
    const requestBody = JSON.parse(event.body)
    if (!isValidBody(requestBody)) {
        return {
            statusCode: 400,
            body: "{\"message\": \"Invalid body\"}"
        };
    }


    try {
        // call reset password UC api
        const payload = {
            "password": requestBody.password,
            "passwordConfirm": requestBody.password,
            "context": "changepassword"
        };
         const resetPasswordResponse = await postRequest(ucAPIPrefix + "/account/" + requestBody.accountId, payload, ucDefaultHeaders);
         console.log(JSON.stringify(resetPasswordResponse))
        
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 200,
            body: JSON.stringify(resetPasswordResponse)
        };
    }
    catch (err) {
        console.log(err);
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 400,
            body: JSON.stringify(err)
        };
    }
};




/**
 * Parse token
 * @param {String} token 
 * @returns payload string
*/
function parseToken(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const buff = Buffer.from(base64, 'base64');
    const payloadinit = buff.toString('ascii');
    const payload = JSON.parse(payloadinit);
    return payload
}

/**
 * validate body data
 * @param {JSON} requestBody 
 * @returns true if requestbody data is valid
 */
function isValidBody(requestBody) {

    if (!requestBody || !requestBody.accountId  || !requestBody.password) {
        return false
    }

    return true
}

/**
 * Get account id from auth token
 * @param {*} headers 
 * @returns accountId
 */
function getAccountId(headers) {
    if (!headers || !headers.Authorization) {
        return null
    }

    const tokenPayload = parseToken(headers.Authorization)
    const accountId = tokenPayload.accountID
    if (!accountId)
        return null

    return accountId
}


