import json
import boto3
import os
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):
    dynamodb = boto3.resource("dynamodb")
    user_id = event.get("CognitoId", "")
    table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
    response = table.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(user_id))
    
    account_data = {}
    
    if len(response["Items"]) == 0 or len(response["Items"]) > 1:
        return {
            'statusCode': "204",
            "headers": {
                "Content-Type": "application/json"
            },
            'body': json.dumps({"error": "User not found"})
        } 
       
    account_data = response["Items"][0]

    consent_table = dynamodb.Table(os.environ['MiddlewareMemberConsentTable'])
    response = consent_table.get_item(Key={'uuid': account_data['uuid'], 'Type': event.get("Type", "") })
    
    return {
        'statusCode': "200",
        "headers": {
            "Content-Type": "application/json"
        },
        'body': json.dumps(response["Item"], cls=DecimalEncoder)
    }
    
    
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, Decimal):
      return str(obj)
    return json.JSONEncoder.default(self, obj)