import json
import boto3
import pandas as pd
from io import StringIO
import os
import time


region_name = 'us-east-1'
File=''
AccehrTag = ""
progrm = ""
AccsfTag = ''
response_status = ''

def lambda_handler(event, context):
    bucketName = os.environ.get('bucket_name')
    Queue = os.environ.get('Queue')
    init_data = event['body']
    paramdata = json.loads(init_data)
    acc_create = paramdata['acc_create']
    program_name = paramdata['program_name']
    customer_name = paramdata['customer_name']
    File = paramdata['file_name']
    sqs = boto3.client('sqs', region_name=region_name)
    queue_url = Queue
    
    def extractTag():
        #if 'ehr' in list(map(str.lower, acc_create)):
        if 'ehr' in acc_create.lower():
            AccehrTag= 'EHR'
        else:
            AccehrTag =''
        #if 'sf' in list(map(str.lower, acc_create)):
        if 'sf' in acc_create.lower():
            AccsfTag= 'SF'
        else:
            AccsfTag = ""
        return AccehrTag, AccsfTag
    
    def readS3Data(File):
        File = File
        client = boto3.client('s3', region_name=region_name)
        bucket_name = bucketName
        object_key = File
        csv_obj = client.get_object(Bucket=bucket_name, Key=object_key)
        if (csv_obj):
            body = csv_obj['Body']
            data = body.read().decode('utf-8')
            data = StringIO(data)
        else:
            data = ''
        return data
    def createMessage():
        counter = 0
        df = pd.DataFrame(pd.read_csv(data, sep = ",", dtype=str,  index_col = False))
        df.dropna(subset=['MBI'],inplace=True)
        df = df.fillna("")
        for index , row in df.iterrows():
            queue_url = Queue
            row['AccehrTag'] = AccehrTag
            row['AccsfTag'] = AccsfTag
            row['File'] = File 
            row['program_name'] = program_name
            row['customer_name'] = customer_name
            row = row.to_json()
            response = sqs.send_message(QueueUrl=queue_url,MessageBody=(row))
            print(response)
            counter +=1
            if counter == 15:
                print(counter)
                time.sleep(1)
                counter = 0

            print('sleeping for a moment')
            

                
            response_status =  "File Submitted for processing. Account Status  updated in Status Queue"
        return response_status
    
    
    if File =='':
        response_status = 'Please provide csv file name.'
    else:
        data = readS3Data(File)
        if data == '':
            response_status = 'Error processing CSV file, please check the File Format.'
        else:
            data = readS3Data(File)
            AccehrTag, AccsfTag = extractTag()
            response_status = createMessage()

    
    responseObj = {}
    responseObj['statusCode'] = 200
    responseObj['headers'] = {}
    responseObj['headers']['Content-Type'] = 'application/json'
    responseObj['body'] = response_status
    

    # TODO implement
    return responseObj
