const {
    getRequest,
} = require("./utils");

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};

exports.handler = async (event) => {
    console.log(JSON.stringify(event))
    let requestEmail = event?.queryStringParameters?.email;
    
    try {
        if (!requestEmail) {
            return {
                 'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
                statusCode: 400,
                body: '{"message": "Email Address is missing"}',
            };
        }

        const checkUserOnUC = await callForCheckUserExsist(requestEmail)
        console.log(`checkUserOnUC`+JSON.stringify(checkUserOnUC))

        if (!checkUserOnUC.recordsCount) {
            return {
                'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
                statusCode: 200,
                body: JSON.stringify({
                    'userExist': false
                })
            };
        }
        
        return {
             'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 200,
            body: JSON.stringify({
                'userExist': true,
                'accountId': checkUserOnUC?.pageRecords && checkUserOnUC?.pageRecords[0].accountID,
            })
        };


    } catch (err) {
        console.log(err);
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 400,
            body: JSON.stringify(err),
        };
    }
};

/**
 * call UC exsist user api
 * @param {*} requestBody 
 */
async function callForCheckUserExsist(requestEmail) {

    let response = await getRequest(ucAPIPrefix + "/account/" + "?" + "f:primaryEmailAddress.emailAddress:eq=" + requestEmail, null, ucDefaultHeaders, false);
    return response
}
