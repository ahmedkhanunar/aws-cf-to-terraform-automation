import boto3
from boto3.dynamodb.conditions import Key
import os
import json
# import jwt
dynamodb = boto3.resource("dynamodb")
#from cryptography.fernet import Fernet
import base64

def lambda_handler(event, context):
   
   client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
   user_id = event['userName']
   isFirstTimeLogin = event['request'].get('userAttributes').get('custom:isFirstTimeLogin','1')
   
   table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
   response = table.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(user_id))
   
   account_data = {}
   
   if(response["Items"]):
     account_data = response["Items"][0]
   
   
   stored_secret = json.loads(get_secret()).get("SecretString", "")
   key = base64.b64encode(f"{stored_secret:<32}".encode("utf-8"))

   #cipher_suite = Fernet(key)
   #    print(account_data)
   #event["response"] = { "userData": account_data}
   event["response"] = {
        "claimsOverrideDetails": {
            # "claimsToAddOrOverride": {
            #     "custom:athenaId": cipher_suite.encrypt(account_data.get("athenaId","").encode("utf-8")).decode("utf-8"),
            #     "custom:cognitoId":cipher_suite.encrypt(account_data.get("cognitoId","").encode("utf-8")).decode("utf-8"),
            #     "custom:SFAccount": cipher_suite.encrypt(account_data.get("SFAccount","").encode("utf-8")).decode("utf-8"),
            #     "custom:ucAccountId": cipher_suite.encrypt(account_data.get("ucAccountId","").encode("utf-8")).decode("utf-8"),
            #     "custom:departmentId": cipher_suite.encrypt(account_data.get("departmentId","-1").encode("utf-8")).decode("utf-8"),
            #     "custom:isFirstTimeLogin": isFirstTimeLogin
            # },
        },
    }
   if isFirstTimeLogin ==  '1':
      response = client.admin_update_user_attributes(
                    UserPoolId=event["userPoolId"],
                    Username=user_id,
                    UserAttributes=[
                        {
                            'Name': 'custom:isFirstTimeLogin',
                            'Value': '0'
                        },
                    ]
                    )

      
      
    
   return event

def get_secret():
   secretId = os.environ["IDTOKEN_SECRET_ID"]
   region_name = os.environ["REGION"]
   session = boto3.session.Session()
   client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )
   session_token = client.get_secret_value(
        SecretId=secretId)
   return session_token["SecretString"]
