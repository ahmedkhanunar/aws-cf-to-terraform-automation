import os
import json
from io import BytesIO
import tarfile
import boto3
import traceback
import sys
from datetime import datetime
import subprocess
import brotli
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs

libre_office_install_dir = '/tmp/instdir'
lambda_client = boto3.client('lambda')

def load_libre_office():
    if os.path.exists(libre_office_install_dir) and os.path.isdir(libre_office_install_dir):
        print('We have a cached copy of LibreOffice, skipping extraction')
    else:
        print('No cached copy of LibreOffice exists, extracting tar stream from Brotli file.')
        buffer = BytesIO()
        with open('/opt/lo.tar.br', 'rb') as brotli_file:
            decompressor = brotli.Decompressor()
            while True:
                chunk = brotli_file.read(1024)
                buffer.write(decompressor.process(chunk))
                if len(chunk) < 1024:
                    break
            buffer.seek(0)

        print('Extracting tar stream to /tmp for caching.')
        with tarfile.open(fileobj=buffer) as tar:
            tar.extractall('/tmp')
        print('Done caching LibreOffice!')

    return f'{libre_office_install_dir}/program/soffice.bin'

def download_from_s3(bucket, key, download_path):
    # s3 = boto3.client("s3")
    s3 = boto3.client('s3', region_name='us-east-1')
    s3.download_file(bucket, key, download_path)
    # s3.download_file("databricks-workspace-stack-newdev-bucket", "MountainHealth_HRA_21212121_20240405000000.docx", "nvirginia-prod/7413904104309051/FileStore/tables/Customer/MountainHealth/Outputs/20240404/MountainHealth_HRA_21212121_20240405000000.docx")
    # s3.download_file(Key="nvirginia-prod/7413904104309051/FileStore/tables/Customer/MountainHealth/Outputs/20240404/MountainHealth_HRA_21212121_20240405000000.docx", Bucket="databricks-workspace-stack-newdev-bucket", Filename="MountainHealth_HRA_21212121_20240405000000.docx" )
    # s3.download_file("databricks-workspace-stack-newdev-bucket", "tmp/MountainHealth_HRA_21212121_20240405000000.docx", "/tmp/MountainHealth_HRA_21212121_20240405000000.docx" )

def upload_to_s3(file_path, bucket, key):
    # s3 = boto3.client("s3")
    s3 = boto3.client('s3', region_name='us-east-1')
    s3.upload_file(file_path, bucket, key)

def convert_word_to_pdf(soffice_path, word_file_path, output_dir):
    conv_cmd = f"{soffice_path} --headless --norestore --invisible --nodefault --nofirststartwizard --nolockcheck --nologo --convert-to pdf:writer_pdf_Export --outdir {output_dir} {word_file_path}"
    response = subprocess.run(conv_cmd.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if response.returncode != 0:
        response = subprocess.run(conv_cmd.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if response.returncode != 0:
            return False
    return True
    
def process(event):
    bucket = os.environ['BucketName']
    key = event.get("path")
    file_name = key.split('/')[-1]
    output_dir = "/tmp"
    print('file_name: ', file_name)
    download_path = f'/tmp/{file_name}'
    download_from_s3(bucket, key, download_path)
    
    soffice_path = load_libre_office()

    is_converted = convert_word_to_pdf(soffice_path, download_path, output_dir)
    if is_converted:
        pdf_file_name = f"{file_name.split('.')[0]}.pdf"
        path_array = key.split('/')[:-2]
        path = '/'.join(path_array)
        upload_to_s3(f"{output_dir}/{pdf_file_name}", bucket, f'{path}/pdf/{pdf_file_name}')
        return {"status_code": 200, "response": f"file converted to PDF at {path}/pdf/{pdf_file_name}", "path": f'{path}/pdf/{pdf_file_name}'}
    else:
        return {"status_code": 500, "response": "cannot convert this document to PDF"}
    
def lambda_handler(event, context):
    try:
        response = process(event)
        if response.get("status_code", 500) == 200:
            # lambda_client.invoke(FunctionName = os.environ['LambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"path": response.get('path', ""), "patient_id": event.get("patient_id", ""), "department_id": event.get("department_id", "")}))
            print('pdf generated successfully')
        else:
            return response
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot convert document to pdf')
        }
