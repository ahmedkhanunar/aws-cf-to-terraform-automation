const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "GET /account/{ultraCommerceAccountId}/guided-experience":
        body = await dynamo
          .query({
            TableName: process.env.GuidedExperienceTable,
            ScanIndexForward: false,
            KeyConditionExpression: "ultraCommerceAccountId = :ultraCommerceAccountId AND createdDate > :createdDate",
            ExpressionAttributeValues: {
                ":ultraCommerceAccountId": event.pathParameters.ultraCommerceAccountId,
                ":createdDate": "1900-01-01"
            }
          })
          .promise();
        break;
      case "POST /account/{ultraCommerceAccountId}/guided-experience":
      case "PUT /account/{ultraCommerceAccountId}/guided-experience":
      case "DELETE /account/{ultraCommerceAccountId}/guided-experience":
        await dynamo
          .put({
            TableName: process.env.GuidedExperienceTable,
            Item: event.pathParameters.guidedExperience
          })
          .promise();
        body = `Put/POST item for ${event.pathParameters.guidedExperience.ultraCommerceAccountId}`;
        break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};