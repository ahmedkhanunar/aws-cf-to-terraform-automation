const AWS = require('aws-sdk');

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  console.log(JSON.stringify(event.body));
  let body;
  let statusCode = 200;
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Allow': 'GET, OPTIONS, POST',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Allow-Headers': '*',
  };

  try {
    let bodyData = JSON.parse(event.body);
    let alreadyExsist = await dynamo
      .query({
        TableName: process.env.EducationalContentFavouritesTable,
        ScanIndexForward: false,
        KeyConditionExpression:
          'ultraCommerceAccountId = :ultraCommerceAccountId',
        FilterExpression: 'contentId = :contentId',
        ExpressionAttributeValues: {
          ':ultraCommerceAccountId': bodyData.ultraCommerceAccountId,
          ':contentId': bodyData.contentId,
        },
      })
      .promise();
    if (alreadyExsist.Count > 0) {
      body = {
        message: 'Favourite already added!',
      };
    } else {
      await dynamo
        .put({
          TableName: process.env.EducationalContentFavouritesTable,
          Item: JSON.parse(event.body),
        })
        .promise();
      body = {
        message: 'Favourite added successfully!',
      };
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};
