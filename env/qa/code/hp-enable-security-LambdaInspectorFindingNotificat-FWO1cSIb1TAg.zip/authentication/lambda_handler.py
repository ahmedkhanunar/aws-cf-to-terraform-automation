
import json
import boto3
import os
from boto3.dynamodb.conditions import Key
import string
import sys
import traceback
from datetime import datetime
import botocore.exceptions
import hmac
import hashlib
import base64
import jwt

headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Allow': 'GET, OPTIONS, POST',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Allow-Headers': '*',
}

def lambda_handler(event, context):
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    body = json.loads(event.get('body','{}'))
    path = event.get('path').rsplit('/', 1)[-1]
    print("user name: ", body.get("userName", ""))
    print("action path", event.get("path", ""))
        
    if path == 'login':
        print("action: ", "log in")
        return new_login(client, body.get("userName", ""), body.get("password", ""))
    if path == 'logout':
        print("action: ", "log out")
        return logout(client, body.get("accessToken", ""))
    elif path == 'forgot-password':
        print("action: ", "password reset")
        return forgot_password(client, body.get("userName", ""))
    elif path == 'confirm-code': 
        print("action: ", "confirm code")
        return confirm_password(client, body.get("userName", "") ,body.get("code", ""),body.get("password", "") )
    elif path == 'verify-email': 
        print("action: ", "verified email")
        return verify_email(client, body.get("userName", "") ,body.get("code", ""))
    elif path == 'resend-activation-email': 
        print("action: ", "resend activation email")
        return resend_activation_email(client, body.get("userName", ""))
    
    else: 
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({"error": "Not Found"})
        }


def new_login(client, username, password):
    try:
        old_user_response = client.admin_get_user(
            UserPoolId=os.environ["UserPoolId"],
            Username=username
        )
        
        if old_user_response.get("ResponseMetadata").get("HTTPStatusCode") == 200:
            if old_user_response['UserStatus'] == 'RESET_REQUIRED':
                return forgot_password(client, username)
            else:
                return login(client, username, password)
                
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "new login", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured during login"})
        } 

def login(client, username, password):
    try:
        response = client.initiate_auth(
            ClientId=os.environ["ClientId"],
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password
            })
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred sending password reset code"})
            }
        userData= get_user_data(response.get("AuthenticationResult").get("AccessToken"))
        if userData is not None:
            response.update(userData)

        
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps(response)
        }
    except client.exceptions.NotAuthorizedException as e:
        return {
            'statusCode': "401",
            "headers": headers,
            'body': json.dumps({"error": "You are not authorized to complete this request"})
        }
    except client.exceptions.UserNotConfirmedException:
        return {
            'statusCode': "403",
            "headers": headers,
            'body': json.dumps({"error": "User is not confirmed"})
        }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "new login", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured during login"})
        }

def logout(client, accessToken):
    try:
        response = client.global_sign_out(
            AccessToken=accessToken
        )

        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred trying to sign out"})
            }
        
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps(response)
        }

    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured during login"})
        }


def confirm_password(client, username, code, password):
    try:
        response = client.confirm_forgot_password(
            ClientId=os.environ["ClientId"],
            Username=username,
            ConfirmationCode=code,
            Password=password,
        )
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred sending password reset code"})
            }
            
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps({"message": "Successfully sent password reset code"})
        }
    except client.exceptions.InvalidPasswordException:
        return {
            'statusCode': "400",
            "headers": headers,
            'body': json.dumps({"error": "The password does not meet minimum requirements"})
        }
    except client.exceptions.CodeMismatchException:
        return {
            'statusCode': "400",
            "headers": headers,
            'body': json.dumps({"error": "The code provided was not valid"})
        }
    except client.exceptions.ExpiredCodeException:
        return {
            'statusCode': "400",
            "headers": headers,
            'body': json.dumps({"error": "The provided code has expired"})
        }
    except client.exceptions.UserNotFoundException:
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({"error": "The username was not found"})
        }
    # except client.exceptions.UserNotConfirmedException:
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "confirm password", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured while generating forgot password code"})
        }
        
def verify_email(client,username,code):
    try:
        response = client.confirm_sign_up(
            ClientId=os.environ["ClientId"],
            Username=username,
            ConfirmationCode=code,
            
        )
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred sending password reset code"})
            }
            
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps({"message": "Email verified successfully."})
        }
    except client.exceptions.CodeMismatchException:
        return {
            'statusCode': "400",
            "headers": headers,
            'body': json.dumps({"error": "The code provided was not valid"})
        }
    except client.exceptions.ExpiredCodeException:
        return {
            'statusCode': "400",
            "headers": headers,
            'body': json.dumps({"error": "The provided code has expired"})
        }
    except client.exceptions.UserNotFoundException:
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({"error": "The username was not found"})
        }
    # except client.exceptions.UserNotConfirmedException:
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "verified email", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured while verifying email."})
        }


def resend_activation_email(client,username):
    try:
        response = client.resend_confirmation_code(
            ClientId=os.environ["ClientId"],
            Username=username
        )
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred resending activation email."})
            }
            
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps({"message": "Activation email send successfully."})
        }
    except client.exceptions.UserNotFoundException:
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({"error": "The username was not found"})
        }
    # except client.exceptions.UserNotConfirmedException:
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "resend activation email", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured while verifying email."})
        }

        
    

def forgot_password(client, username):
    try:
        response = client.forgot_password(
            ClientId=os.environ["ClientId"],
            Username=username)
        if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
            return {
                'statusCode': "400",
                "headers": headers,
                'body': json.dumps({"error": "An error has occurred sending password reset code"})
            }
            
        return {
            'statusCode': "200",
            "headers": headers,
            'body': json.dumps({"message": "Successfully sent password reset code", "value": "email_sent"})
        }
    except client.exceptions.UserNotFoundException:
        return {
            'statusCode': "404",
            "headers": headers,
            'body': json.dumps({"error": "The username was not found"})
        }
    except client.exceptions.CodeDeliveryFailureException:
        return {
            'statusCode': "500",
            "headers": headers,
            'body': json.dumps({"error": "Unable to send code"})
        }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "username": username, "action": "forgot password", "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return {
            'statusCode': 500,
            "headers": headers,
            'body': json.dumps({"error": "An error has occured while generating forgot password code"})
        }


def get_user_data(accessToken):
    decoded = jwt.decode(accessToken, options={"verify_signature": False}) 
    memberData = get_member_data(decoded.get('username'))
    if memberData is not None:
        userType = 'Caregiver' if (len(memberData.get('CarereceiverMappingList',[]))>0 or memberData.get('athenaId','').strip()=='' or memberData.get('athenaId','').strip()=='NC') else 'Patient'
        return {'userType':userType,
                'isEnrolled':(memberData.get('athenaId','').strip()!='' and memberData.get('athenaId','').strip()!='NC'),
                'displayType':'Aetna' if (memberData.get('departmentId', '')=='Aetna') else 'Default' }
    else:
        return None

        
    
def get_member_data(id):
   dynamo = boto3.resource('dynamodb')
   memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
   memberMappingResponse = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(id))
   
       
   if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
        return None
 
   return memberMappingResponse["Items"][0]
def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )