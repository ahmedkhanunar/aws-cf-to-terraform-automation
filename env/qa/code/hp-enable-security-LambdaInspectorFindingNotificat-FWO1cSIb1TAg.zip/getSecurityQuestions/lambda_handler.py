import boto3
from boto3.dynamodb.conditions import Key
import os
import json

dynamo = boto3.resource('dynamodb')
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def lambda_handler(event, context):
       
   
   table = dynamo.Table(os.environ['SecurityQuestionMasterTable'])
   response = table.scan(FilterExpression=Key('Type').eq('SECURITY'))
   

   return {
            'statusCode': 200,
            'body': json.dumps({'data':response.get('Items',[])}),
            'headers': headers
            }
   
