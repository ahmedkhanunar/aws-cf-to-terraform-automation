import boto3
import botocore
import os
import logging
import urllib.parse
from datetime import date

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def lambda_handler(event, context):
    logger.info("New files uploaded to the source bucket.")
     
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    destination_bucket = os.environ["DestinationBucket"]
    source = {'Bucket': source_bucket, 'Key': key}
  
    today = date.today()

    customer_name = key.split('/')[0]
    dirname, fn = os.path.split(key)

    if customer_name.lower() == 'carefirst' or customer_name.lower() == 'carefirst_prd':
        path = os.environ["DestinationPath"] + "CareFirst" + "/Inputs/" + today.strftime('%Y%m%d') + "/" + fn
    elif customer_name.lower() == 'mhc':
        path = os.environ["DestinationPath"] + "MountainHealth" + "/Inputs/" + today.strftime('%Y%m%d') + "/" + fn
    elif customer_name.lower() == 'helloporter' or customer_name.lower() == 'porter':
        path = os.environ["DestinationPath"] + "Porter" + "/Inputs/" + today.strftime('%Y%m%d') + "/" + fn
    else:
        path = os.environ["DestinationPath"] + str(customer_name.lower().capitalize()) + "/Inputs/"  + today.strftime('%Y%m%d') + "/" + fn
    
    dirname_array = dirname.split('/')
    dir_path = dirname_array[0] + '/' + dirname_array[1]

    try:
        if dir_path == customer_name + "/inbound":
            response = s3.copy(source, destination_bucket, path)
            logger.info("File copied to the destination bucket successfully!")
    
        
    except botocore.exceptions.ClientError as error:
        logger.error("There was an error copying the file to the destination bucket")
        print('Error Message: {}'.format(error))
        
    except botocore.exceptions.ParamValidationError as error:
        logger.error("Missing required parameters while calling the API.")
        print('Error Message: {}'.format(error))
        
    try:
        if fn:
            delete = s3.delete_object(Bucket = source_bucket, Key = key)
            logger.info("File deleted from source bucket successfully!")
        
    except botocore.exceptions.ClientError as error:
        logger.error("There was an error deleting the source file")
        print('Error Message: {}'.format(error))
        
