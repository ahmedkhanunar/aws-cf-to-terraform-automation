const { getSalesforceToken, getRequest, postRequest, putRequest, getSalesforceGender } = require("./utils");
const moment = require('moment');

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};
const sf_profilesync_url = process.env.SF_API_PREFIX + "/services/apexrest/ProfileManagement/v1/";
let sfToken = "";

module.exports.handler  = async (event) => {
    console.log("Input Paylod");
    console.log (event.Records[0].Sns);
    const inputJson = JSON.parse(event.Records[0].Sns.Message);
    //console.log (inputJson);

    const ucAccountId = inputJson.accountID;
    console.log ("AccountID: " + ucAccountId);

    // UC API to get Account Details
    console.log(ucAPIPrefix + "/account/" + ucAccountId);
    
    try {
        // Get UC Account Details
        const accountPropList = "propertyIdentifiersList=careGiverFirstName,accountID,subscriberLastName,insuranceCarrier,careGiverFirstName2,subscriberDOB,careGiverHomePhone2,contractNumber,firstName,subscriberName,careGiverEmailAddress,primaryEmailAddress.emailAddress,careGiverRelationship2,careGiverHomePhone,lastName,memberIdentification,careGiverLastName2,dateofBirth,gender,careGiverMobilePhone,careGiverMobilePhone2,insuranceCarrierName,subscriberFirstName,careGiverEmailAddress2,careGiverRelationship,primaryPhoneNumber.phoneNumber,careGiverLastName,primaryAddress";
        const ucAccountDetails = await getRequest(ucAPIPrefix + "/account/" + ucAccountId + "?" + accountPropList, null, ucDefaultHeaders, false);
        console.log('Account Details is: ️', ucAccountDetails);

        if (ucAccountDetails['primaryEmailAddress_emailAddress'] === "") {
            console.log("Primary Email Address is missing, rejecting request");
            return {
                statusCode: 400,
                body: "{\"message\": \"Primary Email Address is missing\"}"
            };
        }

        // Get Salesforce token
        if (sfToken === "") {
            sfToken = await getSalesforceToken();
            console.log('NEW Salesforce Token: ️', sfToken);
        }
        else {
            console.log('USING EXISTING Salesforce Token: ️', sfToken);
        }

        // Get account addresses
        const ucAccountAddresses = await getRequest(ucAPIPrefix + "/accountAddress/?propertyIdentifiersList=address,accountAddressName,accountAddressID&f:account.accountID:EQ=" + ucAccountId, null, ucDefaultHeaders, false);
        console.log('Account Addresses: ️', JSON.stringify(ucAccountAddresses));


        let dob = moment(ucAccountDetails.dateofBirth.trim(), "YYYY-MM-DD", true);
        if (!dob.isValid()) dob = moment(ucAccountDetails.dateofBirth.trim(), "MM/DD/YYYY", true);

        let subscriberDob = moment(ucAccountDetails.subscriberDOB.trim(), "YYYY-MM-DD", true);
        if (!subscriberDob.isValid()) subscriberDob = moment(ucAccountDetails.subscriberDOB.trim(), "MM/DD/YYYY", true);

        // Build Salesforce Account Update Payload
        let sfPayload = {
            "requestObject": {
                "accountObject": {
                    "ucAccountId": ucAccountDetails.accountID,
                    "firstName": ucAccountDetails.firstName,
                    "lastName": ucAccountDetails.lastName,
                    "shortRef": "",
                    "email": ucAccountDetails['primaryEmailAddress_emailAddress'],
                    "dob": ucAccountDetails.dateofBirth.trim() === "" ? "12/31/1999" : dob.format("MM/DD/YYYY"),
                    "sex": getSalesforceGender(ucAccountDetails.gender),
                    "phone": ucAccountDetails['primaryPhoneNumber_phoneNumber']
                }
            }
        };
        
        sfPayload.requestObject.accountObject.careGivers = [];
        if (ucAccountDetails.careGiverLastName.trim() !== "") {
            sfPayload.requestObject.accountObject.careGivers.push(
                {
                    "ucCareGiverId": ucAccountId + "-1",
                    "firstName": ucAccountDetails.careGiverFirstName,
                    "lastName": ucAccountDetails.careGiverLastName,
                    "email": ucAccountDetails.careGiverEmailAddress,
                    "mobile": ucAccountDetails.careGiverMobilePhone,
                    "homePhone": ucAccountDetails.careGiverHomePhone,
                    "relationship": ucAccountDetails.careGiverRelationship,
                    "type": "Care Giver"
                }
            );
        }

        if (ucAccountDetails.careGiverLastName2.trim() !== "") {
            sfPayload.requestObject.accountObject.careGivers.push(
                {
                    "ucCareGiverId": ucAccountId + "-2",
                    "firstName": ucAccountDetails.careGiverFirstName2,
                    "lastName": ucAccountDetails.careGiverLastName2,
                    "email": ucAccountDetails.careGiverEmailAddress2,
                    "mobile": ucAccountDetails.careGiverMobilePhone2,
                    "homePhone": ucAccountDetails.careGiverHomePhone2,
                    "relationship": ucAccountDetails.careGiverRelationship2,
                    "type": "Care Giver"
                }
            );
        }
        
        if (ucAccountDetails.subscriberLastName.trim() !== "") {
            sfPayload.requestObject.accountObject.insuranceCompanies = [
                {
                    "policyHolderFirstName": ucAccountDetails.subscriberFirstName,
                    "policyHolderLastName": ucAccountDetails.subscriberLastName,
                    "policyHolderDOB": ucAccountDetails.subscriberDOB.trim() === "" ? "12/31/1999" : subscriberDob.format("MM/DD/YYYY"),
                    "memberId": ucAccountDetails.memberIdentification,
                    "carrier": ucAccountDetails.insuranceCarrierName,
                    "contractNumber": ucAccountDetails.contractNumber,
                }
            ];
        }

        if (ucAccountAddresses.pageRecords && ucAccountAddresses.pageRecords.length > 0) {
            sfPayload.requestObject.accountObject.Addresses = [];
            ucAccountAddresses.pageRecords.forEach (function (addresses) {
                const address = addresses.address[0];
                if (ucAccountDetails.primaryAddress && ucAccountDetails.primaryAddress.length > 0) {
                    if (ucAccountDetails.primaryAddress[0].accountAddressID === addresses.accountAddressID) {
                        sfPayload.requestObject.accountObject.Addresses.push ({
                            "nickname": addresses.accountAddressName,
                            "firstName": address.firstName,
                            "lastName": address.lastName,
                            "street1": address.streetAddress,
                            "street2": address.street2Address,
                            "city": address.city,
                            "state": address.stateCode,
                            "zip": address.postalCode,
                            "countryCode": address.countryCode,
                            "phone": address.phoneNumber,
                            "email": address.emailAddress,
                            "type": "Default",
                            "ucAddressId": addresses.accountAddressID
                        }); 
                    }
                }
            });
        }

        console.log(JSON.stringify(sfPayload));
        // Call the Salesforce API to update profile
        const sfHeaders = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sfToken.access_token
        }
        const sfResponse = await putRequest (sf_profilesync_url, sfPayload, sfHeaders);
        console.log("Salesforce Response*******");
        console.log(sfResponse);

        if (inputJson.salesforcePersonIdentifier == "") {
            console.log ("Updating Salesforce Profile ID in UC");
            const ucSFProfileIdPayload = {
                "salesforcePersonIdentifier": sfResponse.accountObject.sfAccountId
            };
            console.log("UC Salesforce Profile ID Payload", JSON.stringify(ucSFProfileIdPayload));
            const ucProfileUpdateRes = await postRequest(ucAPIPrefix + "/account/" + ucAccountId, ucSFProfileIdPayload, ucDefaultHeaders);
            console.log('UC Salesforce Profile ID Response: ️', ucProfileUpdateRes);
        }
        else {
            console.log ("Salesforce Profile ID is updated in UC, not updating it again...");
        }

        return {
            statusCode: 200,
            body: JSON.stringify(sfResponse)
        };
    }
    catch (err) {
        console.log(err);
        return {
            statusCode: 400,
            body: JSON.stringify(err)
        };
    }
};