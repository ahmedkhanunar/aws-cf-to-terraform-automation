import json
from datetime import datetime
import boto3
import os
import sys
import traceback
from functions import get_member
from functions import prepare_json
from functions import mapp_child
from functions import new_mapp_child
from functions import post_social
from functions import paramount_height
from functions import update_templates, get_cs_data, cs_mapper, prepare_json_cs, con_height, map_manual_questions, sub_que, additional_map, fetch_splits_athena, fetch_cf_new_split, additional_map_cf_new
from functions import prepare_json_cf2, prepare_json_cm, prepare_json_mhc_shorten, prepare_json_paramount
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs

lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    try:
        for record in event["Records"]:
            row = record['body'].encode().decode("utf-8") 
            print('sqs data:', row )
            
            check_template = json.loads(row)
     
            check_template = check_template[0]['screenings'][0]['templateId']
            #print('templateId - check', check_template)
            
            push_to_destination(check_template, row)
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))

def check_cf_old(check_template):
    return check_template == '361' or check_template == 'HRSCF001'

def check_cf_new(check_template):
    return check_template == 'HRSCF002'

def check_cs(check_template):
    return check_template == 'HRSCS001'

def check_mhc(check_template):
    return check_template == 'HRSMHC001'

def check_mhc_shorten(check_template):
    return check_template == 'MHCT2'

def check_paramount(check_template):
    return check_template == 'HRSMA001'

def traverse_prod_data(prod_data, csm):
    for k in prod_data:
            for v in csm:
                #[{'externalquestionId': 'CST1Q001', 'ehrKey': 'LOCAL.181'},
                if k['externalquestionId'] == v['externalquestionId']:
                    k['ehrKey'] = v['ehrKey']

def push_to_destination(check_template, row):
    if check_cf_old(check_template):
        patient_id , department_id = get_member(row)

        prepare_json(row, patient_id, department_id)
        
        #if patient_id == '293':
    elif check_cf_new(check_template): 
        patient_id , department_id = get_member(row)
        prod_data = get_cs_data(row) 
        data_question_manual_cf = fetch_cf_new_split(prod_data)
        additional_map_cf_new(prod_data,data_question_manual_cf )
        json_data_cf, complete_list =  prepare_json_cf2(row, patient_id, department_id, prod_data)

        #if patient_id == '164':
        lambda_client.invoke(FunctionName = os.environ['CarefirstLambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"data": json_data_cf, "patient_id": patient_id, "department_id": department_id}))
        update_templates(patient_id, check_template)
        post_social(complete_list, patient_id, check_template)
    elif check_cs(check_template):
        patient_id , department_id = get_member(row)
        prod_data = get_cs_data(row) 
        csm = cs_mapper()
        traverse_prod_data(prod_data, csm)

        height = con_height(prod_data) 
        data_question = fetch_splits_athena(prod_data)
        data_question_manual = map_manual_questions(data_question)
        another_query = sub_que(prod_data)
        prod_data = additional_map(prod_data,data_question_manual, another_query, height )
        json_data_cs, complete_list =  prepare_json_cs(row, patient_id, department_id, prod_data)
        
        # if patient_id == '18067':
        lambda_client.invoke(FunctionName = os.environ['ClearspringLambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"data": json_data_cs, "patient_id": patient_id, "department_id": department_id}))
        update_templates(patient_id, check_template)
        post_social(complete_list, patient_id, check_template)
    elif check_mhc(check_template):
        patient_id , department_id = get_member(row)
        if patient_id != 0:
            prod_data = get_cs_data(row)
            height = con_height(prod_data)
    
            json_data, complete_list = prepare_json_cm(row, patient_id, department_id, prod_data, height)
    
            # if patient_id == '62852':
            update_templates(patient_id, check_template)
            post_social(complete_list, patient_id, check_template)
        else:
            write_excpetion_to_sqs(json.dumps({"Exception": "wrong memberid or does not exist", "Date": str(datetime.now())}))
    elif check_mhc_shorten(check_template):
        patient_id , department_id = get_member(row)
        prod_data = get_cs_data(row)
        json_data, complete_list = prepare_json_mhc_shorten(row, patient_id, department_id, prod_data)

        # clientmemberid = 7444705 / patient_id = 846 QA env
        lambda_client.invoke(FunctionName = os.environ['MHCLambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"data": json_data, "patient_id": patient_id, "department_id": department_id}))
        update_templates(patient_id, check_template)
        post_social(complete_list, patient_id, check_template)
    elif check_paramount(check_template):
        patient_id , department_id = get_member(row)
        prod_data = get_cs_data(row)

        height = paramount_height(prod_data)
        json_data, complete_list = prepare_json_paramount(row, patient_id, department_id, prod_data, height)

        lambda_client.invoke(FunctionName = os.environ['ParamountLambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"data": json_data, "patient_id": patient_id, "department_id": department_id}))

        update_templates(patient_id, check_template)
        post_social(complete_list, patient_id, check_template)
    else :
        patient_id , department_id = get_member(row)
        if patient_id != 0:
            department_id = 'invalid-' + check_template
            prod_data = get_cs_data(row) 
            csm = cs_mapper()
            traverse_prod_data(prod_data, csm)
    
            height = con_height(prod_data) 
            data_question = fetch_splits_athena(prod_data)
            data_question_manual = map_manual_questions(data_question)
            another_query = sub_que(prod_data)
            prod_data = additional_map(prod_data,data_question_manual, another_query, height )
            prepare_json_cm(row, patient_id, department_id, prod_data, height)
        else:
            write_excpetion_to_sqs(json.dumps({"Exception": "invalid templateId", "Date": str(datetime.now())}))
        # if patient_id == '18067':
