const { getRequest, getSalesforceToken, postRequest } = require("./utils");

const ucHost = process.env.UC_HOST;
const ucAPIPrefix = "https://" + ucHost + "/api";
const ucAccessKey = process.env.UC_ACCESS_KEY;
const usAccessSecret = process.env.UC_ACCESS_SECRET;
const ucDefaultHeaders = {
    'Access-Key': ucAccessKey,
    'Access-Key-Secret': usAccessSecret,
    'Accept-Encoding': 'gzip',
    'Host': ucHost
};
const statusTypes = ['cancel', 'return']
const statusChangeTypeFor = ['order', 'items']
const methodOfContact = ['email', 'phone']
const sfOrderCaseAPI = process.env.SF_API_PREFIX + "/services/data/v54.0/sobjects/case";

exports.handler = async (event) => {
    console.log(JSON.stringify(event))
    //validate token
    const accountId = getAccountId(event.headers)
    if (!accountId) {
        return {
            statusCode: 401,
            body: "{\"message\": \"Invalid token\"}"
        };
    }
    const requestBody = JSON.parse(event.body)
    if (!isValidBody(requestBody)) {
        return {
            statusCode: 400,
            body: "{\"message\": \"Invalid body\"}"
        };
    }


    try {
        // Get UC order Details
        const orderPropList = "propertyIdentifiersList=orderID,orderNumber,account.accountID,account.primaryEmailAddress.emailAddress,account.primaryPhoneNumber.phoneNumber,salesforceOrderD";
        const ucOrderDetails = await getRequest(ucAPIPrefix + "/order/" + requestBody.orderId + "?" + orderPropList, null, ucDefaultHeaders, false);
        console.log(JSON.stringify(ucOrderDetails))
        requestBody.salesforceOrderD=ucOrderDetails.salesforceOrderD
        if (accountId != ucOrderDetails.account_accountID) {
            return {
                statusCode: 401,
                body: "{\"message\": \"Unauthorized to do this action\"}"
            };
        }

        let orderItemData = []
        if (requestBody.orderItems && requestBody.orderItems.length > 0) {
          
            for (const item of requestBody.orderItems) {
                const ucProductDetails = await getRequest(ucAPIPrefix + "/public/getEntity?urlTitle=" + item.sku_product_urlTitle + "&entityName=product", null, ucDefaultHeaders, false);
                let productSupplier = ''
                if(ucProductDetails && ucProductDetails.data && ucProductDetails.data.product){
                    productSupplier = ucProductDetails.data.product.productSupplier
                }
                orderItemData.push(`${item.sku_product_productName}/${item.quantity}/${productSupplier}`)
            }
            console.log(JSON.stringify(orderItemData))
            requestBody.orderItemData = orderItemData
        }

        await callSFOrderCaseAPI(requestBody, accountId)

        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 200,
            body: JSON.stringify({ message: 'Thank You. Your request has been submitted.' })
        };
    }
    catch (err) {
        console.log(err);
        return {
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Allow": "GET, OPTIONS, POST",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
                "Access-Control-Allow-Headers": "*"
            },
            statusCode: 400,
            body: JSON.stringify(err)
        };
    }
};




/**
 * Parse token
 * @param {String} token 
 * @returns payload string
*/
function parseToken(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const buff = Buffer.from(base64, 'base64');
    const payloadinit = buff.toString('ascii');
    const payload = JSON.parse(payloadinit);
    return payload
}

/**
 * validate body data
 * @param {JSON} requestBody 
 * @returns true if requestbody data is valid
 */
function isValidBody(requestBody) {

    if (!requestBody || !requestBody.orderId || !requestBody.status || !requestBody.statusChangeTypeFor || !requestBody.reason || !requestBody.methodOfContact || !methodOfContact.includes(requestBody.methodOfContact) || !statusTypes.includes(requestBody.status) || !statusChangeTypeFor.includes(requestBody.statusChangeTypeFor) || !requestBody.salesForceMemberId) {
        return false
    }

    return true
}

/**
 * Get account id from auth token
 * @param {*} headers 
 * @returns accountId
 */
function getAccountId(headers) {
    if (!headers || !headers.Authorization) {
        return null
    }

    const tokenPayload = parseToken(headers.Authorization)
    const accountId = tokenPayload.accountID
    if (!accountId)
        return null

    return accountId
}

/**
 * call SalesForce Order case api
 * @param {*} requestBody 
 * @param {*} accountId 
 */
async function callSFOrderCaseAPI(requestBody, accountId) {

    const sfToken = await getSalesforceToken();
    const subject = `${statusChangeTypeFor.indexOf(requestBody.statusChangeTypeFor) == 0 ? 'Order' : 'Order Items'} ${statusTypes.indexOf(requestBody.status) == 0 ? 'Cancellation Request' : 'Return Request'}`

   
    const sfPayload = {
        "Subject": subject,
        "PSC_Order__c": requestBody.salesforceOrderD,
        "AccountId": requestBody.salesForceMemberId,
        "Related_Order_Line_Items__c":(requestBody.orderItemData && requestBody.orderItemData.length>0)?requestBody.orderItemData.toString():'',
        "RecordTypeId":  process.env.SF_RECORD_TYPE_ID,
        "PSC_Order_Cancellation_Return_Reason__c": requestBody.reason,
        "PSC_Preferred_method_of_contact__c": requestBody.methodOfContact,
        "Type" : subject
    };

    console.log(JSON.stringify(sfPayload));
    // Call the Salesforce API to update profile
    const sfHeaders = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + sfToken.access_token
    }
    const sfResponse = await postRequest(sfOrderCaseAPI, sfPayload, sfHeaders);
    console.log("Salesforce Response*******");
    console.log(JSON.stringify(sfResponse));


}
