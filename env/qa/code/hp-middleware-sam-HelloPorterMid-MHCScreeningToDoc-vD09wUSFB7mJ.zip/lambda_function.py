import json
import boto3
import datetime
import docx
import shutil
from docx import Document

from boto3.dynamodb.conditions import Key, Attr
import sys
import io
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
import ast
import random
import os
import traceback
from datetime import datetime, date
import pandas as pd
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs

today = date.today()
null = None
region_name = 'us-east-1'
customer = "MountainHealth"
# template_file = "MHC_Shorten_2024_template.docx"
template_file = "MHC_Shorten_2024_03_26.docx"
# year_month_day = "20240422"
year_month_day = today.strftime('%Y%m%d')
template_ins = "MHCT2"
department_id = "4"
lambda_client = boto3.client('lambda')

def get_mapping():
    mapping = [
        {
            "question": "What is your preferred language?",
            "type": "text"
        },
        {
            "question": "What is your race & ethnicity?",
            "type": "text"
        },
        {
            "question": "Is there anything we should know about your race, ethnicity, culture, beliefs, or religious practices that would help us provide better care and services for you?",
            "type": "text"
        },
        {
            "question": "Do you have a primary care doctor?",
            "type": "yn"
        },
        {
            "question": "Name of primary care doctor",
            "type": "text"
        },
        {
            "question": "Have you had any difficulty getting an appointment with your primary care doctor in the last 6 months?",
            "type": "yn"
        },
        {
            "question": "Do you need help finding an in-network primary care doctor?",
            "type": "text"
        },
        {
            "question": "Do you see any specialists?",
            "type": "yn"
        },
        {
            "question": "If yes, confirm name(s) and specialty.",
            "type": "text"
        },
        {
            "question": "Have you been diagnosed with any chronic conditions for which you currently take medication?",
            "type": "yn"
        },
        {
            "question": "Have you had any surgeries?",
            "type": "yn"
        },
        {
            "question": "Do you often feel sad or depressed?",
            "type": "yn"
        },
        {
            "question": "Do you take any medication to help you sleep or improve your mood?",
            "type": "yn"
        },
        {
            "question": "Are you currently on any chronic pain medications?",
            "type": "yn"
        },
        {
            "question": "Have you lost any feeling in your feet?",
            "type": "yn"
        },
        {
            "question": "Do you use healthcare-related devices like a C-PAP, oxygen, blood pressure machine or glucometer?",
            "type": "yn"
        },
        {
            "question": "Do you use alcohol, tobacco or vape products?",
            "type": "yn"
        },
        {
            "question": "Do you use any illicit drugs or controlled substances?",
            "type": "yn"
        },
        {
            "question": "Do you exercise on a regular basis?",
            "type": "yn"
        },
        {
            "question": "Have you had a flu shot in the last year?",
            "type": "yn"
        },
        {
            "question": "Would you like help finding a location where you can get no cost a flu shot?",
            "type": "yn"
        },
        {
            "question": "Do you have trouble controlling your bladder, feel urgency or incontinence?",
            "type": "yn"
        },
        {
            "question": "Do you need any assistance with activities of daily living?",
            "type": "yn"
        },
        {
            "question": "Do you need help with any of the following activities: preparing meals, transportation, shopping, keeping house, making calls, etc?",
            "type": "yn"
        },
        {
            "question": "Have you fallen in the last year?",
            "type": "yn"
        },
        {
            "question": "Do you have housing?",
            "type": "yn"
        },
        {
            "question": "Are you worried about losing your housing?",
            "type": "yn"
        },
        {
            "question": "In the last 12 months: have you worried about being able to afford proper food, heat, water etc.?",
            "type": "yn"
        },
        {
            "question": "Do you have access to the internet?",
            "type": "yn"
        },
        {
            "question": "Do you have access to transportation to get where you need to go – appts, medication, etc.?",
            "type": "yn"
        },
    ]
    
    return mapping
    
def yn_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No'
    else:
        text_value = '☐  Yes   ☐  No'
    return text_value

def ynd_match(data):
    #print(data, 'IN ynd match')
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No   ☐  Don’t know'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No   ☐  Don’t know'
    elif  'know' in data.lower() :
        text_value = '☐  Yes   ☐  No   ☒  Don’t know'
    else:
        text_value = '☐  Yes   ☐  No   ☐  Don’t know'
    return text_value
    
def process_pdf(mapping_questions, completion_date, memberName, memberId):
    # -------------
    
    s3 = boto3.resource("s3")
    # bucket = s3.Bucket("databricks-workspace-stack-newdev-bucket")
    bucket = s3.Bucket(os.environ['BucketName'])

    object_in_s3 = bucket.Object(f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{customer}/Inputs/templates/{template_file}")
    object_as_streaming_body = object_in_s3.get()["Body"]
    print(f"Type of object_as_streaming_body: {type(object_as_streaming_body)}")
    object_as_bytes = object_as_streaming_body.read()
    print(f"Type of object_as_bytes: {type(object_as_bytes)}")

    # Now we use BytesIO to create a file-like object from our byte-stream
    object_as_file_like = io.BytesIO(object_as_bytes)
    
    # ------------
    
    s3_path = os.getenv("s3path", "/dbfs/FileStore/tables")
    # s3_path = os.getenv("s3path", "databricks-workspace-stack-newdev-bucket/nvirginia-prod/7413904104309051/FileStore/tables")
    # s3_path = '/dbfs/File'
    # document2 = Document(f"{s3_path}/Customer/Porter/Inputs/templates/{template_file}")
    document2 = Document(docx=object_as_file_like)
    style = document2.styles['Normal']
    fullText = []
    i = 0
    for para in document2.paragraphs: 
        i+=1
        inline = para.runs
        for run in inline:
            print('outside: ', run.text.strip())
            for data in mapping_questions:                
                if run.text == 'Date: ':
                    run.text = run.text + '\t\t\t\t\t'  +  completion_date # #datetime.strptime(completion_date, "%Y-%m-%d")
                if run.text.strip() == 'Member Name:':
                    run.text = run.text + '\t\t'  + memberName
                if run.text.strip() == 'Member ID:':
                    run.text = run.text + '\t\t\t\t'  + memberId
                if run.text.strip().lower() == data['question'].strip().lower() and data['type'] == 'yn' and data['answer'] is not None :
                    if data['question'].strip() == 'Do you need help with any of the following activities: preparing meals, transportation, shopping, keeping house, making calls,':
                        run.text = run.text
                    else:
                        run.text = run.text + '\t'
                    r = para.add_run(yn_match(data['answer']))
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text.strip() == data['question'] and data['type'] == 'text' and  data['answer'] is not None :
                    run.text = run.text   + '\t'
                    r = para.add_run(data['answer'])
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                
                if run.text.strip() == data['question'] and data['type'] == 'ynd' and  data['answer'] is not None :
                    run.text = run.text   + '\n'
                    j = para.add_run(ynd_match(data['answer']))
                    j.bold = True
                    j.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text == data['question'] and data['type'] == 'ytd' and  data['answer'] is not None :

                    run.text = run.text   + '\t\t\t\t'
                    k = para.add_run(yes_match(data['answer']))
                    k.bold = False
                    k.alignment=WD_ALIGN_PARAGRAPH.LEFT

    batch_date = today.strftime('%Y%m%d%H%M%S')

    filename = f"{customer}_HRA_{memberId}_{batch_date}.docx"
    
    file_path_part = f"{customer}/Outputs/{year_month_day}/docx/{filename}"

    path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}"
    s3 = boto3.client('s3', region_name='us-east-1')
    i = 0
    
    document2.save(f"/tmp/{filename}")
    try:
        s3.upload_file(f"/tmp/{filename}", os.environ['BucketName'], path)
        return {
            'statusCode': 200,
            'body': 'success',
            'path': path
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('cannot complete request')
        }

def parent_map(que):
    que_child = 1
    jsondata = {}
    jsondata['questionText'] = que['questionText']
    jsondata['questionId'] = que['questionId']
    jsondata['externalquestionId'] = que['externalquestionId']  if 'externalquestionId' in que.keys() else ''
    jsondata['ehrKey'] = que['ehrKey']
    jsondata['answerType'] = que['answerType']
    jsondata['answerDetails'] = que['answerDetails']
    jsondata['answer'] = que['answer']
    jsondata['Finalanswer'] = str(que['answer']) if str(que['answer']) !='None' else str(que['answerDetails'])

    return jsondata

def generate_docx(event):
    raw_data = event
    for data_pro in raw_data:    
        screenings = data_pro['screenings']
        if screenings[0]["templateId"] != template_ins:
            skip = 1
            continue
    
        memberName = data_pro['memberName']
        memberLifetimeID = data_pro['memberLifetimeID'] if ('memberLifetimeID' in data_pro.keys() and data_pro['memberLifetimeID'] is not None) else data_pro['memberId']
        questions = screenings[0]['questions']
        completion_date = screenings[0]['completionDate']
        completion_date = completion_date.split("T")[0]
    
        que_seq = 1    

        mbi = data_pro.get('mbi', "")
        memberId = data_pro['memberId']
        hContract = data_pro.get('contractId', "")
    
        final_data = []
        for que in questions:
            que_seq += 1
            que_child = 0
            que_child2 = 0
            dt = parent_map(que)
            final_data.append(dt)
            if str(que['children']) != 'None':
                que2 = que['children']
                for que1 in que2:
                    que_child += 1
                    dt = parent_map(que1)
                    final_data.append(dt)
                    if str(que1['children']) != 'None':
                        que3 = que1['children']
                        for que4 in que3:
                            que_child2 += 1
                            dt = parent_map(que4)
                            final_data.append(dt)
    
        df = pd.DataFrame(final_data)
    
        final_data_mapping = []
        for index, row in df.iterrows():
                data ={}
                data['question'] = row['questionText']
                data['answer'] = row['Finalanswer']
                data['type'] = row['answerType']
                data['ehrKey'] = row['ehrKey']
                final_data_mapping.append(data)
    
        mapping_questions = get_mapping()
        for ft in mapping_questions:
            for cf in final_data_mapping:
                if ft['question'] == cf['question']:
                    ft['answer'] = str(cf['answer'])
    
        for data in mapping_questions:
            if data['question'] == 'Do you need help with any of the following activities: preparing meals, transportation, shopping, keeping house, making calls, etc?':
                data['question'] = 'Do you need help with any of the following activities: preparing meals, transportation, shopping, keeping house, making calls,'
    
        result = process_pdf(mapping_questions, completion_date, memberName, memberId)
        return result

def lambda_handler(event, context):
    try:
        response = generate_docx(event.get("data", ""))

        if response.get("statusCode", "") == 200:
            lambda_client.invoke(FunctionName = os.environ['LambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"path": response.get('path', ""), "patient_id": event.get("patient_id", ""), "department_id": event.get("department_id", "")}))
        else:
            return response
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot generate mhc to docx')
        }
