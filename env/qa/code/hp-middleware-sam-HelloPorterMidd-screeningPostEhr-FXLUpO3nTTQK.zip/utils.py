import boto3
import os

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
    
def write__to_sqs(region_name: str, sqs_url: str, message: str) -> None:
    """
    Write a message to the passed in SQS queue.

    Parameters
    ----------
    region_name: str
        the aws region of where the sqs queue is
    sqs_url : str
        the url of the specific queue to write to
    message : str
        The exception message to write to the queue

    Raises
    ------
    boto3.exceptions.Boto3Error
        If there's an error writing to the queue
    KeyError
        If SQS_URL environment is incorrect
    """
    sqs = boto3.client('sqs', region_name=region_name)
    url = sqs_url
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )