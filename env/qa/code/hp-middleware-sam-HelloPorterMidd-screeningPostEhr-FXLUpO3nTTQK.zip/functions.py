import json
import os
import boto3
from boto3.dynamodb.conditions import Key, And
region_name = 'us-east-1'
import http.client
from base64 import b64encode
import requests
import time
token_data = {}
access_token =''
from datetime import datetime
today_date = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
from mapper_templates import get_mhc_mapping
from shorten_mhc_template import get_mhc_shorten_mapping
from paramount_template import get_paramount_mapping
import uuid


dynamodb = boto3.resource('dynamodb', region_name=region_name)
mappingtable =  dynamodb.Table('mw_member_mapping') 
screeningtable =  dynamodb.Table('sf_hra_screening_data') 
enrollment_table =  dynamodb.Table('mw_enrollment_details')
tokentable = dynamodb.Table("mw_test_token") # = dynamodb.Table("mw_test_token")
client_id = os.environ['client_id']
authHost = os.environ['authHost']
social_history_url = "/chart/configuration/socialhistory"
yes_no_str = "Yes/No"

def get_secret():
    secretId = os.environ["ATHENA_ID"]
    region_name = os.environ["REGION"]
    session = boto3.session.Session()
    client = session.client(
    service_name='secretsmanager',
    region_name=region_name,
    )
    session_token = client.get_secret_value(
    SecretId=secretId
    )
    return json.loads(session_token["SecretString"]).get(secretId, "")

def basic_auth(username, password):
    token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
    return f'Basic {token}'

def access_token_gen(conn, payload, headers):
    conn.request("POST", "/oauth2/v1/token", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data = json.loads(data)
    token_data['token'] = data['access_token']
    access_token = data['access_token']
    token_data['id'] = 'EHR'
    token_data['ts'] = str(int(time.time()))
    tokentable.put_item(Item=token_data)

    return access_token

def generate_ehr_token():
    auth_1 = basic_auth(client_id, get_secret())
    payload = 'grant_type=client_credentials&scope=athena/service/Athenanet.MDP.*'
    conn = http.client.HTTPSConnection(authHost)
    headers = { 
        'Authorization' : auth_1,
        'content-type': "application/x-www-form-urlencoded"
    }
    response = tokentable.query(KeyConditionExpression=Key('id').eq('EHR'))
    if len(response['Items'])  > 0:
        token_response = response['Items'][0]
        if ((int(time.time())) - (int(token_response['ts'])) < 3000): 
            access_token = token_response['token']
        else:
            access_token = access_token_gen(conn, payload, headers)
    else:
        access_token = access_token_gen(conn, payload, headers)
    return access_token

def change_yn(value):
    if value:
        if str(value).strip().lower() == 'yes':
            return "Y"
        elif str(value).strip().lower() == 'no':
            return "N"
    return value

def fetch_cf_new_split(final_data):
    cfn24 = [{'key' : 'LOCAL.308', 'ans' : 'No', 'answerType' : yes_no_str }, {'key' : 'LOCAL.309', 'ans' : 'No', 'answerType' : yes_no_str }, {'key' : 'LOCAL.310', 'ans' : 'No', 'answerType' : yes_no_str }, {'key' : 'LOCAL.311', 'ans' : 'No', 'answerType' : yes_no_str }, {'key' : 'LOCAL.312', 'ans' : 'No', 'answerType' : yes_no_str }]
    for n in final_data:
        print(n)
        if n['answerType'] == "Select Multiple":
            answer = n.get('Finalanswer', '').lower()
            print('answer: ', answer)
            for m in cfn24:
                if multi_select_check(m['key'], answer):
                    m['ans'] = 'Yes'
    return cfn24

def multi_select_check(key, answer):
    if 'cane' in answer and key == 'LOCAL.308':
        return True
    if 'walker' in answer and key == 'LOCAL.309':
        return True
    if 'wheelchair\n' in answer and key == 'LOCAL.310':
        return True
    if 'prosthetic' in answer and key == 'LOCAL.311':
        return True
    if 'electric' in answer and key == 'LOCAL.312':
        return True
    return False

def check_is_cf(check_template):
    if check_template == '361' or check_template == 'HRSCF001' or check_template == 'HRSCF002':
        return True

def check_is_mhc(check_template):
    if check_template == 'HRSMHC001':
        return True

def check_is_mhc_short(check_template):
    if check_template == 'MHCT2':
        return True
    
def check_is_paramount(check_template):
    if check_template == 'HRSMA001':
        return True

def check_is_cs(check_template):
    if check_template == '362' or check_template == '402' or check_template == 'HRSCS001':
        return True

def check_is_centene(check_template):
    if check_template == 'HRSCEN001':
        return True

def update_templates(patient_id, check_template):
    tokendata = generate_ehr_token()
    if check_template == '361' or check_template == 'HRSCF001':
        temp_data = {'templateids': '361', 'templatename': 'CF HRS'}
        department_id = '1'
    elif check_is_cs(check_template):
        department_id = '3'
        temp_data = {'templateids': '402', 'templatename': 'CS HRS'}
    elif check_template == 'HRSCF002':
        department_id = '1'
        temp_data = {'templateids': '421', 'templatename': 'CF 2024'}
    elif check_is_mhc(check_template):
        department_id = '4'
        temp_data = {'templateids': '461', 'templatename': 'HRS - MHC 2024'}
    elif check_is_mhc_short(check_template):
        department_id = '4'
        temp_data = {'templateids': '481', 'templatename': 'Short HRS - MHC 2024'}
    elif check_is_paramount(check_template):
        department_id = '5'
        temp_data = {'templateids': '501', 'templatename': 'Paramount - HRS 2024'}
    elif check_is_centene(check_template):
        department_id = '6'
        temp_data = {'templateids': '501', 'templatename': 'Centene - HRS 2024'}

    patientURL_sub =  os.environ.get('patientURL')
    practice_id = os.environ.get('practice_id')

    patient_url = str(patientURL_sub)   + str(practice_id) + "/" + "chart/"+ patient_id + "/socialhistory/templates?departmentid=" + str(department_id)
    post_headers = {
        "Accept": "application/json",
        "Authorization" : "Bearer " + tokendata ,
        "Content-Type" : "application/x-www-form-urlencoded"
    }
    print('patient url is :', patient_url)
    response = requests.request("PUT", patient_url, headers=post_headers, data=temp_data)
    response_data = response.text
    response_data = json.loads(response_data)
    print('template data')
    print(response_data)
    return response.text
    
def post_social(json_data, patient_id, check_template):
    tokendata = generate_ehr_token()
    json_data = json.dumps(json_data)
    practice_id = os.environ.get('practice_id')
    if check_is_cf(check_template):
        department_id = '1'
    elif check_is_cs(check_template):
        department_id = '3'
    elif check_template == '461' or check_is_mhc(check_template) or check_template == '481' or check_is_mhc_short(check_template):
        department_id = '4'
    elif check_template == '501' or check_is_paramount(check_template):
        department_id = '5'
    elif check_is_centene(check_template):
        department_id = '6'

    patientURL_sub =  os.environ.get('patientURL')

    post_headers = {
        "Accept": "application/json",
        "Authorization" : "Bearer " + tokendata ,
        "Content-Type" : "application/x-www-form-urlencoded"
    }
    data = {
        'questions': json_data,
        'sectionnote': 'Health Risk Screening',
        'departmentid': str(department_id),
    }
    patient_url = str(patientURL_sub) + str(practice_id) + "/" + "chart/"+ patient_id + "/socialhistory"
    print('patient url is :', patient_url)
    response = requests.put(patient_url, headers=post_headers, data=data)
    print(response)
    return response.text

def get_member(row):
    row = json.loads(row)
    for data in row:
        memberId = data.get('memberId', "")
        print("memberId: ", memberId)
        if (memberId == None) or (memberId == ""):
            continue
        response = mappingtable.query(KeyConditionExpression=Key('ClientMemberId').eq(memberId), IndexName='ClientMemberId-index')
        if len(response['Items'])  > 0:
            patient_id = response['Items'][0]['athenaId']
            department_id = response['Items'][0]['departmentId']
        else:
            patient_id = ''
            department_id =''
        return patient_id, department_id
    patient_id = 0
    department_id =0
    return patient_id, department_id
    
def get_ehr_keys(questions):
    prod_data = []
    for que in questions:
        meta_json = {}
        ehrKey = que['ehrKey']
        queKey = que['questionId']
        que_text = que['questionText']
        answerType = que['answerType']
        child_text = que['children']
        answerDetails = que['answerDetails']
        answer = que['answer']
        if ehrKey == 'LOCAL.61':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answerDetails
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.62':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answerType'] = answerType
            for ch in child_text:
                if ch['questionText'] == 'Feet':
                    feet = ch['answer'] + ' ' + 'Feet'
                elif ch['questionText'] == 'Inches':
                    Inches = ' ' +  ch['answer'] + ' ' + 'Inches'
            meta_json['answer'] =  feet + Inches
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.63':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answerDetails
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.64': 
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerDetails = ch['answerDetails']
                answerType = ch['answerType'] 
                queKey = ch['questionId']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.68':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = que['questionId']
                answer = ch['answer']
                answerType = ch['answerType'] 
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answer
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.71':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.72':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerType = ch['answerType']
                answerDetails = ch['answerDetails']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.74':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerDetails = ch['answerDetails']
                answerType = ch['answerType']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.76':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerDetails = ch['answerDetails']
                answerType = ch['answerType']
                if ehrKey == 'LOCAL.77' :
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answerDetails
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
        elif ehrKey == 'LOCAL.78':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answerDetails
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.79':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.80':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.81':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerType = ch['answerType']
                answer = ch['answer']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answer
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.84':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.85':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerType = ch['answerType']
                answerDetails = ch['answerDetails']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif que_text == 'Have you received the following vaccines?':
            for ch in child_text:
                if ch['ehrKey'] == 'LOCAL.87':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    meta_json['queKey'] = queKey
                    answerType = ch['answerType']
                    answer = ch['answer']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.90':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answer = ch['answer']
                    answerType = ch['answerType']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.93':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answer = ch['answer']
                    answerType = ch['answerType']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.96':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answerType = ch['answerType']
                    answer = ch['answer']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
        elif que_text == 'Have you received the following screenings?':
            for ch in child_text:
                if ch['ehrKey'] == 'LOCAL.99':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answerType = ch['answerType']
                    answer = ch['answer']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.102':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answer = ch['answer']
                    answerType = ch['answerType']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerType = ch2['answerType']
                        answerDetails = ch2['answerDetails']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.105':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answer = ch['answer']
                    answerType = ch['answerType']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerDetails = ch2['answerDetails']
                        answerType = ch2['answerType']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.108':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answerType = ch['answerType']
                    answer = ch['answer']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerDetails = ch2['answerDetails']
                        answerType = ch2['answerType']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
                elif ch['ehrKey'] == 'LOCAL.111':
                    ehrKey = ch['ehrKey']
                    queKey = ch['questionId']
                    answerType = ch['answerType']
                    answer = ch['answer']
                    meta_json['ehrKey'] = ehrKey
                    meta_json['queKey'] = queKey
                    meta_json['answer'] = answer
                    meta_json['answerType'] = answerType
                    prod_data.append(meta_json)
                    meta_json = {}
                    for ch2 in ch['children']:
                        ehrKey = ch2['ehrKey']
                        queKey = ch2['questionId']
                        answerDetails = ch2['answerDetails']
                        answerType = ch2['answerType']
                        meta_json['ehrKey'] = ehrKey
                        meta_json['queKey'] = queKey
                        meta_json['answer'] = answerDetails
                        meta_json['answerType'] = answerType
                        prod_data.append(meta_json)
                        meta_json = {}
        elif ehrKey == 'LOCAL.114':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerDetails = ch['answerDetails']
                answerType = ch['answerType']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.116':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerType = ch['answerType']
                answer = ch['answer']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answer
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif que_text == 'Do you need assistance completing the following activities?':
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answer = ch['answer']
                answerType = ch['answerType']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answer
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.127':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answerType = ch['answerType']
                answerDetails = ch['answerDetails']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answerDetails
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
        elif ehrKey == 'LOCAL.130':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.131':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.132':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.133':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.134':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.138':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif ehrKey == 'LOCAL.139':
            meta_json['ehrKey'] = ehrKey
            meta_json['queKey'] = queKey
            meta_json['answer'] = answer
            meta_json['answerType'] = answerType
            prod_data.append(meta_json)
            meta_json = {}
        elif que_text == 'In the last 12 months:' :
            for ch in child_text:
                ehrKey = ch['ehrKey']
                queKey = ch['questionId']
                answer = ch['answer']
                answerType = ch['answerType']
                meta_json['ehrKey'] = ehrKey
                meta_json['queKey'] = queKey
                meta_json['answer'] = answer
                meta_json['answerType'] = answerType
                prod_data.append(meta_json)
                meta_json = {}
    return prod_data
###

def additional_map_cf_new(prod_data,data_question_manual_cf ):
    for que2 in data_question_manual_cf:
        data = {}
        data['externalquestionId'] = ''
        data['Finalanswer'] = que2['ans']
        data['answerType'] = yes_no_str
        data['ehrKey'] = que2['key']
        prod_data.append(data)
        print(data)
    return prod_data

def data_mapping(row):
    for data1 in row:
        member_id = data1['memberId'] if 'memberId' in data1.keys() else ''
        member_name =  data1['memberName']  if 'memberName' in data1.keys() else ''
        mbi =  data1['mbi']  if 'mbi' in data1.keys() else ''
        member_lifetime_id =  data1['memberLifetimeID']  if 'memberLifetimeID' in data1.keys() else ''
        h_contract =  data1['hContract']  if 'hContract' in data1.keys() else ''
        completion_date =  data1['screenings'][0]['completionDate']
        template_id = data1['screenings'][0]['templateId']
    
    return member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id

def prep_json_step_one(department_id):
    payload2 = { 
        "departmentId": str(department_id),
        "limit" : 10
        }
    tokendata = generate_ehr_token()
    practice_id = os.environ.get('practice_id')
    patient_url =  os.environ.get('patientURL')
    post_headers = {
        "Accept": "application/json",
        "Authorization" : "Bearer " + tokendata ,
        "Content-Type" : "application/x-www-form-urlencoded"
    }
    patient_url = patient_url + str(practice_id) + social_history_url
    response = requests.request("GET", patient_url, params=payload2,  headers=post_headers)
    response_data = response.text
    response_data = json.loads(response_data)

    return response_data

def loop_thru_questions_list(questions_list):
    complete_list = []
    for questions in questions_list:
        prepared_json = {}
        prepared_json['key'] = questions['key']
        complete_list.append(prepared_json)

    return complete_list

def put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list):
    dynamo_data = {}   
    dynamo_uuid = uuid.uuid4()
    dynamo_data['uuid'] = str(dynamo_uuid)
    dynamo_data['athenaId'] = patient_id
    dynamo_data['date_posted'] = str(today_date)
    dynamo_data['department_id'] = department_id
    dynamo_data['Version'] =""
    dynamo_data['template_id'] = template_id
    dynamo_data['memberName'] = member_name
    dynamo_data['memberId'] = str(member_id)
    dynamo_data['MBI'] = str(mbi)
    dynamo_data['memberLifetimeID'] = str(member_lifetime_id)
    dynamo_data['contractId'] = str(h_contract)
    dynamo_data['completionDate'] = str(completion_date)
    dynamo_data['raw_data'] = str(row)
    dynamo_data['screening_data'] = json.dumps(complete_list)

    screeningtable.put_item(Item=dynamo_data)

def prepare_json_cf2(row, patient_id, department_id,prod_data ):
    response_data = prep_json_step_one(department_id)

    for temp in response_data:
        if  temp['templateid'] == '421' :
            questions_list = temp['questions'] if  temp['questions'] is not None else csfg
            complete_list = loop_thru_questions_list(questions_list)
    
    row = json.loads(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)
    for dts in prod_data:
        if dts['answerType'] is None or dts['answerType'] == '' :
            dts['answerType'] = 'Undefined'
        dts = loop_thru_prod_data(dts)
        complete_list = loop_thru_complete_list(complete_list, dts)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    return row, complete_list

def prepare_json(row, patient_id, department_id) :
    prepared_json = {}
    complete_list = []

    response_data = prep_json_step_one(department_id)

    #print('temp',response_data )
    for temp in response_data:
        if temp['templateid'] == "361" :
            questions_list = temp['questions']
            for questions in questions_list:
                prepared_json = {}
                prepared_json['question'] = questions['question']
                prepared_json['ordering'] = questions['ordering']
                prepared_json['questionid'] = questions['questionid']
                prepared_json['key'] = questions['key']
                complete_list.append(prepared_json)
    
    
    row = json.loads(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)
    
    for data in row:
        screening = data['screenings']
        template_id = screening[0]['templateId'] 
        for screen_event in screening:
            questions = screen_event['questions']
            prod_data = get_ehr_keys(questions)
            #print("prod data", prod_data)
            for dts in prod_data:
                if dts['answerType'] ==yes_no_str and str(dts['answer']).lower() == 'yes':
                    dts['answer'] = 'Y'
                elif dts['answerType'] ==yes_no_str and str(dts['answer']).lower() == 'no':
                    dts['answer'] = 'N'
                for lst in complete_list:
                    if lst['key'] == dts['ehrKey']:
                        lst['answer'] = dts['answer']
                    
    # complete_list[:] = [d for d in complete_list if d.get('answer') != 'invalid']
    # # for finalchange in complete_list:
    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    complete_list[0] = {i:j for i,j in complete_list[0].items() if j != 'invalid'}
    print("after ",  complete_list )
    return row
    
    
def mapp_child(row):
    new_mapping_list = []
    child_dict = {}
    row = json.loads(row)
    for data in row:
        screening = data['screenings']
        for screen_event in screening:
            question_captured = screen_event['questions']
            for txt in question_captured:
                if 'children'  in txt.keys() :
                    qp = txt['questionText']
                    if qp == 'Do you often feel sad, depressed, anxious, or nervous?':
                        child_dict['questionid'] = '554'
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                    elif qp == 'Do you have a primary care doctor?':
                        child_dict['questionid'] = ''
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if 'children' in txt.keys():
                            if txt['children'][0]['questionText'] =='If yes, PCP Name:':
                                child_dict['questionid'] = '503'
                                if 'answerDetails' in txt['children'][0]:
                                    child_dict['answer'] = txt['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][1]['questionText'] =='PCP Address (city/state):':
                                child_dict['questionid'] = '504'
                                if 'answerDetails' in txt['children'][1]:
                                    child_dict['answer'] = txt['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][2]['questionText'] =='Date of last visit (month/year):':
                                child_dict['questionid'] = '505'
                                if 'answerDetails' in txt['children'][2]:
                                    child_dict['answer'] = txt['children'][2]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                    elif qp == 'Do you have an Advanced Directive, Living Will, or Medical Power of Attorney?':
                        child_dict['questionid'] = '506'
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if 'children' in txt.keys():
                            if txt['children'][0]['questionText'] =='If yes, have you shared it with your PCP?':
                                child_dict['questionid'] = '507'
                                if 'answerDetails' in txt['children'][0]:
                                    child_dict['answer'] = txt['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][1]['questionText'] =='If no, would you like more information?':
                                child_dict['questionid'] = '508'
                                if 'answerDetails' in txt['children'][1]:
                                    child_dict['answer'] = txt['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                    elif qp == 'Do/did you smoke?':
                        child_dict['questionid'] = '519'
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][0]['questionText'] =='How many packs per day do you/did you smoke?':
                            child_dict['questionid'] = '520'
                            if 'answerDetails' in txt['children'][0]:
                                child_dict['answer'] = txt['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if txt['children'][1]['questionText'] =='How many years have you/did you smoke?':
                            child_dict['questionid'] = '521'
                            if 'answerDetails' in txt['children'][1]:
                                child_dict['answer'] = txt['children'][1]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                    elif qp == 'Have you received the following vaccines?':
                        child_dict['questionid'] = ''
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][0]['questionText'] =='Pneumonia':
                            child_dict['questionid'] = '525'
                            
                            if 'answerDetails' in txt['children'][0]:
                                child_dict['answer'] = txt['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if txt['children'][0]['children'][0]['questionText'] =='If yes, date (month/year):':
                                child_dict['questionid'] = '526'
                                if 'answerDetails' in txt['children'][0]['children'][0]:
                                    child_dict['answer'] = txt['children'][0]['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][0]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                                child_dict['questionid'] = '527'
                                if 'answerDetails' in txt['children'][0]['children'][1]:
                                    child_dict['answer'] = txt['children'][0]['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                        if txt['children'][1]['questionText'] =='Shingles':
                            child_dict['questionid'] = '528'
                            if 'answerDetails' in txt['children'][0]:
                                child_dict['answer'] = txt['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if txt['children'][1]['children'][0]['questionText'] =='If yes, date (month/year):':
                                child_dict['questionid'] = '529'
                                if 'answerDetails' in txt['children'][1]['children'][0]:
                                    child_dict['answer'] = txt['children'][1]['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][1]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                                child_dict['questionid'] = '530'
                                if 'answerDetails' in txt['children'][1]['children'][1]:
                                    child_dict['answer'] = txt['children'][1]['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                        if txt['children'][1]['questionText'] =='Flu':
                            child_dict['questionid'] = '531'
                            if 'answerDetails' in txt['children'][2]:
                                child_dict['answer'] = txt['children'][2]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if txt['children'][2]['children'][0]['questionText'] =='If yes, date (month/year):':
                                child_dict['questionid'] = '532'
                                if 'answerDetails' in txt['children'][2]['children'][0]:
                                    child_dict['answer'] = txt['children'][2]['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][2]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                                child_dict['questionid'] = '533'
                                if 'answerDetails' in txt['children'][2]['children'][1]:
                                    child_dict['answer'] = txt['children'][2]['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                        if txt['children'][1]['questionText'] =='COVID':
                            child_dict['questionid'] = '534'
                            if 'answerDetails' in txt['children'][3]:
                                child_dict['answer'] = txt['children'][3]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if txt['children'][3]['children'][0]['questionText'] =='If yes, date (month/year):':
                                child_dict['questionid'] = '535'
                                if 'answerDetails' in txt['children'][3]['children'][0]:
                                    child_dict['answer'] = txt['children'][3]['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][3]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                                child_dict['questionid'] = '536'
                                if 'answerDetails' in txt['children'][3]['children'][1]:
                                    child_dict['answer'] = txt['children'][3]['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                    for child in txt['children']:
                        qt1 = child['questionText']
                        if qt1 =='FEMALE ONLY: Cervical cancer (PAP smear)':
                            child_dict['questionid'] = '549'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '550'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '551'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='FEMALE ONLY: Mammogram':
                            child_dict['questionid'] = '543'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '544'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '545'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='FEMALE ONLY: Bone density scan (for osteoporosis)':
                            child_dict['questionid'] = '546'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '547'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '548'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='MALE ONLY: Prostate cancer':
                            child_dict['questionid'] = '540'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '541'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '542'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if qt1 =='Colorectal (colonoscopy) in the last 10 years?':
                            child_dict['questionid'] = '537'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '538'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '539'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        elif qt1 =='If yes, are you seeing a mental health provider?':
                            child_dict['questionid'] = '555'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='Did you worry that your food would run out before you had money to buy more?':
                            child_dict['questionid'] = '573'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='Did the food you bought just not last, and you did not have money to get more?':
                            child_dict['questionid'] = '574'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        elif qt1 =='Have you or the family you live with been unable to get utilities?':
                            child_dict['questionid'] = '575'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
        return new_mapping_list  
        
##

def new_mapp_child(row):
    new_mapping_list = []
    child_dict = {}
    row = json.loads(row)
    for data in row:
        screening = data['screenings']
        for screen_event in screening:
            question_captured = screen_event['questions']
            #for txt in question_captured:
            for txt in question_captured:
                qp = txt['questionText']
                if qp == 'What is your height?':
                    child_dict['questionid'] = '500'
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'Feet':
                        if 'answer' in qp2[0].keys():
                            antx = qp2[0]['answer'] + " Feet "
                    if qp2[1]['questionText'] == 'Inches':
                        if 'answer' in qp2[0].keys():
                            antx = antx + " " + qp2[1]['answer'] + " Inches "
                    child_dict['answer'] =  antx
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Do you have a primary care doctor?':
                        child_dict['questionid'] = '502'
                        if 'answer' in txt.keys():
                                child_dict['answer'] = txt['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if 'children' in txt.keys():
                            if txt['children'][0]['questionText'] =='If yes, PCP Name:':
                                child_dict['questionid'] = '503'
                                if 'answerDetails' in txt['children'][0]:
                                    child_dict['answer'] = txt['children'][0]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][1]['questionText'] =='PCP Address (city/state):':
                                child_dict['questionid'] = '504'
                                if 'answerDetails' in txt['children'][1]:
                                    child_dict['answer'] = txt['children'][1]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                            if txt['children'][2]['questionText'] =='Date of last visit (month/year):':
                                child_dict['questionid'] = '505'
                                if 'answerDetails' in txt['children'][2]:
                                    child_dict['answer'] = txt['children'][2]['answerDetails']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                        
                if qp == 'Do you have an Advanced Directive, Living Will, or Medical Power of Attorney?':
                    child_dict['questionid'] = '506'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    if 'answer' in txt.keys() :
                        if txt['answer'].lower() == 'yes' :
                            if 'children' in txt.keys():
                                if txt['children'][0]['questionText'] =='If yes, have you shared it with your PCP?':
                                    child_dict['questionid'] = '507'
                                    if 'answerDetails' in txt.keys():
                                        child_dict['answer'] = txt['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        elif 'answer' in txt.keys() :
                            if txt['answer'].lower() == 'no' :
                                if txt['children'][1]['questionText'] =='If no, would you like more information?':
                                    child_dict['questionid'] = '508'
                                    if 'answerDetails' in txt.keys():
                                        child_dict['answer'] = txt['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                if qp == 'Do you have any planned surgeries?':
                    child_dict['questionid'] = '510'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'If yes, when?':
                        child_dict['questionid'] = '511'
                        if 'answer' in qp2[0].keys():
                            child_dict['answer'] =  qp2[0]['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Have you recently been to the emergency room?':
                    child_dict['questionid'] = '512'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'If yes, why?':
                        child_dict['questionid'] = '513'
                        if 'answer' in qp2[0].keys():
                            child_dict['answer'] =  qp2[0]['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Have you stayed overnight in the hospital within the last 12 months?':
                    child_dict['questionid'] = '514'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'If \"Yes\", how many times?':
                        child_dict['questionid'] = '515'
                        if 'answerDetails' in qp2[0].keys():
                            child_dict['answer'] =  qp2[0]['answerDetails']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Do/did you smoke?':
                    child_dict['questionid'] = '519'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'How many packs per day do you/did you smoke?':
                        child_dict['questionid'] = '520'
                        if 'answer' in qp2[0].keys():
                            child_dict['answer'] =  qp2[0]['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    if qp2[1]['questionText'] == 'How many years have you/did you smoke?':
                        child_dict['questionid'] = '521'
                        if 'answer' in qp2[1].keys():
                            child_dict['answer'] =  qp2[1]['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Do you use illicit drugs or abuse medications?':
                    child_dict['questionid'] = '523'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'If yes, what are you taking?':
                        child_dict['questionid'] = '524'
                        if 'answer' in qp2[0].keys():
                            child_dict['answer'] =  qp2[0]['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Have you received the following vaccines?':
                    child_dict['questionid'] = ''
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    if txt['children'][0]['questionText'] =='Pneumonia':
                        child_dict['questionid'] = '525'
                        
                        if 'answer' in txt['children'][0]:
                            child_dict['answer'] = txt['children'][0]['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][0]['children'][0]['questionText'] =='If yes, date (month/year):':
                            child_dict['questionid'] = '526'
                        
                            if 'answerDetails' in txt['children'][0]['children'][0]:
                                child_dict['answer'] = txt['children'][0]['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if txt['children'][0]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                            child_dict['questionid'] = '527'
                        
                            if 'answerDetails' in txt['children'][0]['children'][1]:
                                child_dict['answer'] = txt['children'][0]['children'][1]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                    if txt['children'][1]['questionText'] =='Shingles':
                        child_dict['questionid'] = '528'
                        
                        if 'answer' in txt['children'][1]:
                            child_dict['answer'] = txt['children'][1]['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][1]['children'][0]['questionText'] =='If yes, date (month/year):':
                            child_dict['questionid'] = '529'
                        
                            if 'answerDetails' in txt['children'][1]['children'][0]:
                                child_dict['answer'] = txt['children'][1]['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if txt['children'][1]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                            child_dict['questionid'] = '530'
                        
                            if 'answerDetails' in txt['children'][1]['children'][1]:
                                child_dict['answer'] = txt['children'][1]['children'][1]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                    if txt['children'][2]['questionText'] =='Flu':
                        child_dict['questionid'] = '531'
                        if 'answer' in txt['children'][2]:
                            child_dict['answer'] = txt['children'][2]['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][2]['children'][0]['questionText'] =='If yes, date (month/year):':
                            print('question matched level 2')
                            child_dict['questionid'] = '532'
                        
                            if 'answerDetails' in txt['children'][2]['children'][0]:
                                child_dict['answer'] = txt['children'][2]['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if txt['children'][2]['children'][1]['questionText'] =='Where (PCP, pharmacy, etc.):':
                            print('question matched level 2')
                            child_dict['questionid'] = '533'
                        
                            if 'answerDetails' in txt['children'][2]['children'][1]:
                                child_dict['answer'] = txt['children'][2]['children'][1]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                    if txt['children'][3]['questionText'] =='COVID':
                        child_dict['questionid'] = '534'
                        if 'answer' in txt['children'][3]:
                            child_dict['answer'] = txt['children'][3]['answer']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                        if txt['children'][3]['children'][0]['questionText'] =='If yes, date (month/year):':
                            print('question matched level 2')
                            child_dict['questionid'] = '535'
                        
                            if 'answerDetails' in txt['children'][3]['children'][0]:
                                child_dict['answer'] = txt['children'][3]['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if txt['children'][3]['children'][2]['questionText'] =='Where (PCP, pharmacy, etc.):':
                            print('question matched level 2')
                            child_dict['questionid'] = '536'
                        
                            if 'answerDetails' in txt['children'][3]['children'][2]:
                                child_dict['answer'] = txt['children'][3]['children'][2]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                if qp == 'In the last 4 weeks, how much body pain have you experienced?':
                    child_dict['questionid'] = '552'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    print('upper level')
                    if txt['children'][0]['questionText'] =='If so, where?':
                        child_dict['questionid'] = '553'
                        if 'answerDetails' in txt['children'][0]:
                            child_dict['answer'] = txt['children'][0]['answerDetails']
                        new_mapping_list.append(child_dict)
                        child_dict = {}
                if qp == 'Do you often feel sad, depressed, anxious, or nervous?':
                    child_dict['questionid'] = '554'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    if 'children' in txt.keys():
                        if txt['children'][0]['questionText'] =='If yes, are you seeing a mental health provider?':
                            child_dict['questionid'] = '555'
                            if 'answerDetails' in txt['children'][0]:
                                child_dict['answer'] = txt['children'][0]['answerDetails']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                if qp == 'Do you need assistance completing the following activities?':
                    if 'answer' in txt.keys():
                        answerText = txt['answer']
                        if 'Grocery shopping/getting food' in answerText:
                            child_dict['questionid'] = '560'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'Cooking/preparing meals' in answerText:
                            child_dict['questionid'] = '561'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'eating' in answerText:
                            child_dict['questionid'] = '562'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'Bathing' in answerText:
                            child_dict['questionid'] = '556'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'Obtaining or taking your meds' in answerText:
                            child_dict['questionid'] = '564'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'dressed' in answerText:
                            child_dict['questionid'] = '557'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'standing?' in answerText:
                            child_dict['questionid'] = '558'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'toilet?' in answerText:
                            child_dict['questionid'] = '559'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'eating' in answerText:
                            child_dict['questionid'] = '562'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if 'phone' in answerText:
                            child_dict['questionid'] = '563'
                            child_dict['answer'] = 'Yes'
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                if qp == 'Have you fallen in the last 12 months?':
                    child_dict['questionid'] = '565'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    qp2 = txt['children']
                    if qp2[0]['questionText'] == 'If yes, how many times:':
                        child_dict['questionid'] = '566'
                    if 'answerDetails' in qp2[0].keys():
                        child_dict['answer'] =  qp2[0]['answerDetails']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                    if qp2[1]['questionText'] == 'Any injuries?':
                        child_dict['questionid'] = '567'
                    if 'answerDetails' in qp2[1].keys():
                        child_dict['answer'] =  qp2[1]['answerDetails']
                    new_mapping_list.append(child_dict)
                    child_dict = {} 
                if qp == 'Do you have transportation to get you where you need to go?':
                    child_dict['questionid'] = '577'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if qp == 'Do you have access to the internet?':
                    child_dict['questionid'] = '576'
                    if 'answer' in txt.keys():
                            child_dict['answer'] = txt['answer']
                    new_mapping_list.append(child_dict)
                    child_dict = {}
                if 'children'  in txt.keys() :
                    for child in txt['children']:
                        qt1 = child['questionText']
                        if qt1 =='Colorectal (colonoscopy) in the last 10 years?':
                                child_dict['questionid'] = '537'
                                if 'answer' in child.keys():
                                    child_dict['answer'] = child['answer']
                                new_mapping_list.append(child_dict)
                                child_dict = {}
                                if 'children' in child.keys():
                                    if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                        child_dict['questionid'] = '538'
                                        if 'answerDetails' in child['children'][0]:
                                            child_dict['answer'] = child['children'][0]['answerDetails']
                                        new_mapping_list.append(child_dict)
                                        child_dict = {}
                                    if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                        print('question matched')
                                        child_dict['questionid'] = '539'
                                        if 'answerDetails' in child['children'][1]:
                                            child_dict['answer'] = child['children'][1]['answerDetails']
                                        new_mapping_list.append(child_dict)
                                        child_dict = {}    
                        if qt1 =='MALE ONLY: Prostate cancer':
                            child_dict['questionid'] = '540'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '541'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '542'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        if qt1 =='FEMALE ONLY: Mammogram':
                            child_dict['questionid'] = '543'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '544'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '545'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        if qt1 =='FEMALE ONLY: Bone density scan (for osteoporosis)':
                            child_dict['questionid'] = '546'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '547'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '548'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        if qt1 =='FEMALE ONLY: Cervical cancer (PAP smear)':
                            child_dict['questionid'] = '549'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                            if 'children' in child.keys():
                                if child['children'][0]['questionText'] =='If yes, date (month/year):':
                                    child_dict['questionid'] = '550'
                                    if 'answerDetails' in child['children'][0]:
                                        child_dict['answer'] = child['children'][0]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                                if child['children'][1]['questionText'] =='Where (or MD) performed:':
                                    child_dict['questionid'] = '551'
                                    if 'answerDetails' in child['children'][1]:
                                        child_dict['answer'] = child['children'][1]['answerDetails']
                                    new_mapping_list.append(child_dict)
                                    child_dict = {}
                        if qt1 =='Did you worry that your food would run out before you had money to buy more?':
                            child_dict['questionid'] = '573'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if qt1 =='Did the food you bought just not last, and you did not have money to get more?':
                            child_dict['questionid'] = '574'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                        if qt1 =='Have you or the family you live with been unable to get utilities?':
                            child_dict['questionid'] = '575'
                            if 'answer' in child.keys():
                                child_dict['answer'] = child['answer']
                            new_mapping_list.append(child_dict)
                            child_dict = {}
                
            return new_mapping_list
        ###
def prep_data(json_data, mapped_id ) :
    for match_data in json_data:
        for child in mapped_id:
            if 'questionid' in child.keys():
                if str(match_data['questionid']) == str(child['questionid']):
                    if 'answer' in child.keys():
                        match_data['answer'] = child['answer']
    return json_data
    

#### CS functions 
def fetch_splits_athena(final_data):
    que_list = []

    for data in final_data:
        splitted_string = []
        if data['answerType'] == "Select Multiple":
            answer = data['answer']
            splitted_string = answer.split('\n')
            print(splitted_string)
            for seq in splitted_string:
                ques = {}
                ques['que'] = seq
                ques['ans'] = 'Yes'
                que_list.append(ques)
    return que_list

def map_manual_questions(data_question):
    que_pre_map =  [{'que': 'Mold', 'key' : 'LOCAL.265', 'ans' :'No'},{'que': 'Bug Infestation', 'key' : 'LOCAL.264', 'ans' :'No'},{'que': 'Lead Pipes', 'key' : 'LOCAL.266', 'ans' :'No'},{'que': 'No solid hand rails', 'key' : 'LOCAL.267', 'ans' :'No'},{'que': 'No or non-working smoke detectors', 'key' : 'LOCAL.269', 'ans' :'No'},{'que': 'Water leaks', 'key' : 'LOCAL.270', 'ans' :'No'},{'que': 'Loose Rugs', 'key' : 'LOCAL.271', 'ans' :'No'},{'que': 'Oven or stove not working', 'key' : 'LOCAL.268', 'ans' :'No'},{'que': 'No or not working Carbon Monoxide detector', 'key' : 'LOCAL.272', 'ans' :'No'},{'que': 'No good lighting in walkways', 'key' : 'LOCAL.273', 'ans' :'No'},{'que': 'Anxiety', 'key' : 'LOCAL.280', 'ans' :'No'},{'que': 'Loneliness', 'key' : 'LOCAL.281', 'ans' :'No'},{'que': 'Fatigue', 'key' : 'LOCAL.282', 'ans' :'No'},{'que': 'Stress', 'key' : 'LOCAL.279', 'ans' :'No'}]
    for n in data_question:
        for m in que_pre_map:
            if n['que'] == m['que']:
                m['ans'] = 'Yes'
    return que_pre_map

def sub_que(final_data):
    que_list = []
    for data in final_data:
        if data['externalquestionId'] == 'CST1Q029':
            answer = data['answerDetails']
            ques = {}
            ques['que'] = 'Type Arthrisis'
            ques['ans'] = str(answer)
            ques['key'] = 'LOCAL.210'
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q030':
            answer = data['answerDetails']
            ques = {}
            ques['que'] = 'Type Cancer'
            ques['ans'] = str(answer)
            ques['key'] = 'LOCAL.212'
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q033':
            answer = data['answerDetails']
            ques = {}
            ques['que'] = 'Age'
            ques['ans'] = str(answer)
            ques['key'] = 'LOCAL.216'
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q036':
            answer = data['answerDetails']
            ques = {}
            ques['que'] = 'Type Vascular '
            ques['ans'] = str(answer)
            ques['key'] = 'LOCAL.220'
            que_list.append(ques)
    return que_list
def con_height(final_data):
    for data in final_data:
        if data['questionText'] == "Feet":
            feet = data['Finalanswer']
        if data['questionText'] == "Inches":
            inches = data['Finalanswer']
    return feet + ' Feet ' + inches + ' Inches' 

def paramount_height(final_data):
    for data in final_data:
        if data['questionText'] == "Feet:":
            feet = data['Finalanswer']
        if data['questionText'] == "Inches:":
            inches = data['Finalanswer']
    return feet + ' Feet ' + inches + ' Inches'

def parent_map(que):
    jsondata = {}
    jsondata['questionText'] = que['questionText']
    jsondata['questionId'] = que['questionId']
    jsondata['externalquestionId'] = que['externalquestionId'] if str(que['externalquestionId']) !='None' else ''
    jsondata['ehrKey'] = que['ehrKey']
    jsondata['answerType'] = que['answerType']
    jsondata['answerDetails'] = que['answerDetails']
    jsondata['answer'] = que['answer']
    jsondata['Finalanswer'] = que['answer'] if str(que['answer']) != 'None' else str(que['answerDetails'])

    return jsondata

def get_cs_data(row):
    row = json.loads(row)
    data = row[0]
    screenings = data['screenings']
    questions = screenings[0]['questions']
    completion_date = screenings[0]['completionDate']
    print(completion_date)
    final_data = []
    for que in questions:
        dt = parent_map(que)
        final_data.append(dt)

        if (str(que['children']) !='None'):
            que2 = que['children']
            for que1 in que2:
                dt = parent_map(que1)
                final_data.append(dt)
                if str(que1['children']) !='None':
                    que3 = que1['children']
                    for que4 in que3:
                        dt = parent_map(que4)
                        final_data.append(dt)
                        if  str(que4['children']) !='None':
                            print(que1['children'])
    return final_data

def additional_map(prod_data,data_question_manual, another_query, height ):
    for que in prod_data:
        if que['externalquestionId'] == 'CST1Q014':
            que['Finalanswer'] = height

    for que2 in data_question_manual:
        data = {}
        data['Finalanswer'] = que2['ans']
        data['answerType'] = yes_no_str
        data['ehrKey'] = que2['key']
        data['externalquestionId'] = ''
        prod_data.append(data)
    print('first processing')
    for que2 in another_query:
        data = {}
        data['Finalanswer'] = que2['ans']
        data['answerType'] = ''
        data['ehrKey'] = que2['key']
        data['externalquestionId'] = ''
        prod_data.append(data)
    return prod_data

def cs_mapper():
    df = [{'externalquestionId': 'CST1Q001', 'ehrKey': 'LOCAL.181'},{'externalquestionId': 'CST1Q012', 'ehrKey': 'LOCAL.191'}, {'externalquestionId': 'CST1Q013', 'ehrKey': 'LOCAL.192'}, {'externalquestionId': 'CST1Q088', 'ehrKey': 'LOCAL.193'},  {'externalquestionId': 'CST1Q002', 'ehrKey': 'LOCAL.182'}, {'externalquestionId': 'CST1Q003', 'ehrKey': 'LOCAL.183'}, {'externalquestionId': 'CST1Q004', 'ehrKey': 'LOCAL.184'}, {'externalquestionId': 'CST1Q005', 'ehrKey': 'LOCAL.185'}, {'externalquestionId': 'CST1Q006', 'ehrKey': 'LOCAL.186'}, {'externalquestionId': 'CST1Q007', 'ehrKey': 'LOCAL.187'}, {'externalquestionId': 'CST1Q008', 'ehrKey': 'LOCAL.188'}, {'externalquestionId': 'CST1Q009', 'ehrKey': 'LOCAL.189'}, {'externalquestionId': 'CST1Q010', 'ehrKey': 'LOCAL.190'}, {'externalquestionId': 'CST1Q011', 'ehrKey': None},  {'externalquestionId': 'CST1Q089', 'ehrKey': 'LOCAL.194'}, {'externalquestionId': 'CST1Q090', 'ehrKey': 'LOCAL.195'}, {'externalquestionId': 'CST1Q091', 'ehrKey': 'LOCAL.196'}, {'externalquestionId': 'CST1Q014', 'ehrKey': 'LOCAL.197'}, {'externalquestionId': 'CST1Q015', 'ehrKey': None}, {'externalquestionId': 'CST1Q016', 'ehrKey': None}, {'externalquestionId': 'CST1Q017', 'ehrKey': 'LOCAL.63'}, {'externalquestionId': 'CST1Q018', 'ehrKey': 'LOCAL.198'}, {'externalquestionId': 'CST1Q019', 'ehrKey': 'LOCAL.199'}, {'externalquestionId': 'CST1Q020', 'ehrKey': 'LOCAL.200'}, {'externalquestionId': 'CST1Q021', 'ehrKey': 'LOCAL.201'}, {'externalquestionId': 'CST1Q022', 'ehrKey': 'LOCAL.202'}, {'externalquestionId': 'CST1Q023', 'ehrKey': 'LOCAL.203'}, {'externalquestionId': 'CST1Q024', 'ehrKey': 'LOCAL.204'}, {'externalquestionId': 'CST1Q025', 'ehrKey': 'LOCAL.205'}, {'externalquestionId': 'CST1Q026', 'ehrKey': 'LOCAL.206'}, {'externalquestionId': 'CST1Q027', 'ehrKey': 'LOCAL.'}, {'externalquestionId': 'CST1Q028', 'ehrKey': 'LOCAL.207'}, {'externalquestionId': 'CST1Q029', 'ehrKey': 'LOCAL.208'}, {'externalquestionId': 'CST1Q030', 'ehrKey': 'LOCAL.211'}, {'externalquestionId': 'CST1Q031', 'ehrKey': 'LOCAL.213'}, {'externalquestionId': 'CST1Q032', 'ehrKey': 'LOCAL.214'}, {'externalquestionId': 'CST1Q033', 'ehrKey': 'LOCAL.215'}, {'externalquestionId': 'CST1Q034', 'ehrKey': 'LOCAL.217'}, {'externalquestionId': 'CST1Q035', 'ehrKey': 'LOCAL.218'}, {'externalquestionId': 'CST1Q036', 'ehrKey': 'LOCAL.219'}, {'externalquestionId': 'CST1Q037', 'ehrKey': 'LOCAL.221'}, {'externalquestionId': 'CST1Q038', 'ehrKey': 'LOCAL.222'}, {'externalquestionId': 'CST1Q039', 'ehrKey': 'LOCAL.223'}, {'externalquestionId': 'CST1Q040', 'ehrKey': 'LOCAL.224'}, {'externalquestionId': 'CST1Q041', 'ehrKey': 'LOCAL.225'}, {'externalquestionId': 'CST1Q042', 'ehrKey': 'LOCAL.226'}, {'externalquestionId': 'CST1Q043', 'ehrKey': 'LOCAL.227'}, {'externalquestionId': 'CST1Q044', 'ehrKey': 'LOCAL.228'}, {'externalquestionId': 'CST1Q045', 'ehrKey': 'LOCAL.229'}, {'externalquestionId': 'CST1Q046', 'ehrKey': 'LOCAL.230'}, {'externalquestionId': 'CST1Q047', 'ehrKey': 'LOCAL.241'}, {'externalquestionId': 'CST1Q048', 'ehrKey': 'LOCAL.242'}, {'externalquestionId': 'CST1Q049', 'ehrKey': 'LOCAL.243'}, {'externalquestionId': 'CST1Q051', 'ehrKey': 'LOCAL.'}, {'externalquestionId': 'CST1Q052', 'ehrKey': 'LOCAL.245'}, {'externalquestionId': 'CST1Q053', 'ehrKey': 'LOCAL.246'}, {'externalquestionId': 'CST1Q054', 'ehrKey': 'LOCAL.247'}, {'externalquestionId': 'CST1Q055', 'ehrKey': 'LOCAL.248'}, {'externalquestionId': 'CST1Q056', 'ehrKey': 'LOCAL.249'}, {'externalquestionId': 'CST1Q057', 'ehrKey': 'LOCAL.250'}, {'externalquestionId': 'CST1Q058', 'ehrKey': 'LOCAL.251'}, {'externalquestionId': 'CST1Q059', 'ehrKey': 'LOCAL.253'}, {'externalquestionId': 'CST1Q060', 'ehrKey': 'LOCAL.254'}, {'externalquestionId': 'CST1Q061', 'ehrKey': 'LOCAL.255'}, {'externalquestionId': 'CST1Q062', 'ehrKey': 'LOCAL.256'}, {'externalquestionId': 'CST1Q063', 'ehrKey': 'LOCAL.257'}, {'externalquestionId': 'CST1Q064', 'ehrKey': 'LOCAL.258'}, {'externalquestionId': 'CST1Q050', 'ehrKey': 'LOCAL.244'}, {'externalquestionId': 'CST1Q065', 'ehrKey': 'LOCAL.259'}, {'externalquestionId': 'CST1Q066', 'ehrKey': 'LOCAL.260'}, {'externalquestionId': 'CST1Q067', 'ehrKey': 'LOCAL.261'}, {'externalquestionId': 'CST1Q068', 'ehrKey': 'LOCAL.262'}, {'externalquestionId': 'CST1Q069', 'ehrKey': 'LOCAL.263'}, {'externalquestionId': 'CST1Q070', 'ehrKey': 'LOCAL.'}, {'externalquestionId': 'CST1Q071', 'ehrKey': 'LOCAL.274'}, {'externalquestionId': 'CST1Q073', 'ehrKey': 'LOCAL.276'}, {'externalquestionId': 'CST1Q072', 'ehrKey': 'LOCAL.275'}, {'externalquestionId': 'CST1Q074', 'ehrKey': 'LOCAL.277'}, {'externalquestionId': 'CST1Q075', 'ehrKey': 'LOCAL.278'}, {'externalquestionId': 'CST1Q076', 'ehrKey': 'LOCAL'}, {'externalquestionId': 'CST1Q077', 'ehrKey': ''}, {'externalquestionId': 'CST1Q078', 'ehrKey': 'LOCAL.283'}, {'externalquestionId': 'CST1Q079', 'ehrKey': 'LOCAL.284'}, {'externalquestionId': 'CST1Q080', 'ehrKey': 'LOCAL.285'}, {'externalquestionId': 'CST1Q081', 'ehrKey': 'LOCAL.286'}, {'externalquestionId': 'CST1Q082', 'ehrKey': 'LOCAL.287'}, {'externalquestionId': 'CST1Q083', 'ehrKey': 'LOCAL.288'}, {'externalquestionId': 'CST1Q084', 'ehrKey': 'LOCAL.289'}, {'externalquestionId': 'CST1Q085', 'ehrKey': 'LOCAL.290'}, {'externalquestionId': 'CST1Q086', 'ehrKey': 'LOCAL.291'}, {'externalquestionId': 'CST1Q087', 'ehrKey': 'LOCAL.292'}]

    return df

def loop_thru_complete_list(complete_list, dts):
    for lst in complete_list:
            if lst['key'] == dts['ehrKey']:
                    lst['answer'] = dts['Finalanswer'] if "Finalanswer" in dts.keys() else ''
    return complete_list

def loop_thru_prod_data(dts):
    if str(dts['answerType']) =='None' or str(dts['answerType']) == '':
        dts['answerType'] = 'Undefined'
    if dts['answerType'] ==yes_no_str:
        dts = {k: "N" if str(v) == 'None' else v for k, v in dts.items()}
        for k,v in dts.items():
            dts[k] = change_yn(v)
    elif dts['answerType'] =='Select Single':
        dts = {k: "N/A"  if v is None else v for k, v in dts.items() }
    else:
        dts = {k: "N/A" if v is None else v for k, v in dts.items() }

    return dts

def prepare_json_cs(row, patient_id, department_id,prod_data ):
    complete_list = []
    response_data = prep_json_step_one(department_id)

    for temp in response_data:
        if temp['templateid'] == '402' :
            print('template exists')
            questions_list = temp['questions']
            complete_list = loop_thru_questions_list(questions_list)

    row = json.loads(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)

    for dts in prod_data:
        if dts['ehrKey'] == 'LOCAL.200' and dts['Finalanswer'] == '>5':
            dts['Finalanswer'] = 'greaterthan5'
        dts = loop_thru_prod_data(dts)
        complete_list = loop_thru_complete_list(complete_list, dts)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    complete_list[:] = [d for d in complete_list if d.get('answer') != 'invalid']
    
    return row, complete_list
###CS function ends

def prepare_json_cm(row, patient_id, department_id, prod_data, height):
    response_data = prep_json_step_one(department_id)
    
    for temp in response_data:
        if temp['templateid'] == '461' :
            print('template exists')
            questions_list = temp['questions']
            complete_list = loop_thru_questions_list(questions_list)

    mhc_mapping_que = get_mhc_mapping()
    
    for fd in prod_data:
        for k in mhc_mapping_que:
            if k['externalquestionId'] == fd['externalquestionId']:
                fd['ehrKey'] = k['key']
    row = json.loads(row)
    # print(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)
    #   
    for dts in prod_data:
        if dts['ehrKey'] == 'LOCAL.200' and dts['Finalanswer'] == '>5':
            dts['Finalanswer'] = 'greaterthan5'
        if dts['externalquestionId'] == 'MHCT1Q017':
            dts['Finalanswer'] = height
        dts = loop_thru_prod_data(dts)
        complete_list = loop_thru_complete_list(complete_list, dts)
            # else:
            #     lst['answer'] = 'N'
        # complete_list = {k: v for k, v in complete_list.items() if v is not None}
        #print(complete_list)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    complete_list[:] = [d for d in complete_list if d.get('answer') != 'invalid']
    
    return row, complete_list

def prepare_json_mhc_shorten(row, patient_id, department_id, prod_data):
    response_data = prep_json_step_one(department_id)
    
    for temp in response_data:
        if temp['templateid'] == '481' :
            print('template: ', temp['templateid'])
            questions_list = temp['questions']
            complete_list = loop_thru_questions_list(questions_list)

    mhc_mapping_template = get_mhc_shorten_mapping()
    
    for fd in prod_data:
        for k in mhc_mapping_template:
            if k['externalquestionId'] == fd['externalquestionId']:
                fd['ehrKey'] = k['key']
    row = json.loads(row)
    # print(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)

    for dts in prod_data:
        dts = loop_thru_prod_data(dts)
        complete_list = loop_thru_complete_list(complete_list, dts)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    complete_list[:] = [d for d in complete_list if d.get('answer') != 'invalid']
    
    return row, complete_list

def prepare_json_paramount(row, patient_id, department_id, prod_data, height):
    response_data = prep_json_step_one(department_id)
    
    for temp in response_data:
        if temp['templateid'] == '501':
            print('template: ', temp['templateid'])
            questions_list = temp['questions']
            complete_list = loop_thru_questions_list(questions_list)

    paramount_mapping_template = get_paramount_mapping()
    
    for fd in prod_data:
        for k in paramount_mapping_template:
            if k['externalquestionId'] == fd['externalquestionId']:
                fd['ehrKey'] = k['key']
    row = json.loads(row)
    # print(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)

    # 87209
    for dts in prod_data:
        if dts['externalquestionId'] == 'MAT1015':
            dts['Finalanswer'] = height
        if dts['externalquestionId'] == 'MAT1007' or dts['externalquestionId'] == 'MAT1072' or dts['externalquestionId'] == 'MAT1073' or dts['externalquestionId'] == 'MAT1074':
            # if dts['Finalanswer'] == ''
            dts['answerType'] = 'Custom'
        if dts['externalquestionId'] == 'MAT1021' and dts['Finalanswer'] == '>5':
            dts['Finalanswer'] = 'greaterthan5'
        dts = loop_thru_prod_data(dts)
        complete_list = loop_thru_complete_list(complete_list, dts)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    complete_list[:] = [d for d in complete_list if d.get('answer') != 'invalid']
    
    return row, complete_list

def prepare_json_aetna(row, patient_id, department_id, prod_data):
    complete_list = []

    row = json.loads(row)
    member_id, member_name, mbi, member_lifetime_id, h_contract, completion_date, template_id = data_mapping(row)

    put_data_to_dynamo(patient_id, department_id, template_id, member_name, member_id, mbi, member_lifetime_id, h_contract, completion_date, row, complete_list)
    
    return row