import boto3
import json
import docx
import shutil
from docx import Document
from boto3.dynamodb.conditions import Key, Attr
import sys
from datetime import datetime, date
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
# import ast
import random
import os
import io
import traceback
import pandas as pd
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs

null = None
today = date.today()
customer = 'Paramount'
template_file = 'paramount_hra_20240408.docx'
# year_month_day = "20240506"
year_month_day = today.strftime('%Y%m%d')
template_ins = 'HRSMA001'
lambda_client = boto3.client('lambda')

department_id = '5'

def get_mapping():
    mapping = [
        {
            "question": "How is the Health Risk Assessment being completed?",
            "type": "single"
        },
        {
            "question": "Who is answering the questions?",
            "type": "single"
        },
        {
            "question": "Primary Language",
            "type": "single"
        },
        {
            "question": "Are you of Hispanic, Latino, or Spanish origin?",
            "type": "single"
        },
        {
            "question": "What is your Primary Race?",
            "type": "single"
        },
        {
            "question": "Are you a veteran?",
            "type": "yn"
        },
        {
            "question": "If you are a veteran, do you get health care at the VA?",
            "type": "yn"
        },
        {
            "question": "If yes, please provide the name of the VA clinic or Address",
            "type": "text"
        },
        {
            "question": "What is your marital status?",
            "type": "single"
        },
        {
            "question": "Name of Primary Care Physician:",
            "type": "text"
        },
        {
            "question": "Do you have any of the following:",
            "type": "text",
            "key": "9"
        },
        {
            "question": "Living will",
            "type": "yn",
            "key": "9a"
        },
        {
            "question": "POA",
            "type": "yn",
            "key": "9b"
        },
        {
            "question": "Advanced Directive",
            "type": "yn",
            "key": "9c"
        },
        {
            "question": "Caregiver",
            "type": "yn"
        },
        {
            "question": "If you have a care giver, please provide  name and phone number:",
            "type": "text"
        },
        {
            "question": "Healthcare proxy",
            "type": "yn"
        },
        {
            "question": "Height:",
            "type": "",
        },
        {
            "question": "Feet:",
            "type": "single",
            "key": "10a"
        },
        {
            "question": "Inches:",
            "type": "single",
            "key": "10b"
        },
        {
            "question": "Weight:",
            "type": "text",
            "key": "11"
        },
        {
            "question": "Do you have any medication allergies?",
            "type": "yn",
            "key": "12"
        },
        {
            "question": "Please list your allergies",
            "type": "text",
            "key": "13"
        },
        {
            "question": "How many prescription drugs do you take?",
            "type": "single",
            "key": "14"
        },
        {
            "question": "How many days a week do you normally get 20 minutes or more of exercise/activity?",
            "type": "single",
            "key": "15"
        },
        {
            "question": "Do you smoke or use tobacco products?",
            "type": "yn",
            "key": "16"
        },
        {
            "question": "Do you use recreational drugs?",
            "type": "yn",
            "key": "17"
        },
        {
            "question": "How many alcoholic drinks do you have in a normal week?",
            "type": "single",
            "key": "18"
        },
        {
            "question": "Do you currently suffer from any pain? (Chronic or Acute)",
            "type": "yn",
            "key": "19"
        },
        {
            "question": "On a scale of 1-5 how do you rate your pain?",
            "type": "single",
            "key": "20"
        },
        {
            "question": "Over the past 7 days, how many servings of fruits or vegetables did you eat each day?",
            "type": "single",
            "key": "21"
        },
        {
            "question": "Are you on a special diet for medical or personal reason?",
            "type": "yn",
            "key": "22"
        },
        {
            "question": "If you are on a special diet please indicate what type of diet:",
            "type": "single",
            "key": "22a"
        },
        {
            "question": "In general, would you say your health is:",
            "type": "single",
            "key": "23"
        },
        {
            "question": "Do you currently or have you ever been told you have any of the following conditions?",
            "type": ""
        },
        {
            "question": "Lung Problems (COPD, asthma, chronic bronchitis, emphysema, pulmonary fibrosis)",
            "type": "yn",
            "key": "24a"
        },
        {
            "question": "Active Cancer",
            "type": "yn",
            "key": "24b"
        },
        {
            "question": "Diabetes",
            "type": "yn",
            "key": "24c"
        },
        {
            "question": "Heart Problems (A Fib, A Flutter, Super Ventricular Tachycardia, Congestive Heart Failure, Coronary Heart Disease, Angina, history of MI)",
            "type": "yn",
            "key": "24d"
        },
        {
            "question": "Vascular Disease",
            "type": "yn",
            "key": "24e"
        },
        {
            "question": "Blood disorders (sickle cell, clotting disorders)",
            "type": "yn",
            "key": "24f"
        },
        {
            "question": "Auto Immune disorders (rheumatoid arthritis, psoriatic arthritis, lupus, scleroderma, other)",
            "type": "yn",
            "key": "24g"
        },
        {
            "question": "Chronic Viral Infection (HIV, Hep B or C)",
            "type": "yn",
            "key": "24h"
        },
        {
            "question": "Kidney Disease (CKD, other)",
            "type": "yn",
            "key": "24i"
        },
        {
            "question": "Mental Health (anxiety, depression, bipolar, schizophrenia, PTSD)",
            "type": "yn",
            "key": "24j"
        },
        {
            "question": "Gastrointestinal issues (ulcerative colitis, Crohn's Disease)",
            "type": "yn",
            "key": "24k"
        },
        {
            "question": "Neurological (Alzheimer's, dementia, Parkinson's, convulsions, MS, history of stroke)",
            "type": "yn",
            "key": "24l"
        },
        {
            "question": "Currently pregnant",
            "type": "yn",
            "key": "24m"
        },
        {
            "question": "Other",
            "type": "text",
            "key": "24n"
        },
        {
            "question": "How many times have you been admitted to the hospital in the last 12 months?",
            "type": "single",
            "key": "25"
        },
        {
            "question": "Do you need help with any of the following?",
            "type": ""
        },
        {
            "question": "Bathing",
            "type": "yn",
            "key": "26a"
        },
        {
            "question": "Transferring: Getting in and out of a chair or a bed",
            "type": "yn",
            "key": "26b"
        },
        {
            "question": "Dressing: this includes taking clothes off and putting clothes on, reaching above your head, and using buttons and zippers",
            "type": "yn",
            "key": "26c"
        },
        {
            "question": "Eating: this includes cutting your food and opening any containers with food inside",
            "type": "yn",
            "key": "26d"
        },
        {
            "question": "Using the bathroom: this includes pulling clothes up and down, and cleaning yourself",
            "type": "yn",
            "key": "26e"
        },
        {
            "question": "Walking: walking more than 10 feet without using a walker, cane, or holding onto furniture",
            "type": "yn",
            "key": "26f"
        },
        {
            "question": "Making your meals: this includes cleaning food, cutting foods, and cooking",
            "type": "yn",
            "key": "26g"
        },
        {
            "question": "Shopping: this includes getting groceries and other items needed for your home",
            "type": "yn",
            "key": "26h"
        },
        {
            "question": "Medication management: this includes taking your medications on time, getting refills",
            "type": "yn",
            "key": "26i"
        },
        {
            "question": "Has the lack of transportation kept you from medical appointments, meetings, work or from getting things need for daily living?",
            "type": "single",
            "key": "27"
        },
        {
            "question": "Are you worried or concerned that in the next two months you may not have stable housing that you own, rent, or stay in as a part of a household?",
            "type": "single",
            "key": "28"
        },
        {
            "question": "Do have problems with any of the following at the place you live?",
            "type": ""
        },
        {
            "question": "Bug Infestation",
            "type": "yn",
            "key": "29a"
        },
        {
            "question": "Mold",
            "type": "yn",
            "key": "29b"
        },
        {
            "question": "Lead Pipes",
            "type": "yn",
            "key": "29c"
        },
        {
            "question": "No solid hand rails",
            "type": "yn",
            "key": "29d"
        },
        {
            "question": "Oven or stove not working",
            "type": "yn",
            "key": "29e"
        },
        {
            "question": "No or non-working smoke detectors",
            "type": "yn",
            "key": "29f"
        },
        {
            "question": "Water leaks",
            "type": "yn",
            "key": "29g"
        },
        {
            "question": "Loose Rugs",
            "type": "yn",
            "key": "29h"
        },
        {
            "question": "No or not working Carbon Monoxide detector",
            "type": "yn",
            "key": "29i"
        },
        {
            "question": "No good lighting in walkways",
            "type": "yn",
            "key": "29j"
        },
        {
            "question": "None",
            "type": "yn",
            "key": "29k"
        },
        {
            "question": "With in the last 12 months have you worried that your food would run out before you had money to buy more?",
            "type": "single",
            "key": "30"
        },
        {
            "question": "With in the last 12 months, the food you bought just didn't last and you didn't have money to get more?",
            "type": "single",
            "key": "31"
        },
        {
            "question": "Does anyone, including friends and family, physically, emotionally, or financially try to hurt you?",
            "type": "yn",
            "key": "32"
        },
        {
            "question": "Have you had any of the following preventive screenings:",
            "type": ""
        },
        {
            "question": "FEMALE AGED 21+: Have you had a Pap Smear (Cervical Cancer) in the last 12 months?",
            "type": "yn",
            "key": "33a"
        },
        {
            "question": "FEMALE AGED 45+: Have you had a mammogram in the past 24 months?",
            "type": "yn",
            "key": "33b"
        },
        {
            "question": "MALE/FEMALE 45+ Have you had a colorectal cancer screening (colonoscopy in last 10 yrs or FIT/Cologuard in last 2 yrs)?",
            "type": "yn"
        },
        {
            "question": "What type of colorectal screening have you had?",
            "type": "single",
            "key": "33i"
        },
        {
            "question": "Date of your last Colorectal screening",
            "type": "text",
            "key": "33ii"
        },
        {
            "question": "Results of your last colorectal screening",
            "type": "single",
            "key": "33iii"
        },
        {
            "question": "Have you had a Flu Vaccine in the last year?",
            "type": "yn",
            "key": "34"
        },
        {
            "question": "Have you had a Pneumonia Vaccine?",
            "type": "yn",
            "key": "35"
        }
    ] 
    
    return mapping
    
def yn_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No'
    else:
        text_value = '☐  Yes   ☐  No'
    return text_value

def ynd_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No   ☐  Don’t know'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No   ☐  Don’t know'
    elif  'know' in data.lower() :
        text_value = '☐  Yes   ☐  No   ☒  Don’t know'
    else:
        text_value = '☐  Yes   ☐  No   ☐  Don’t know'
    return text_value

def process_pdf(mapping_questions, memberId, completion_date, memberName):
    # -------------
    
    s3 = boto3.resource("s3")
    # bucket = s3.Bucket("databricks-workspace-stack-newdev-bucket")
    bucket = s3.Bucket(os.environ['BucketName'])

    object_in_s3 = bucket.Object(f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{customer}/Inputs/templates/{template_file}")
    object_as_streaming_body = object_in_s3.get()["Body"]
    print(f"Type of object_as_streaming_body: {type(object_as_streaming_body)}")
    object_as_bytes = object_as_streaming_body.read()
    print(f"Type of object_as_bytes: {type(object_as_bytes)}")

    # Now we use BytesIO to create a file-like object from our byte-stream
    object_as_file_like = io.BytesIO(object_as_bytes)
    
    # ------------
    document2 = Document(docx=object_as_file_like)
    # document2 = Document(f"{s3_path}/Customer/Porter/Inputs/templates/{template_file}")
    # style = document2.styles['Normal']
    style = document2.styles['List Paragraph']
    fullText = []
    i = 0
    for para in document2.paragraphs: 
        i+=1
        inline = para.runs
        for run in inline:
            for data in mapping_questions:                
                if run.text == 'Date: ':
                    run.text = run.text + '\t\t\t\t\t'  +  completion_date # #datetime.strptime(completion_date, "%Y-%m-%d")
                if run.text.strip() == 'Member Name:':
                    run.text = run.text + '\t\t'  + memberName
                if run.text.strip() == 'Member ID:':
                    run.text = run.text + '\t\t\t\t'  + memberId
                if "gastrointestinal" in run.text.strip().lower() and "gastrointestinal" in data['question'].strip().lower():
                    run.text = run.text.strip()
                    r = para.add_run('\t' + yn_match(data.get('answer', "")))
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if "neurological" in run.text.strip().lower() and "neurological" in data['question'].strip().lower():
                    run.text = run.text.strip()
                    r = para.add_run('\t' + yn_match(data.get('answer', "")))
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if "the food you bought just" in run.text.strip().lower() and "the food you bought just" in data['question'].strip().lower():
                    run.text = run.text.strip()
                    r = para.add_run('\t' + data['answer'])
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text.strip().lower() == data['question'].strip().lower() and data['type'] == 'yn' and (data.get('answer', None) is not None and str(data['answer']).lower() != 'none') :
                    run.text = data['question']
                    r = para.add_run('\t' + yn_match(data['answer']))
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text.strip() == data['question'] and data['type'] == 'text' and (data.get('answer', None) is not None and str(data['answer']).lower() != 'none') :
                    run.text = data['question']
                    r = para.add_run('\t' + data['answer'])
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT
                if run.text.strip() == data['question'] and data['type'] == 'single':
                    run.text = data['question']
                    r = para.add_run('\t' + data['answer'])
                    r.bold = False
                    r.alignment=WD_ALIGN_PARAGRAPH.LEFT

    batch_date = today.strftime('%Y%m%d%H%M%S')

    filename = f"{customer}_HRA_{memberId}_{batch_date}.docx"
    
    file_path_part = f"{customer}/Outputs/{year_month_day}/docx/{filename}"

    # path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}"
    path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}"
    s3 = boto3.client('s3', region_name='us-east-1')
    i = 0

    document2.save(f"/tmp/{filename}")
    try:
        s3.upload_file(f"/tmp/{filename}", os.environ['BucketName'], path)
        return {
            'statusCode': 200,
            'body': 'success',
            'path': path
        }
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('cannot complete request')
        }
    
def parent_map(que):
    jsondata = {}
    jsondata['questionText'] = que['questionText']
    jsondata['questionId'] = que['questionId']
    jsondata['externalquestionId'] = que['externalquestionId']  if 'externalquestionId' in que.keys() else ''
    jsondata['ehrKey'] = que['ehrKey']
    jsondata['answerType'] = que['answerType']
    jsondata['answerDetails'] = que['answerDetails']
    jsondata['answer'] = que['answer']
    jsondata['Finalanswer'] = str(que['answer']) if str(que['answer']) !='None' else str(que['answerDetails'])

    return jsondata
    
def generate_docx(raw_data):
    for data_pro in raw_data:
        screenings = data_pro['screenings']
        if screenings[0]["templateId"] != template_ins:
            skip = 1
            continue

        memberName = data_pro['memberName']
        memberLifetimeID = data_pro['memberLifetimeID'] if ('memberLifetimeID' in data_pro.keys() and data_pro['memberLifetimeID'] is not None) else data_pro['memberId']
        questions = screenings[0]['questions']
        completion_date = screenings[0]['completionDate']
        completion_date = completion_date.split("T")[0]


        #TODO:
        mbi = data_pro.get('mbi', "")
        memberId = data_pro['memberId']
        hContract = data_pro.get('contractId', "")

        final_data = []

        for que in questions:
            dt = parent_map(que)
            final_data.append(dt) 
            if str(que['children']) != 'None':
                que2 = que['children']
                for que1 in que2:
                    dt = parent_map(que1)
                    final_data.append(dt)
                    if str(que1['children']) != 'None':
                        que3 = que1['children']
                        for que4 in que3:
                            dt = parent_map(que4)
                            final_data.append(dt)

        df = pd.DataFrame(final_data)

        final_data_mapping = []
        for index, row in df.iterrows():
                data ={}
                data['question'] = row['questionText']
                data['answer'] = row['Finalanswer']
                data['type'] = row['answerType']
                data['ehrKey'] = row['ehrKey']
                final_data_mapping.append(data)

        mapping_questions = get_mapping()
        for ft in mapping_questions:
            for cf in final_data_mapping:
                if ft['question'] == cf['question']:
                    ft['answer'] = str(cf['answer'])

        for data in mapping_questions:
            if data['question'] == 'How is the Health Risk Assessment being completed?':
                data['question'] = 'How is the Health Risk Assessment being'
            if data['question'] == 'If yes, please provide the name of the VA clinic or Address':
                data['question'] = 'If yes, please provide the name of the VA'
            if data['question'] == 'Mental Health (anxiety, depression, bipolar, schizophrenia, PTSD)':
                data['question'] = 'Mental Health (anxiety, depression, bipolar, schizophrenia, PTSD'
            if data['question'] == 'Oven or stove not working':
                data['question'] = 'Oven or stove no'
            if data['question'] == 'On a scale of 1-5 how do you rate your pain?':
                data['question'] = 'On a scale of 1-5 how do you rate your pain'

        return process_pdf(mapping_questions, memberId, completion_date, memberName)
    
    return {
        'statusCode': 400,
        'body': json.dumps('cannot complete request')
    }

def lambda_handler(event, context):
    try:
        response = generate_docx(event.get("data", ""))

        if response.get("statusCode", "") == 200:
            print("inside if 200")
            lambda_client.invoke(FunctionName = os.environ['LambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"path": response.get('path', ""), "patient_id": event.get("patient_id", ""), "department_id": event.get("department_id", "")}))
        else:
            return response
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        print("ex: ", ex)
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot generate mhc to docx')
        }
