import json
import os
import boto3
import http.client
import time
from datetime import datetime
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs
from base64 import b64encode
import sys
import traceback
from boto3.dynamodb.conditions import Key, And
import requests

session = requests.Session()
session.trust_env = False

region_name = os.environ["REGION"]
dynamodb = boto3.resource('dynamodb', region_name=region_name)
practice_id = os.environ['PracticeId']#'2849201'
client_id = os.environ['ClientId']#'0oahmi9gzkjDLp8ue297'
authHost = os.environ['EHRAuthUrl']#'api.preview.platform.athenahealth.com'

# ---- auth / token steps --------
def get_secret():
    secretId = os.environ["AthenaId"]
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )
    session_token = client.get_secret_value(
        SecretId=secretId
    )
    return json.loads(session_token["SecretString"]).get(secretId, "")

def basic_auth(username, password):
    token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
    return f'Basic {token}'

def access_token_gen(conn, payload, headers):
    conn.request("POST", "/oauth2/v1/token", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data = json.loads(data)
    access_token = data['access_token']

    return access_token

def generate_ehr_token():
    auth_1 = basic_auth(client_id, get_secret())
    tokentable = dynamodb.Table("mw_test_token")
    payload = 'grant_type=client_credentials&scope=athena/service/Athenanet.MDP.*'
    conn = http.client.HTTPSConnection(authHost)
    headers = { 
        'Authorization' : auth_1,
        'content-type': "application/x-www-form-urlencoded"
    }
    response = tokentable.query(KeyConditionExpression=Key('id').eq('EHR'))
    if len(response['Items'])  > 0:
        token_response = response['Items'][0]
        if ((int(time.time())) - (int(token_response['ts'])) < 3000): 
            access_token = token_response['token']
        else:
            access_token = access_token_gen(conn, payload, headers)
    else:
        access_token = access_token_gen(conn, payload, headers)
    return access_token

# ---- end auth / token steps ----- 

def get_doc(key):
    client = boto3.client('s3')

    response = client.get_object(
        Bucket=os.environ["BucketName"],
        Key=key
    )

    return response

def post_clinical_document(doc, patient_id, department_id):
    tokendata = generate_ehr_token()
    post_headers = {
        "Accept": "application/json",
        "Authorization" : "Bearer " + tokendata,
    }
    data = {
        "departmentid": str(department_id),
        "documentsubclass": "CLINICALDOCUMENT",
        # "attachmenttype": "PDF",
        "attachmentcontents": doc
    }
    # practice_id = '2849201'
    # patient_id = '6'
    # /v1/{practiceid}/patients/{patientid}/documents/clinicaldocument
    patient_url = 'https://' + authHost + '/v1/' + practice_id + '/' + 'patients/' + patient_id + '/' + 'documents/clinicaldocument'
    print('patient url is :', patient_url)
    response = session.post(patient_url, headers=post_headers, data=data)
    print(response.status_code)
    print(response.text)
    
    return response

def lambda_handler(event, context):
    try:
        department_id = event.get("department_id", 0)
        key = event.get("path", "")
        patient_id = event.get("patient_id", "")
        response = get_doc(key)

        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            print('inside first if')
            doc = b64encode(response.get("Body", "").read())
        else:
            return {
                'statusCode': 500,
                'body': json.dumps('Error, cannot retrieve file')
            }
        
        response = post_clinical_document(doc, patient_id, department_id)
        print('response: ', response)
        if response.status_code == 200:
            print('uploaded to athena' + patient_id)
            return {
                'statusCode': 200,
                'body': json.dumps('Successfully uploaded to athena')
        }
        else:
            return {
                'statusCode': 500,
                'body': json.dumps('Error, cannot upload document to athena')
            }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot upload document to athena')
        }
