import boto3
import json
import docx
import shutil
from docx import Document
from boto3.dynamodb.conditions import Key, Attr
import sys
from datetime import datetime, date
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
# import ast
import random
import os
import io
import traceback
from utils import write_excpetion_to_sqs as write_excpetion_to_sqs

null = None

today = date.today()
region_name = 'us-east-1'
customer = 'Clearspring'
template_file = 'CS_HRA_Template_20240202.docx'
template_ins = 'HRSCS001'
# template_ins = '362'
department_id = '3'
year_month_day = datetime.now().strftime('%Y%m%d')
lambda_client = boto3.client('lambda')

def Getmapping_questions():
   mapping_questions =  [
   {
      "question":"How is the Health Risk Assessment being completed?",
      "type":"simple"
   },
   {
      "question":"Who is answering the questions?",
      "type":"simple"
   },
   {
      "question":"What is your primary language?",
      "type":"simple"
   },
   {
      "question":"Are you of Hispanic, Latino, or Spanish origin?",
      "type":"simple"
   },
   {
      "question":"What is your Primary Race?",
      "type":"simple"
   },
   {
      "question":"Are you a veteran?",
      "type":"ynd"
   },
   {
      "question":"If you are a veteran, do you get health care at the VA?",
      "type":"ynd"
   },
   {
      "question":"If yes, please provide the name of the VA clinic or Address:",
      "type":"simple"
   },
   {
      "question":"What is your marital status?",
      "type":"simple"
   },
   {
      "question":"Name of Primary Care Physician:",
      "type":"simple"
   },
   {
      "question":"Do you have any of the following:"  , 
      "type":"parent"
   },
   {
      "question":"Living Will",
      "type":"yn"
   },
    {
      "question":"POA",
      "type":"yn"
   },
    {
      "question":"Advanced Directive",
      "type":"yn"
   },
   {
      "question":"Caregiver",
      "type":"yn"
   },
   {
      "question":"Health care proxy",
      "type":"yn"
   },
   {
      "question":"If yes, which one?",
      "type":"parent"
   },
   {
      "question":"If you have a care giver, please provide name and phone number:",
      "type":"simple"
   },
   {
      "question":"What is your height?",
      "type":"simple"
   },
   {
      "question":"Feet",
      "type":"simple"
   },
   {
      "question":"Inches",
      "type":"simple"
   },
   {
      "question":"What is your weight?",
      "type":"simple"
   },
   {
      "question":"Do you have any allergies?",
      "type":"ynd"
   },
   {
      "question":"If yes, please list your allergies:",
      "type":"simple"
   },
   {
      "question":"How many prescription drugs do you take?",
      "type":"simple"
   },
   {
      "question":"How many days a week do you normally get 20 minutes or more of exercise/activity?",
      "type":"simple"
   },
   {
      "question":"Do you currently suffer from any pain? (Chronic or Acute)",
      "type":"yn"
   },
   {
      "question":"On a scale of 1-5, how do you rate your pain?",
      "type":"simple"
   },
   {
      "question":"Over the past 7 days, how many servings of fruits or vegetables did you eat each day?",
      "type":"simple"
   },
   {
      "question":"Are you on a special diet for medical or personal reason?",
      "type":"yn"
   },
   {
      "question":"If you are on a special diet please indicate what type of diet:",
      "type":"simple"
   },
   {
      "question":"Do you currently or have you ever been told you have any of the following conditions?",
      "type":"parent"
   },
   {
      "question":"Asthma",
      "type":"yn"
   },
   {
      "question":"Arthritis",
      "type":"yn"
   },
   {
      "question":"Cancer",
      "type":"yn"
   },
   {
      "question":"Diabetes Type 1",
      "type":"yn"
   },
   {
      "question":"Diabetes Type 2",
      "type":"yn"
   },
   {
      "question":"Heart Attack",
      "type":"yn"
   },
   {
      "question":"Heart Failure",
      "type":"yn"
   },
   {
      "question":"Heart Rhythm Issues",
      "type":"yn"
   },
   {
      "question":"Vascular Disease",
      "type":"yn"
   },
   {
      "question":"Hypertension",
      "type":"yn"
   },
   {
      "question":"High Cholesterol",
      "type":"yn"
   },
   {
      "question":"Kidney Disease",
      "type":"yn"
   },
   {
      "question":"COPD",
      "type":"yn"
   },
   {
      "question":"Other Lung Issues (Emphysema, Fibrosis)",
      "type":"yn"
   },
   {
      "question":"Mental Health (anxiety, depression, bipolar, schizophrenia, PTSD)",
      "type":"yn"
   },
   {
      "question":"Neurological (Alzheimer's, dementia, Parkinson's, convulsions, MS)",
      "type":"yn"
   },
   {
      "question":"Currently pregnant",
      "type":"yn"
   },
   {
      "question":"Stroke",
      "type":"yn"
   },
   {
      "question":"Other",
      "type":"simple"
   },
   {
      "question":"How many times have you been admitted to the hospital in the last 12 months?",
      "type":"simple"
   },
   {
      "question":"In general, would you say your health is:",
      "type":"simple"
   },
   {
      "question":"Do you have any hearing problems for which you need help such as a hearing aid or TTY?",
      "type":"yn"
   },
   {
      "question":"Do you have a problem with seeing or your vision which requires glasses/contacts?",
      "type":"yn"
   },
   {
      "question":"Do you need assistance completing the following activities?",
      "type":"parent"
   },
   {
      "question":"Bathing",
      "type":"yn"
   },
   {
      "question":"Transferring: Getting in and out of a chair or a bed",
      "type":"yn"
   },
   {
      "question":"Dressing: This includes taking clothes off and putting clothes on, reaching above your head, and using buttons and zippers",
      "type":"yn"
   },
   {
      "question":"Eating: This includes cutting your food and opening any containers with food inside",
      "type":"yn"
   },
   {
      "question":"Using the bathroom: This includes pulling clothes up and down, and cleaning yourself",
      "type":"yn"
   },
   {
      "question":"Walking: Walking more than 10 feet without using a walker, cane, or holding onto furniture",
      "type":"yn"
   },
   {
      "question":"Using the phone",
      "type":"yn"
   },
   {
      "question":"Transportation",
      "type":"yn"
   },
   {
      "question":"Housework: This includes sweeping, mopping, changing sheets, and taking out the trash",
      "type":"yn"
   },
   {
      "question":"Laundry: This includes washing, drying, ironing, folding clothing, and house items",
      "type":"yn"
   },
   {
      "question":"Making your meals: This includes cleaning food, cutting foods, and cooking",
      "type":"yn"
   },
   {
      "question":"Shopping: This includes getting groceries and other items needed for your home",
      "type":"yn"
   },
   {
      "question":"Medication management: This includes taking your medications on time, getting refills",
      "type":"yn"
   },
   {
      "question":"Do you have any difficulty walking which requires the use of a cane, walker, or wheelchair?",
      "type":"yn"
   },
   {
      "question":"Do you smoke or use tobacco products?",
      "type":"yn"
   },
   {
      "question":"Do you use recreational drugs?",
      "type":"yn"
   },
   {
      "question":"How many alcoholic drinks do you have in a normal week?",
      "type":"simple"
   },
   {
      "question":"Has the lack of transportation kept you from medical appointments, meetings, work or from getting things need for daily living?",
      "type":"simple"
   },
   {
      "question":"Are you worried or concerned that in the next two months you may not have stable housing that you own, rent, or stay in as a part of a household?",
      "type":"simple"
   },
   {
      "question":"Do have problems with any of the following at the place you live?",
      "type":"parent"
   },
   {
      "question":"Within the last 12 months have you worried that your food would run out before you had money to buy more?",
      "type":"simple"
   },
   {
      "question":"Does anyone, including friends and family, physically, emotionally, or financially try to hurt you?",
      "type":"yn"
   },
   {
      "question":"With in the last 12 months, did the food you bought just didn't last and you didn't have money to get more?",
      "type":"simple"
   },
   {
      "question":"Over the past 2 weeks how often have you felt down, depressed, or hopeless?",
      "type":"simple"
   },
   {
      "question":"Over the past 2 weeks how often have you felt little interest or pleasure in doing things?",
      "type":"simple"
   },
   {
      "question":"During the last 6 months, have you experienced any of the following?",
      "type":"simple"
   },
   {
      "question":"Have you had any of the following preventative screenings?",
      "type":"parent"
   },
   {
      "question":"FEMALE ONLY: Pap Smear (Cervical Cancer) in the last 12 months",
      "type":"simple"
   },
   {
      "question":"Females Aged 45 and Above Only: Mammogram in the past 24 months",
      "type":"simple"
   },
   {
      "question":"Females Aged 65 to 85 Only: Bone Density and/or Osteoporosis Screening",
      "type":"simple"
   },
   {
      "question":"Males Aged 50 and Above Only: Prostate Exam",
      "type":"simple"
   },
   {
      "question":"Male/Female Aged 45 and Above Only: Colorectal Cancer Screening",
      "type":"simple"
   },
   {
      "question":"What type of colorectal screening have you had?",
      "type":"simple"
   },
   {
      "question":"Date of your last Colorectal screening:",
      "type":"simple"
   },
   {
      "question":"Results of your last colorectal screening:",
      "type":"simple"
   },
   {
      "question":"Have you had a Flu Vaccine in the last year?",
      "type":"yn"
   },
   {
      "question":"Have you had a Pneumonia Vaccine?",
      "type":"yn"
   },
   {
      "question":"Mold",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Bug Infestation",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Lead Pipes",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"No solid hand rails",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Oven or stove not working",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Water leaks",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Loose Rugs",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"No or not working Carbon Monoxide detector",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"No or non-working smoke detectors",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"No good lighting in walkways",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"None1",
      "type":"tj",
      "answer": "No"
   },
   {
      "question":"None2",
      "type":"tk",
      "answer": "No"
   },
   {
      "question":"Fatigue",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Loneliness",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Anxiety",
      "type":"ty",
      "answer": "No"
   },
   {
      "question":"Stress",
      "type":"ty",
      "answer": "No"
   }]

   return mapping_questions

def subQue(final_data):
    que_list = []
    for data in final_data:
        if data['externalquestionId'] == 'CST1Q029':
            answer = str(data['answerDetails'])
            ques = {}
            ques['question'] = 'ArthritisType'
            ques['answer'] = str(answer)
            ques['type'] = 'simple1'
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q030':
            answer = str(data['answerDetails'])
            ques = {}
            ques['question'] = 'CancerType'
            ques['type'] = 'simple1'
            ques['answer'] = str(answer)
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q033':
            answer = str(data['answerDetails'])
            ques = {}
            ques['question'] = 'Age'
            ques['type'] = 'simple1'
            ques['answer'] = str(answer)
            que_list.append(ques)
        if data['externalquestionId'] == 'CST1Q036':
            answer = str(data['answerDetails'])
            ques = {}
            ques['question'] = 'VascularType'
            ques['type'] = 'simple1'
            ques['answer'] = str(answer)
            que_list.append(ques)
    return que_list

def conHeight(final_data):
    for data in final_data:
        if data['questionText'] == "Feet":
            Feet = data['Finalanswer']
        if data['questionText'] == "Inches":
            Inches = data['Finalanswer']
    return Feet + ' Feet ' + Inches + ' Inches' 

def fetchSplits(final_data):
   que_list = []

   for data in final_data:
      splitted_string = []
      que = {}
      if data['answerType'] == "Select Multiple":
        queid = data['externalquestionId'] 
        answer = data['answer']
        if queid == 'CST1Q070':
            answer = answer.replace('None', 'None2')
        elif queid == 'CST1Q076':
            answer = answer.replace('None', 'None1')
        splitted_string = answer.split('\n')
        print(splitted_string)
        for seq in splitted_string:
            ques = {}
            ques['que'] = seq
            ques['ans'] = 'Yes'
            que_list.append(ques)
   
   return que_list

def cs_custom_mapping(mapping_questions, height):
    for data in mapping_questions:
        if data['question'] == "If you have a care giver, please provide name and phone number:":
            data['question'] = "please provide name and phone number:"
        if data['question'] == "Within the last 12 months have you worried that your food would run out before you had money to buy more?":
            data['question'] = "Within the last 12 months have you worried that your food would run out before you had money to buy more"
        if data['question'] == "What is your height?":
            data['answer'] = height
        if data['question'] == "Results of your last colorectal screening:":
            data['question'] = "Results of your test colorectal screening"
        if data['question'] == "Using the bathroom: This includes pulling clothes up and down, and cleaning yourself":
            data['question'] = "Using the bathroom: This includes pulling clothes up and down, and cleansing yourself"
        if data['question'] == "Are you a veteran?":
            data['question'] = "Are you a Veteran?"
        if data['question'] == "Living Will":
            data['question'] = "Living will"
        if data['question'] == "Date of your last Colorectal screening:":
            data['question'] = "Date of your last Colorectal screening"

    return mapping_questions

def yes_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes'
    else:
        text_value = '☐  Yes'
    return text_value

def yn_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No'
    else:
        text_value = '☐  Yes   ☐  No'
    return text_value

def ynd_match(data):
    if data.lower() == 'yes' or data.lower() == 'y':
        text_value = '☒  Yes   ☐  No   ☐  Don’t know'
    elif data.lower() == 'no' or data.lower() == 'n':
        text_value = '☐  Yes   ☒  No   ☐  Don’t know'
    elif  'know' in data.lower() :
        text_value = '☐  Yes   ☐  No   ☒  Don’t know'
    else:
        text_value = '☐  Yes   ☐  No   ☐  Don’t know'
    return text_value

# newly added
def parent_map(que):
   que_child = 1
   jsondata = {}
   jsondata['questionText'] = que['questionText']
   jsondata['questionId'] = que['questionId']
   jsondata['externalquestionId'] = que['externalquestionId']  if 'externalquestionId' in que.keys() else ''
   jsondata['ehrKey'] = que['ehrKey']
   jsondata['answerType'] = que['answerType']
   jsondata['answerDetails'] = que['answerDetails']
   jsondata['answer'] = que['answer']
   jsondata['Finalanswer'] = str(que['answer']) if str(que['answer']) !='None' else str(que['answerDetails'])

   return jsondata

def processCFPdf(mapping_questions, completion_date, memberName, memberLifetimeID, memberId, hContract):      
   s3 = boto3.resource("s3")
   # bucket = s3.Bucket("databricks-workspace-stack-newdev-bucket")
   bucket = s3.Bucket(os.environ['BucketName'])

   object_in_s3 = bucket.Object(f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{customer}/Inputs/templates/{template_file}")
   object_as_streaming_body = object_in_s3.get()["Body"]
   print(f"Type of object_as_streaming_body: {type(object_as_streaming_body)}")
   object_as_bytes = object_as_streaming_body.read()
   print(f"Type of object_as_bytes: {type(object_as_bytes)}")

   # Now we use BytesIO to create a file-like object from our byte-stream
   object_as_file_like = io.BytesIO(object_as_bytes)
   
   # ------------
   document = Document(docx=object_as_file_like)
   style = document.styles['Normal']
   fullText = []
   i = 0
   for para in document.paragraphs: 
      i+=1
      inline = para.runs
      for run in inline:
         # print("inline : ", run.text)
         for data in mapping_questions:
            if run.text == 'Date:':
               run.text = run.text + '\t\t' + completion_date 
            if run.text.strip() == 'Member Name:':
               run.text = run.text + '\t\t'  + memberName
            if run.text.strip() == 'Member ID:':
               run.text = run.text + '\t\t'  + memberLifetimeID
            if run.text == data['question'] and data['type'] == 'simple':
               run.text = run.text + '\t\t'  
               q = para.add_run(data['answer'])
               q.bold = False
               q.alignment=WD_ALIGN_PARAGRAPH.LEFT
            elif run.text == data['question'] and data['question']=='CancerType' and data['question']!='Type' and data['type'] == 'simple1':
               run.text = run.text.replace('CancerType', 'Type')
               run.text = run.text + '\t\t'  
               x = para.add_run(data['answer'])
               x.bold = False
               x.alignment=WD_ALIGN_PARAGRAPH.LEFT
            elif run.text == data['question'] and data['question']=='ArthritisType' and data['question']!='Type' and data['type'] == 'simple1':
               run.text = run.text.replace('ArthritisType', 'Type')
               run.text = run.text + '\t\t'  
               x = para.add_run(data['answer'])
               x.bold = False
               x.alignment=WD_ALIGN_PARAGRAPH.LEFT
            elif run.text == data['question'] and data['question']=='Age' and data['type'] == 'simple1':
               run.text = run.text.replace('ArthritisType', 'Type')
               run.text = run.text + '\t\t'  
               x = para.add_run(data['answer'])
               x.bold = False
               x.alignment=WD_ALIGN_PARAGRAPH.LEFT
            elif run.text == data['question'] and data['question']=='VascularType'  and data['question']!='Type' and data['type'] == 'simple1':
               run.text = run.text.replace('VascularType', 'Type')
               run.text = run.text + '\t\t'  
               y = para.add_run(str(data['answer']))
               y.bold = False
               y.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if run.text.strip() == data['question'] and data['type'] == 'yn' and  data['answer'] is not None:
               run.text = run.text   + '\t'
               r = para.add_run(yn_match(data['answer']))
               r.bold = True
               r.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if run.text.strip() == data['question'] and data['type'] == 'ynd' and  data['answer'] is not None:
               run.text = run.text   + '\n'
               j = para.add_run(ynd_match(data['answer']))
               j.bold = True
               j.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if run.text.strip() ==  data['question']  and data['type'] == 'ty':
               run.text = run.text   + '\t\t'
               k = para.add_run(yes_match(data['answer']))
               k.bold = True
               k.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if run.text == 'None2' and data['question']=='None2'  and data['type'] == 'tk'  and str(data['question']) !='None':
               run.text = run.text.replace('None2', 'None')
               run.text = run.text   + '\t\t'
               k = para.add_run(yes_match(data['answer']))
               k.bold = True
               k.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if run.text == 'None1' and data['question']=='None1' and data['type'] == 'tj' and str(data['question']) !='None':
               style = para.style
               run.text = run.text.replace('None1', 'None')
               run.text = run.text   + '\t\t'
               z = para.add_run(yes_match(data['answer']))
               z.bold = True
               z.alignment=WD_ALIGN_PARAGRAPH.LEFT

   file_date = today.strftime('%Y%m%d%H%M%S')

   filename = 'ClearSpring_HRA_' + str(memberId) +'_' + str(hContract) +'_' + str(file_date) + '.docx'
   
   file_path_part = f"{customer}/Outputs/{year_month_day}/docx/{filename}"
   
   # 5170568595690779
   # 7413904104309051
   path = f"nvirginia-prod/5170568595690779/FileStore/tables/Customer/{file_path_part}"
   
   s3 = boto3.client('s3', region_name='us-east-1')
   i = 0

   document.save(f"/tmp/{filename}")
   try:
      s3.upload_file(f"/tmp/{filename}", os.environ['BucketName'], path)
      return {
            'statusCode': 200,
            'body': 'success',
            'path': path
      }
   except:
      return {
            'statusCode': 400,
            'body': json.dumps('cannot complete request')
      }

def generate_docx(raw_data):
    for data_pro in raw_data:
        print('----------------------')

        screenings = data_pro['screenings']
        if screenings[0]["templateId"] != template_ins:
            print(screenings[0]["templateId"], "skipping")
            skip = 1
            continue

        memberName = data_pro['memberName']
        memberLifetimeID = data_pro['memberLifetimeID'] if ('memberLifetimeID' in data_pro.keys() and data_pro['memberLifetimeID'] is not None) else data_pro['memberId']

        questions = screenings[0]['questions']
        completion_date = screenings[0]['completionDate']
        completion_date = completion_date.split("T")[0]
        final_data = []
        memberId = data_pro['memberId'] if ('memberId' in data_pro.keys() and data_pro['memberId'] is not None) else data_pro['memberLifetimeID']
        mbi = data_pro['mbi']  if 'mbi' in data_pro.keys() else ''
        hContract = data_pro['hContract']  if 'hContract' in data_pro.keys() else ''

        for que in questions:
            dt = parent_map(que)
            final_data.append(dt)
            # print(que.keys())
            if str(que['children']) != 'None':
                que2 = que['children']
                for que1 in que2:
                    dt = parent_map(que1)
                    final_data.append(dt)
                    if str(que1['children']) != 'None':
                        que3 = que1['children']
                        for que4 in que3:
                            dt = parent_map(que4)
                            final_data.append(dt)

    data_break = fetchSplits(final_data)

    data_sub = subQue(final_data)

    mapping_questions = Getmapping_questions()
    for data in mapping_questions:
        data['answer']=''
    updated_data = []
    new_type ={}
    for data in final_data:
        new_type['question'] = data['questionText']
        updated_data.append(new_type)
        new_type ={}
    for data in mapping_questions:
        for data2 in final_data:
            if data['question'] == data2['questionText']:
                data['answer'] = data2['Finalanswer']

    for data in mapping_questions:
        for data2 in data_break:
            if data['question'] == data2['que']:
                data['answer'] = data2['ans'] 

    for data2 in data_sub:
        mapping_questions.append(data2)
        helght = conHeight(final_data)
        mapping_questions = cs_custom_mapping(mapping_questions, helght)
    
    return processCFPdf(mapping_questions, completion_date, memberName, memberLifetimeID, memberId, hContract)
    # return {
    #     'statusCode': 400,
    #     'body': json.dumps('cannot complete request')
    # }

def lambda_handler(event, context):
    try:
        print(event)
        
        response = generate_docx(event.get("data", ""))
        
        if response.get("statusCode", "") == 200:
            lambda_client.invoke(FunctionName = os.environ['LambdaFunctionToInvoke'], InvocationType = 'Event', Payload = json.dumps({"path": response.get('path', ""), "patient_id": event.get("patient_id", ""), "department_id": event.get("department_id", "")}))
        else:
            return response
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        
        print("ex: ", ex)
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            'statusCode': 500,
            'body': json.dumps('Error, cannot generate mhc to docx')
        }
