import boto3
import os
import json
import botocore.exceptions
from boto3.dynamodb.conditions import Key
from datetime import datetime
from httpUtils import not_found
import sys
import traceback
import http
from auth import generate_access_token_sf
import requests

session = requests.Session()
session.trust_env = False

dynamodb = boto3.resource("dynamodb")

headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def lambda_handler(event, context):
    method = event.get('method')
    action = event.get('action')
    token = get_token(event['headers']['Authorization'])
    if method == 'GET':
        if action == 'GetCommunicationPreferences':
            return get_communication_preferences(event)
        return get_profile_data(event['requestContext']['authorizer']['claims']['username'])
    elif method == 'PUT':
        return update_password(event,token)
    elif method == 'POST' and action == 'UpdateUserProfile':
        return update_user_profile(event)
    elif method == 'POST' and action == 'UpdateCommunicationPreferences':
        return update_communication_preferences(event)
    
    return not_found('', f'The provided request method, {method} is not supported for request {action}') 
    
def get_token(header):
    PREFIX = 'Bearer'
    bearer, _, token = header.partition(' ')
    if bearer != PREFIX:
        raise ValueError('Invalid token')

    return token
    
def update_password(event, token):
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    
    payload = json.loads(event.get('payload'))
    original_password = payload["originalPassword"]
    new_password = payload["newPassowrd"]
    try:
        response = client.change_password(
            PreviousPassword=original_password,
            ProposedPassword=new_password,
            AccessToken=token
        )
    except client.exceptions.NotAuthorizedException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Invalid old password."})
        }
    except client.exceptions.LimitExceededException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Limit exceeded.Please try after sometime."})
        }
    except client.exceptions.TooManyRequestsException:
        return {
        "statusCode": 400,
        "headers": headers,
        "body": json.dumps({"message": "Too many attempts.Please try after sometime."})
        }
    
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
        return {
            'statusCode': response.get("ResponseMetadata").get("HTTPStatusCode"),
            "headers": headers,
            'body': json.dumps(response)
        } 
    
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Successfully updated password."}),
        "headers": headers
    }
    
def update_user_profile(event):
    try:
        client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
        payload = json.loads(event.get('payload'))

        cognito_id = event['requestContext']['authorizer']['claims']['username']
        mappingtable =  dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
        
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))

        if (response["Items"]):
            update_response = client.admin_update_user_attributes(
                UserPoolId=os.environ["UserPoolId"],
                Username=str(cognito_id),
                UserAttributes=[
                    {
                        "Name": "email",
                        "Value": payload["emailAddress"]
                    },
                    {
                        "Name": "email_verified",
                        "Value": "true"
                    },
                    {
                        "Name": "phone_number",
                        "Value": payload["primaryNumber"]
                    }
                ]
            )

    except client.exceptions.AliasExistsException as e:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": str(e), "message": "An account with given email already exists"}),
            "headers": headers
        }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            "statusCode": 400,
            "body": json.dumps({"message": 'An Error Has Occurred'}),
            "headers": headers
        }
        
    if update_response.get("ResponseMetadata").get("HTTPStatusCode") != 200:
        return {
            'statusCode': response.get("ResponseMetadata").get("HTTPStatusCode"),
            "headers": headers,
            'body': json.dumps(response)
        } 

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Update Successfully"}),
        "headers": headers
    }
def get_profile_data(cognito_id):
    try:
        profileData = {}
        cognito_id = str(cognito_id)
        membertable = dynamodb.Table(os.environ['MemberDetailsTable'])
        addresstable =  dynamodb.Table(os.environ['MemberAddressTable'])
        mappingtable =  dynamodb.Table(os.environ['MiddlewareMemberMappingTable']) 
        consenttable =  dynamodb.Table(os.environ['MiddlewareMemberConsentTable'])
        contacttable =  dynamodb.Table(os.environ['MemberContactTable']) 
        
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))
        account_data = {}
        if (response["Items"]):
            print(response["Items"])
            uuid = response["Items"][0]['uuid']
            memberDetail = membertable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            # contactDetail = get_user_detail_from_cognito(cognito_id)
            address_details = get_address_data(addresstable, uuid) 
            constable = consenttable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            contact_details = contacttable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            print("contact details: ", contact_details)
            print("add details: ", address_details)
            print(memberDetail["Items"])
            if (memberDetail["Items"] and len(memberDetail["Items"]) > 0):
                data = memberDetail["Items"][0]
                profileData['status'] = "success"
                profileData['uuid'] = uuid
                profileData['Gender'] = data.get('Gender','') 
                profileData['FirstName'] = data.get('FirstName',"") 
                profileData['LastName'] = data.get('LastName',"") 
                profileData['DateOfBirth'] = data.get('DateOfBirth',"")
            if contact_details.get("Items", []) and len(contact_details.get("Items", [])) > 0:
                data = contact_details.get("Items", [])[0]
                if data.get('UserUpdatedEmail',""):
                    user_email = data.get('UserUpdatedEmail',"")
                else:
                    user_email = data.get('EmailAddress',"")

                if data.get('UserUpdatedNumber',""):
                    user_number = data.get('UserUpdatedNumber',"")
                else:
                    user_number= data.get('PrimaryNumber',"")
                profileData['EmailAddress'] = user_email
                profileData['PrimaryNumber'] = user_number
            if (address_details.get("Items", []) and len(address_details.get("Items", [])) > 0):
                adata = address_details["Items"][0]
                profileData['Street1'] = adata.get('Street1', "")
                profileData['Street2'] = adata.get('Street2', "")
                profileData['City'] = adata.get('City', "")
                profileData['State'] = adata.get('State', "")
                profileData['Zip'] = adata.get('Zip', "")
            if (constable["Items"] and len(constable["Items"]) > 0):
                csdata = constable["Items"][0]
                consentData = {}
                consentData['Type'] = csdata['Type'] if (csdata['Type']) else ""
                consentData['Consent'] = csdata['Consent'] if (csdata['Consent']) else ""
                consentData['Individual'] = csdata['Individual'] if (csdata['Individual']) else ""
                consentData['IndividualRelationship'] = csdata['IndividualRelationship'] if (csdata['IndividualRelationship']) else ""
                consentData['LegalName'] = csdata['LegalName'] if (csdata['LegalName']) else ""
                consentData['Title'] = csdata['Title'] if (csdata['Title']) else ""
                consentData['FirstName'] = csdata['FirstName'] if (csdata['FirstName']) else ""
                consentData['LastName'] = csdata['LastName'] if (csdata['LastName']) else ""
                consentData['ConsentDate'] = csdata['ConsentDate'] if (csdata['ConsentDate']) else ""
                profileData['consentData'] = consentData
            else:
                profileData['consentData'] = ''
    
        else:
            profileData['status'] = "Account not found."
    except Exception as err:
      exec_info = sys.exc_info()
      ex = ''.join(traceback.format_exception(*exec_info))
      
        
    return {
        "statusCode": 200,
        "body": json.dumps(profileData,cls=DecimalEncoder),
        "headers": headers
    }

def get_address_data(addresstable, uuid):
    address_details = addresstable.query(KeyConditionExpression=Key('uuid').eq(uuid) & (Key('type').eq('UserUpdated')))
    if not (address_details.get("Items", []) and len(address_details.get("Items", [])) > 0):
        address_details = addresstable.query(KeyConditionExpression=Key('uuid').eq(uuid) & (Key('type').eq('HomeAddress')))

    return address_details

def get_user_detail_from_cognito(cognitoId):
    if cognitoId is None or cognitoId == '':
        return None
    
    client = boto3.client("cognito-idp", region_name=os.environ["REGION"])
    response = client.list_users (
            UserPoolId=os.environ["UserPoolId"], 
            AttributesToGet= ["email","phone_number"],
            Limit=1,
            Filter = f"username = \"{cognitoId}\""
            )
    if response.get("ResponseMetadata").get("HTTPStatusCode") != 200 or len(response.get("Users",[])) == 0:
            return None
                    
    attributes = response.get("Users")[0].get('Attributes')
    data = {}
    for attribute in attributes:
        if attribute.get('Name','') == 'phone_number':
            data['phoneNumber'] = attribute.get('Value')
        elif attribute.get('Name','') == 'email':
            data['emailAddress'] = attribute.get('Value')

    return data

def update_communication_preferences(event):
    try:
        cognito_id = event['requestContext']['authorizer']['claims']['username']
        payload = json.loads(event.get('payload'))
        
        mappingtable = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))
        
        if not response["Items"]:
            return {
                "statusCode": 404,
                "body": json.dumps({"message": "User not found"}),
                "headers": headers
            }
        
        uuid = response["Items"][0]['uuid']
        
        sf_payload = {
            "uuid": uuid,
            "emailOptOut": payload.get("emailOptOut", False),
            "textOptOut": payload.get("textOptOut", False),
            "textOptIn": payload.get("textOptIn", False),
            "doNotCall": payload.get("doNotCall", False),
            "directMailOptsOut": payload.get("directMailOptsOut", False)
        }
        
        sf_token = generate_access_token_sf()
        salesforce_url = f"https://{os.environ['SF_API_PREFIX']}/services/apexrest/accountupdate/v1/"
        
        sf_response = session.post(
            salesforce_url,
            json=sf_payload,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {sf_token['token']}"
            }
        )
        
        return {
            "statusCode": sf_response.status_code,
            "body": json.dumps({
                "message": "Communication preferences updated",
            }),
            "headers": headers
        }
        
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "An error occurred while updating communication preferences"}),
            "headers": headers
        }

def get_communication_preferences(event):
    try:
        cognito_id = event['requestContext']['authorizer']['claims']['username']
        mappingtable = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
        response = mappingtable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(cognito_id))
        
        if not response["Items"]:
            return {
                "statusCode": 404,
                "body": json.dumps({"message": "User not found"}),
                "headers": headers
            }
        
        uuid = response["Items"][0]['uuid']
        
        sf_token = generate_access_token_sf()
        salesforce_url = f"https://{os.environ['SF_API_PREFIX']}/services/apexrest/accountupdate/v1/"
        
        sf_response = session.get(
            salesforce_url,
            params={"UUID": uuid},
            headers={
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {sf_token['token']}"
            }
        )
        
        if sf_response.status_code != 200:
            return {
                "statusCode": sf_response.status_code,
                "body": json.dumps({"message": "Failed to retrieve communication preferences from Salesforce"}),
                "headers": headers
            }
        
        communication_preferences = sf_response.json()
        
        if communication_preferences.get("status") != "Success":
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Failed to retrieve communication preferences"}),
                "headers": headers
            }
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "uuid": communication_preferences.get("uuid"),
                "emailOptOut": communication_preferences.get("emailOptOut", False),
                "textOptOut": communication_preferences.get("textOptOut", False),
                "textOptIn": communication_preferences.get("textOptIn", False),
                "doNotCall": communication_preferences.get("doNotCall", False),
                "directMailOptsOut": communication_preferences.get("directMailOptsOut", False)
            }),
            "headers": headers
        }
        
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "An error occurred while retrieving communication preferences"}),
            "headers": headers
        }
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return json.JSONEncoder.default(self, obj)

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
