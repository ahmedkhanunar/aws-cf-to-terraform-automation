import boto3
import os

from typing import Tuple, Union
from urllib.parse import ParseResult, urlencode, urlunparse

import botocore.session
import redis
from botocore.model import ServiceId
from botocore.signers import RequestSigner
from cachetools import TTLCache, cached

def write_excpetion_to_sqs(message):
      sqs = boto3.client('sqs')  #client is required to interact with 
      url = os.environ['SQS_EXCEPTION_URL']
      
      sqs.send_message(
         QueueUrl=url,
         MessageBody=message
      )

class ElastiCacheIAMProvider(redis.CredentialProvider):
   def __init__(self, user, cache_name, is_serverless=False, region="us-east-1"):
      self.user = user
      self.cache_name = cache_name
      self.is_serverless = is_serverless
      self.region = region

      session = botocore.session.get_session()
      self.request_signer = RequestSigner(
            ServiceId("elasticache"),
            self.region,
            "elasticache",
            "v4",
            session.get_credentials(),
            session.get_component("event_emitter"),
      )

   # Generated IAM tokens are valid for 15 minutes
   @cached(cache=TTLCache(maxsize=128, ttl=900))
   def get_credentials(self) -> Union[Tuple[str], Tuple[str, str]]:
      query_params = {"Action": "connect", "User": self.user}
      if self.is_serverless:
            query_params["ResourceType"] = "ServerlessCache"
      url = urlunparse(
            ParseResult(
               scheme="https",
               netloc=self.cache_name,
               path="/",
               query=urlencode(query_params),
               params="",
               fragment="",
            )
      )
      signed_url = self.request_signer.generate_presigned_url(
            {"method": "GET", "url": url, "body": {}, "headers": {}, "context": {}},
            operation_name="connect",
            expires_in=900,
            region_name=self.region,
      )
      # RequestSigner only seems to work if the URL has a protocol, but
      # Elasticache only accepts the URL without a protocol
      # So strip it off the signed URL before returning
      return (self.user, signed_url.removeprefix("https://"))

def get_redis_client():
   try:
      username = "default" # replace with your user id
      print("redis cache name: ", os.environ["RedisCacheName"])
      print("redis cache endpoint: ", os.environ["RedisEndpoint"])
      # cache_name = "hp-redis-dev" # replace with your cache name
      cache_name = os.environ["RedisCacheName"]
      # elasticache_endpoint = "hp-redis-dev-v4dnpk.serverless.use1.cache.amazonaws.com" # replace with your cache endpoint
      elasticache_endpoint = os.environ["RedisEndpoint"]
      creds_provider = ElastiCacheIAMProvider(user=username, cache_name=cache_name, is_serverless=True)
      redis_client = redis.Redis(host=elasticache_endpoint, port=6379, credential_provider=creds_provider, ssl=True, ssl_cert_reqs="none")

      return redis_client
   except Exception as e:
      return None
