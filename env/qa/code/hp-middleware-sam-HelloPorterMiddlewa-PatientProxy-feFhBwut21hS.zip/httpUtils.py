from auth import client_authentication 
from auth import get_auth_header
from auth import generate_access_token_sf
import urllib.parse
import json
import os
import urllib3
import base64
from utils import get_redis_client


def request(route, method, payload, scope, connection, event, customHeader,isSFConnection = False):
    
    if isSFConnection:
        auth_response = generate_access_token_sf()
    else:
        auth_response = client_authentication(scope, payload.get('cognitoId', ""))
        
        
    if auth_response['statusCode']  != 200:
            return auth_response
    header = get_auth_header(auth_response['token'])

    
    
    for key in customHeader:
        header[key] = customHeader[key]
    
   
    if method != 'PUT' and method != 'PATCH':
        connection.request(method, route, urllib.parse.urlencode(payload.get('data') or {}), headers=header)
    else:
        connection.request(method, route, json.dumps(payload.get('data') or {}), headers=header)
        
        

    res = connection.getresponse()
    json_response = json.loads(res.read())
    
    return {
        'statusCode': res.status,
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        'body' : json.dumps(json_response)
    } 

def request_raw_file(route, method, payload, scope, connection, customHeader):
    auth_response = client_authentication(scope, payload.get('cognitoId', ""))
    host = os.environ['EHR_HOST']

    if auth_response['statusCode']  != 200:
        return auth_response

    header = get_auth_header(auth_response['token'])
    
    for key in customHeader:
        header[key] = customHeader[key]
    
    encoded = urllib.parse.urlencode({})

    http = urllib3.PoolManager()
    r = http.request(method, "https://" + host + route, headers=header)
    
    if r.status != 200:
        return {
            "statusCode": r.status,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            "body": json.dumps({"content":  json.loads(json.dumps(r.data, default=str))})
        }

    if len(r.data) == 0:
        return {
            "statusCode": 404,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            "body": json.dumps({"error":  "Report not found."})
        }
    
    return {
        "statusCode": r.status,
        "headers": {
            'Content-Type': r.headers["Content-Type"],
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        #"body": json.dumps({"content":  json.loads(json.dumps(report_response.data, default=str).encode('base'))})
        "body": base64.b64encode(r.data).decode('utf-8'),
        "isBase64Encoded": True
    }    
    

def request_report_file(route, method, payload, scope, connection, customHeader):
    http = urllib3.PoolManager()

    auth_response = client_authentication(scope, payload.get("cognitoId", ""))
    host = os.environ['EHR_HOST']

    if auth_response['statusCode']  != 200:
        return auth_response

    header = get_auth_header(auth_response['token'])
    
    for key in customHeader:
        header[key] = customHeader[key]

    redis_client = get_redis_client()
    if redis_client.get(f"{route}:reportfile:href") and redis_client.get(f"{route}:reportfile:contenttype"):
        href = redis_client.get(f"{route}:reportfile:href").decode("utf-8")
        content_type = redis_client.get(f"{route}:reportfile:contenttype").decode('utf-8')
    else:
        r = http.request(method, "https://" + host + route, headers=header)
        
        if r.status != 200:
            return {
                "statusCode": r.status,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Origin': '*',
                    'Allow': 'GET, OPTIONS, POST',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                "body": json.dumps({"content":  json.loads(json.dumps(r.data, default=str))})
            }
            
        report_data = json.loads(r.data)
        
        if len(report_data) == 0:
            return {
                "statusCode": 404,
                "headers": {
                    "Content-Type": "application/json",
                    'Access-Control-Allow-Origin': '*',
                    'Allow': 'GET, OPTIONS, POST',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Headers': '*',
                },
                "body": json.dumps({"error":  "Report not found."})
            }
        
        href = report_data[0]["originaldocument"].get("href", "")
        content_type = report_data[0]["originaldocument"].get("contenttype", "")

        redis_client.set(f"{route}:reportfile:href", href, ex=3600)
        redis_client.set(f"{route}:reportfile:contenttype", content_type, ex=3600)

    report_response = http.request('GET', href,headers=header)
    
    if report_response.status != 200:
        return {
            "statusCode": report_response.status,
            "headers": {
                "Content-Type": "application/json",
                'Access-Control-Allow-Origin': '*',
                'Allow': 'GET, OPTIONS, POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*',
            },
            "body": json.dumps(report_response)
        }

    # redis_client.set(f"{route}", json.dumps(report_response), ex=3600)

    return {
        "statusCode": report_response.status,
        "headers": {
            'Content-Type': content_type,
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        #"body": json.dumps({"content":  json.loads(json.dumps(report_response.data, default=str).encode('base'))})
        "body":base64.b64encode(report_response.data).decode('utf-8'),
        "isBase64Encoded": True
    }

def not_found(action, message = ''):
    return { 
        "statusCode": 404,
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        "body": json.dumps({ "error": message or f"The provided api call, {action}, was not found or is not configured.", "status": 404})
    }
