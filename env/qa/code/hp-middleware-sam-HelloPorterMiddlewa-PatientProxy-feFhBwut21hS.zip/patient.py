import json
import os
import http
from httpUtils import request, not_found ,request_raw_file, request_report_file
import boto3
from boto3.dynamodb.conditions import Key
import urllib.parse
from datetime import datetime,timedelta
from utils import get_redis_client

dynamodb = boto3.resource("dynamodb")


default_headers =    {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Allow': 'GET, OPTIONS, POST',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Allow-Headers': '*'
}

def lambda_handler(event, context):
    method = event.get('method')
    host = os.environ['EHR_HOST']
   
    connection = http.client.HTTPSConnection(host)
    
    if method == 'GET':
        return get_requests(connection, event)
    elif method == 'POST':
        return post_requests(connection, event)
    elif method == 'PUT':
        return put_requests(connection, event)
   
    
    return not_found('', f'The provided request method, {method} is not supported for request {action}') 

def get_requests(connection, event):
    scope = 'athena/service/Athenanet.MDP.*'
    route = ''
    action = event.get('action')
    payload = json.loads(event.get('payload'))
    salesforceHost = os.environ['SF_API_PREFIX']
    salesforce_connection = http.client.HTTPSConnection(salesforceHost)
    custom_header = {}
    
    
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    patientId = payload.get("patientId", "")
     
    if action == 'GetPatient':
        route = f'/v1/{practiceId}/{departmentId}/fhir/dstu2/Patient?_id={patientId}'
    elif action == 'GetPatientAppointments':
       return get_patient_appointments(payload, scope, connection, salesforce_connection, event,custom_header)
    elif action == 'GetPatientAppointment':
        route = f'/v1/{practiceId}/patients/{patientId}/appointments/{payload.get("appointmentId", "")}'
        return request(route, 'GET', payload, scope, connection, event,custom_header)
    elif action == 'GetPatientVisits':
        return get_patient_appointments(payload, scope, connection, salesforce_connection, event,custom_header)
    elif action == 'GetPatientVisitNotes':
        route = f'/v1/{practiceId}/appointments/{payload.get("appointmentId", "")}/notes'
        return request(route, 'GET', payload, scope, connection, event, custom_header)
    elif action == 'GetPatientInsurances':
        route = f'/v1/{practiceId}/patients/{patientId}/insurances'
    elif action == 'GetPatientEncounters':
        route = f'/v1/{practiceId}/{departmentId}/fhir/dstu2/Encounter?patient={patientId}'
    elif action == 'GetPatientEncounter':
        route = f'/v1/{practiceId}/{departmentId}/fhir/dstu2/Encounter/{payload.get("encounterId", "")}'
    elif action == 'GetPatientMedications':
        route = f'/v1/{practiceId}/chart/{patientId}/medications?departmentId={departmentId}&medicationtype=ACTIVE'
    elif action == "GetPatientVisitChart":
        route = f'/v1/{practiceId}/chart/{patientId}/documentexport/{payload.get("documentId", "")}'
        custom_header["Content-Type"] = "text/html"
        custom_header["Accept"] = "*/*"
        return request_raw_file(route, 'GET', payload, scope, connection, custom_header)
    elif action == "GetPatientVisitCharts":
        # route = f'/v1/{practiceId}/patients/{patientId}/documents?departmentid={departmentId}&documentclass=PATIENTRECORD&offset={payload.get("offset", 0)}&limit={payload.get("limit", )}'
        return get_patient_charts(payload, scope, connection,salesforce_connection, event, custom_header)
    elif action == 'GetPatientMedicalReports':
        return get_patient_medical_reports(payload, scope, connection, event)
    elif action == 'GetPatientReport':
        return get_patient_report(payload, scope, connection, event, custom_header)
    elif action == 'GetPatientFollowUps':
        return get_patient_followups(payload,salesforce_connection, event, custom_header)
    elif action == 'GetResourceRecommendations':
        return get_resource_recommendations(payload,salesforce_connection, event, custom_header)
    else:
        return not_found(action)

def get_patient_charts(payload, scope, connection,salesforce_connection, event, custom_header):
    
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    offset = payload.get('start', 1)
    limit = payload.get('limit', 10)
    patientId = payload.get("patientId", "")
    user_uuid = event.get("uuid", "")

    if limit:
        limit = int(limit)
    else:
        limit = 10

    if offset:
        offset = int(offset)
    else:
        offset = 1

    if not is_valid_id(patientId):
        return {
                'statusCode': 200,
                "headers": default_headers,
                'body' : json.dumps([])
            }

    # get  porter plans from sf
    salesforceAccountId = payload.get("salesForceAccount", "")

    redis_client = get_redis_client()

    redis_chart_array = redis_client.get(f'{user_uuid}:visitCharts')
    
    if redis_chart_array != None:
        # redis_chart = []
        # for data in redis_chart_array:
        #     if data:
        #         redis_chart.append(json.loads(data.decode("utf-8")))
        redis_chart = json.loads(redis_chart_array.decode("utf-8"))
        return {
            'statusCode': 200,
            "headers": default_headers,
            'body' : json.dumps(redis_chart[offset-1:(offset-1+limit)])
        }

    salesforce_response = request(f'/services/apexrest/ProfileManagement/v1/{salesforceAccountId}', 'GET', {}, scope, salesforce_connection, event,custom_header,True)
    
    if salesforce_response["statusCode"] != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps({'error': 'An error has occurred while retrieving your visit notes.'})
        }
   
    cases = json.loads(salesforce_response["body"]).get("Cases", [])
   
    if departmentId != 'Aetna':

        # fetch visits from EHR
        route = f'/v1/{practiceId}/patients/{patientId}/documents?departmentid={departmentId}&documentclass=PATIENTRECORD&status=CLOSED'
        response = request(route, 'GET', payload, scope, connection, event,custom_header)
        
        if response["statusCode"] != 200:
            return {
                'statusCode': 500,
                "headers": default_headers,
                'body' : json.dumps(response)
            }
        documents = json.loads(response["body"]).get("documents", [])

        # filter visit which are manual
        filtered =[p for p in documents if p.get("documentsource", "") == "MANUAL"]
        
        for document in filtered:
            document['type'] = 'EHR'

        # merge cases with visits which have visit number and available in ehr visits
        if cases != None:
            for case in cases:
                case['type'] = 'SF'
                if case.get("dateTimeOpened") is not None:
                    case['createddate'] = datetime.strftime(datetime.strptime(f'{case["dateTimeOpened"]}', "%Y-%m-%d"),'%m/%d/%Y')
                else:
                    case['createddate'] = datetime.today().strftime("%m/%d/%Y")
                    
                if case.get("visitNumber") is not None:
                    document = [p for p in filtered if p.get("encounterid") is not None and p["encounterid"] == case['visitNumber']]
                    if document and document[0]:
                        case['document'] = document
                        filtered.remove(document)

        else:
            cases = []
            
        cases.extend(filtered)    

        cases = sorted(cases, key=lambda x: datetime.strptime(f"{x['createddate']}", '%m/%d/%Y'),reverse=True)

    # for case in cases:
    #     redis_client.rpush(f"{salesforceAccountId}:visitCharts", json.dumps(case))

    # redis_client.expire(f"{salesforceAccountId}:visitCharts", 3600)

    redis_client.set(f"{user_uuid}:visitCharts", json.dumps(cases), ex=3600)

    return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps(cases[offset-1:(offset-1+limit)])
    }


def get_patient_report(payload, scope, connection, event, custom_header):
    practiceId = payload.get("practiceId", "")
    patientId = payload.get("patientId", "")
    documentType = payload.get("documentType", "LABRESULT")
    documentId = payload.get("documentId", "-1")
  
    route = f"/v1/{practiceId}/patients/{patientId}/documents/"
    
    if documentType == "LABRESULT":
        route = route + f"labresult/{documentId}"
    else: 
        route = route + f"imagingresult/{documentId}"
    
    custom_header = {}
    custom_header["Content-Type"] = "text/html"
    custom_header["Accept"] = "*/*"
    
    return request_report_file(route, 'GET', payload, scope, connection, custom_header)
    


def create_pcp(payload, scope, connection, event, custom_header):
    practiceId = os.environ["PRACTICE_ID"] or ""
    clincialProviderNpi = payload.get('clincialProviderNpi', '')
    
    firstName = payload.get("firstName", '')
    lastName = payload.get("lastName", '')
    zipCode = payload.get("zip", '33127')
    
    route = f"/v1/{practiceId}/clinicalproviders/search?clinicalprovidernpi={clincialProviderNpi}&firstname={firstName}&lastname={lastName}&zip={zipCode}"
    provider_response = request(route, 'GET', payload, scope, connection, event, custom_header)
    
    if provider_response["statusCode"] != 200:
        return provider_response
    
    provider = json.loads(provider_response["body"]).get("clinicalproviders", [])[0]
    
    route = f"/v1/{practiceId}/chart/configuration/recipientclasses"
    specialty_response = request(route, 'GET', payload, scope, connection, event, custom_header)
    
    specialties = json.loads(specialty_response["body"]).get("recipientclasses", [])

    filtered_arr = [p for p in specialties if p["description"] == "Primary Care Provider"]
    
    recipientclassid = filtered_arr[0].get("code", "")
    
    salesforce_id = payload.get("SFAccount", "")
    table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
    member_search = table.query(IndexName='SFAccount-index', KeyConditionExpression=Key('SFAccount').eq(salesforce_id))
    
    if len(member_search["Items"]) > 1 or len(member_search["Items"]) == 0 or member_search["Items"][0].get("athenaId", "") == "":
        return {
            'statusCode': "300",
            "headers": default_headers,
            'body' : json.dumps({ "error": "No member found."})
        } 
    
    patient_id = member_search["Items"][0].get("athenaId")
    departmentId = member_search["Items"][0].get("departmentId")
    
    route = f"/v1/{practiceId}/chart/{patient_id}/careteam"
   # custom_header["Content-Type"] = "application/x-www-form-urlencoded"
    
    provider_id = provider["clinicalproviderid"]
    payload['data'] = {"departmentid": departmentId, "recipientclassid": recipientclassid, "clinicalproviderid": provider_id }

    member_careteam_update_response = request(route, 'PUT', payload, scope, connection, event, custom_header)
    
    if member_careteam_update_response["statusCode"] != 200:
        return member_careteam_update_response
    
    return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps(member_careteam_update_response)
    }  
    


        
    
def get_patient_medical_reports(payload, scope, connection, event):
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    patientId = payload.get("patientId", "")
    start = payload.get("start", 1)
    limit = payload.get("limit", 10)
    user_uuid = event.get("uuid", "")

    custom_header = {}

    if limit:
        limit = int(limit)
    else:
        limit = 10

    if start:
        start = int(start)
    else:
        start = 1
    
    if not is_valid_id(patientId):
        return {
                'statusCode': 200,
                "headers": default_headers,
                'body' : json.dumps({ "medicalReports": []})
            }

    redis_client = get_redis_client()

    # redis_medical_reports_array = redis_client.lrange(f'{patientId}:medicalReports', 0, -1)
    redis_medical_reports_array = redis_client.get(f'{user_uuid}:medicalReports')
    
    if redis_medical_reports_array != None:
        # redis_medical_reports = []
        # for data in redis_medical_reports_array:
        #     if data:
        #         redis_medical_reports.append(json.loads(data.decode("utf-8")))
        redis_medical_reports = json.loads(redis_medical_reports_array.decode("utf-8"))
        return {
            'statusCode': 200,
            "headers": default_headers,
            'body' : json.dumps({ "medicalReports": redis_medical_reports[start-1:(start-1+limit)], "totalcount": len(redis_medical_reports) })
        }
    # -----

    route = f'/v1/{practiceId}/patients/{patientId}/documents?departmentid={departmentId}&documentclass='
    
    lab_reports = request(route + 'LABRESULT', 'GET', payload, scope, connection, event, custom_header)
    
    if lab_reports["statusCode"] != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps(lab_reports)
        }
    
    non_filtered_labs = json.loads(lab_reports["body"]).get("documents", [])
    labs = [p for p in non_filtered_labs if p.get("tietoorderid", "") == ""]
    imaging_results = request(route + 'IMAGINGRESULT', 'GET', payload, scope, connection, event, custom_header)
    
    if imaging_results["statusCode"] != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps(imaging_results)
        }

    non_filtered_images = json.loads(imaging_results["body"]).get("documents", [])
    images = [p for p in non_filtered_images if p.get("tietoorderid", "") == ""]
    labs.extend(images)
    labs = sorted(labs, key=lambda x: datetime.strptime(f"{x['createddate']}", '%m/%d/%Y'),reverse=True)

    redis_client.set(f"{user_uuid}:medicalReports", json.dumps(labs), ex=3600)
    
    return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps({ "medicalReports": labs[start-1:(start-1+limit)], "totalcount": len(labs) })
    }


def get_patient_appointments(payload,scope, ehr_connection, salesforce_connection, event,custom_header,includeSalesForceAppointments = True):
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    patientId = payload.get("patientId", "")
    salesforceAccountId = payload.get("salesForceAccount", "")
    offset = payload.get('start', 1)
    limit = payload.get('limit', 10)
    showpast=payload.get('showpast', 'true')
    status=payload.get('status', '')
    user_uuid = event.get("uuid", "")

    salesforce_appointments = []
    ehr_appointments = []
    
    if limit:
        limit = int(limit)
    else:
        limit = 10

    if offset:
        offset = int(offset)
    else:
        offset = 1

    # --- 
    redis_client = get_redis_client()

    # redis_appointments_array = redis_client.lrange(f"{salesforceAccountId}:appointments", 0, -1)
    redis_appointments_array = redis_client.get(f"{user_uuid}:appointments")
    
    if redis_appointments_array != None:
        redis_appointments = json.loads(redis_appointments_array.decode("utf-8"))

        if redis_appointments:
            if status == 'Upcoming':
                current_date = datetime.now()
                redis_appointments = [i for i in redis_appointments if current_date < datetime.strptime(f"{i['date']} {i['starttime']}",'%m/%d/%Y %H:%M')]
                redis_appointments = sorted(redis_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'))
            elif status == 'Completed':
                current_date = datetime.now()
                redis_appointments = [i for i in redis_appointments if current_date > datetime.strptime(f"{i['date']} {i['starttime']}",'%m/%d/%Y %H:%M')]
                redis_appointments = sorted(redis_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'),reverse=True)           
            else:
                redis_appointments = sorted(redis_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'),reverse=True)

        print("resdis appointments: ", redis_appointments)
        return {
            'statusCode': 200,
            "headers": default_headers,
            'body' : json.dumps({ "ehrAppointments": redis_appointments[offset-1:(offset-1+limit)] })
        }
    # ---
    if is_valid_id(patientId):
        route = f'/v1/{practiceId}/patients/{patientId}/appointments?offset=0&limit=1000&showpast={showpast}'
        
        ehr_appointments_response = request(route, 'GET', payload, scope, ehr_connection, event,custom_header)

        if ehr_appointments_response["statusCode"] == 200:

            ehr_appointments = json.loads(ehr_appointments_response["body"]).get("appointments", [])
            for appointment in ehr_appointments:
                est_datetime = datetime.strptime(f'{appointment["date"]} {appointment["starttime"]}', "%m/%d/%Y %H:%M")
                if is_dst(est_datetime):
                    est_offset = timedelta(hours=4)  # UTC-5 for Eastern Standard Time
                else:
                    est_offset = timedelta(hours=5)  # UTC-5 for Eastern Standard Time
                    
                    
                
                # Apply the offset to the datetime to get the UTC datetime
                utc_datetime = est_datetime + est_offset
                appointment['date'] = utc_datetime.strftime('%m/%d/%Y')

                appointment['starttime'] = utc_datetime.strftime('%H:%M')


            provider_ids = {appointment["providerid"] for appointment in ehr_appointments}
    
            provider_route = f'/v1/{practiceId}/providers/'
    
            providers = []

            for providerid in provider_ids:
                route = provider_route + providerid
                provider_response = request(route, 'GET', payload, scope, ehr_connection, event,custom_header)
                
                if provider_response["statusCode"] == 200:
                    providers.append(json.loads(provider_response["body"])[0])
                
                    for appointment in ehr_appointments:
                        appointment["provider"] = next((x for x in providers if x["providerid"] == int(appointment["providerid"])), "")
                        #print(datetime.strptime(f'{appointment["starttime"]}{offset}:00','%H:%M%z'))
                        #appointment["starttime"] = datetime.strptime(f'{appointment["starttime"]}{offset}:00','%H:%M%z')

            for providerid in provider_ids:
                route = provider_route + providerid
                provider_response = request(route, 'GET', payload, scope, ehr_connection, event,custom_header)
                
                if provider_response["statusCode"] == 200:
                    providers.append(json.loads(provider_response["body"])[0])
                
                    for appointment in ehr_appointments:
                        appointment["provider"] = next((x for x in providers if x["providerid"] == int(appointment["providerid"])), "")
                
    if includeSalesForceAppointments and is_valid_id(salesforceAccountId):
        parDict = {}
        parDict['accountId'] = salesforceAccountId
        parDict['page'] = 1
        parDict['pageSize'] = 1000
        
        parDict = {i:j for i,j in parDict.items() if j != ''}
        
        query_params = urllib.parse.urlencode(parDict)
        salesforce_appointments_response = request(f'/services/apexrest/EventService?{query_params}', 'GET', {}, scope, salesforce_connection, event,custom_header,True)
        if salesforce_appointments_response["statusCode"] == 200:
            
            salesforce_appointments = json.loads(salesforce_appointments_response["body"]).get("Appointments", [])
            if salesforce_appointments:
                key_map = {'subject': 'patientappointmenttypename', 'dueDate': 'date','appointmentId':'appointmentid','type':'appointmenttype',
                        'dueDateTime': 'starttime', 'durationInMinutes': 'duration','location':'location','phone':'phone'}
                try:
                    for appointment in salesforce_appointments:
                     mapped_appointment = {newkey: appointment[oldkey] for (oldkey, newkey) in key_map.items()}
                     if appointment.get('ownerId','') is not None and appointment.get('ownerId','') != '':
                         mapped_appointment['img'] = os.environ['CareguideImgBasePath']+appointment.get('ownerId')
                         
                     if mapped_appointment['date'] and mapped_appointment['starttime']:
                         mapped_appointment['date'] = datetime.strptime(mapped_appointment['starttime'], '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%m/%d/%Y')
                         mapped_appointment['starttime'] = datetime.strptime(mapped_appointment['starttime'], '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%H:%M')
                     elif mapped_appointment['date']:
                         mapped_appointment['date'] = datetime.strptime(mapped_appointment['date'], '%Y-%m-%d').strftime('%m/%d/%Y')
                         mapped_appointment['starttime'] = '00:00'
                     ehr_appointments.append(mapped_appointment)
                except Exception as e:
                    raise e   

    redis_client.set(f"{user_uuid}:appointments", json.dumps(ehr_appointments), ex=3600)

    if ehr_appointments:
        if status == 'Upcoming':
            current_date = datetime.now()
            ehr_appointments = [i for i in ehr_appointments if current_date < datetime.strptime(f"{i['date']} {i['starttime']}",'%m/%d/%Y %H:%M')]
            ehr_appointments = sorted(ehr_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'))
        elif status == 'Completed':
            current_date = datetime.now()
            ehr_appointments = [i for i in ehr_appointments if current_date > datetime.strptime(f"{i['date']} {i['starttime']}",'%m/%d/%Y %H:%M')]
            ehr_appointments = sorted(ehr_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'),reverse=True)           
        else:
            ehr_appointments = sorted(ehr_appointments, key=lambda x: datetime.strptime(f"{x['date']} {x['starttime']}", '%m/%d/%Y %H:%M'),reverse=True)

    return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps({ "ehrAppointments": ehr_appointments[offset-1:(offset-1+limit)]})
    }  


    
def get_patient_followups(payload,salesforce_connection, event, custom_header):
    query_params_data = {}
    query_params_data['accountId'] = payload.get("salesForceAccount", "")
    query_params_data['page'] = payload.get('start', 1)
    query_params_data['pageSize'] = payload.get('limit', 4)
    query_params_data['status'] = payload.get('status', "")
    user_uuid = event.get("uuid", "")
    query_params_data = {i:j for i,j in query_params_data.items() if j != ''}

    redis_client = get_redis_client()
    if payload.get('status', ""):
        if redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('status', '')}:followups") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('status', '')}:followups").decode("utf-8"))
    else:
        if redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:followups") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:followups").decode("utf-8"))

    query_params = urllib.parse.urlencode(query_params_data)
    salesforce_response = request(f'/services/apexrest/Member/FollowUps?{query_params}', 'GET', {}, {}, salesforce_connection, event,custom_header,True)
    if salesforce_response["statusCode"] != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps({'error': 'An error has occurred while retrieving your follow-ups.'})
        }
    if payload.get('status', ""):
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('status', '')}:followups", json.dumps(salesforce_response), ex=3600)
    else:
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:followups", json.dumps(salesforce_response), ex=3600)

    return salesforce_response
    

#def get_resource_recommendations(payload,salesforce_connection, event, custom_header):
#    salesforceAccountId = payload.get("salesForceAccount", "")
#    offset = payload.get('start', 1)
#    limit = payload.get('limit', 4)
#    
#    query_params = urllib.parse.urlencode({ 'accountId' : salesforceAccountId, 'page' : offset,'pageSize':limit})
#    route = f'/services/apexrest/resourceRecommendations/v1/?{query_params}'
#    
#    return request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True)
    
def get_resource_recommendations(payload,salesforce_connection, event, custom_header):
    parDict = {}
    parDict['accountId'] = payload.get("salesForceAccount", "")
    parDict['page'] = payload.get('start', 1)
    parDict['pageSize'] = payload.get('limit', 4)
    parDict['status'] = payload.get('status', "")
    parDict['type'] = payload.get('type', "")
    user_uuid = event.get("uuid", "")

    redis_client = get_redis_client()
    if parDict['status'] and parDict['type']:
        if redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['status']}:{parDict['type']}:rec") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['status']}:{parDict['type']}:rec").decode("utf-8"))
    elif parDict['status']:
        if redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['status']}:rec") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['status']}:rec").decode("utf-8"))
    elif parDict['type']:
        if redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['type']}:rec") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{parDict['page']}:{parDict['pageSize']}:{parDict['type']}:rec").decode("utf-8"))
    else:
        if redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:rec") != None:
            return json.loads(redis_client.get(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:rec").decode("utf-8"))

    parDict = {i:j for i,j in parDict.items() if j != ''}
    query_params = urllib.parse.urlencode(parDict)
    route = f'/services/apexrest/resourceRecommendations/v1/?{query_params}'
    salesforce_response = request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True) 
    if salesforce_response["statusCode"] != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps({'error': 'An error has occurred while retrieving your resource recommendations.'})
        }
    
    if payload.get('status', '') and payload.get('type', ''):
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('status', '')}:{payload.get('type', '')}:rec", json.dumps(salesforce_response), ex=3600)
    elif payload.get('status', ''):
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('status', '')}:rec", json.dumps(salesforce_response), ex=3600)
    elif payload.get('type', ''):
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:{payload.get('type', '')}:rec", json.dumps(salesforce_response), ex=3600)
    else:
        redis_client.set(f"{user_uuid}:{payload.get('start', 1)}:{payload.get('limit', 4)}:rec", json.dumps(salesforce_response), ex=3600)

    return salesforce_response

    

def post_requests(connection, event):
    scope = 'athena/service/Athenanet.MDP.*'
    route = ''
    action = event.get('action')
    payload = json.loads(event.get('payload'))
    
    custom_header = {}
    salesforceHost = os.environ['SF_API_PREFIX']
    salesforce_connection = http.client.HTTPSConnection(salesforceHost)
    practiceId = payload.get("practiceId", "")
    
    if action == 'CreatePatient':
        route = f'/v1/{practiceId}/patients'
    elif action == 'GetPatientMedications':
        return get_patient_medications(payload, scope, connection, event, custom_header)
    elif action == 'CreatePCP':
        return create_pcp(payload, scope, connection, event, custom_header)
    elif action == 'GetPatientPorterPlan':
        return fetch_porter_planvi(payload, scope, connection, event, custom_header, salesforce_connection)
    else:
        return not_found(action)

    return request(route, 'POST', payload, scope, connection, event)

def get_patient_medications(payload,scope, ehr_connection, event,custom_header):
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    patientId = payload.get("patientId", "")
    offset = payload.get('start', 1)
    limit = payload.get('limit', 10)
    status = payload.get('status', "")
    user_uuid = event.get("uuid", "")

    if limit:
        limit = int(limit)
    else:
        limit = 10

    if offset:
        offset = int(offset)
    else:
        offset = 1

    if not is_valid_id(patientId) :
        return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps({ "medications": []})
        }     
    if status == 'Current':
        filter_type = 'ACTIVE'
    elif status == 'Past':
        filter_type = 'HISTORICAL'
    else: 
        filter_type = ''
    
    #add query params
    parDict = {}
    parDict['departmentId'] = departmentId
    parDict['medicationtype'] = filter_type
    parDict = {i:j for i,j in parDict.items() if j != ''}
    query_params = urllib.parse.urlencode(parDict)
    route = f'/v1/{practiceId}/chart/{patientId}/medications?{query_params}'

    # --- 
    redis_client = get_redis_client()

    # redis_medications_array = redis_client.lrange(f"{route}:medications", 0, -1)
    redis_medications = redis_client.get(f"{user_uuid}:{route}:medications")
    
    if redis_medications != None:
        # redis_medications = []
        # for data in redis_medications_array:
        #     if data:
        #         redis_medications.append(json.loads(data.decode("utf-8")))
        redis_medications = json.loads(redis_medications.decode("utf-8"))

        return {
            'statusCode': 200,
            "headers": default_headers,
            'body' : json.dumps({"medications": redis_medications[offset-1:(offset-1+limit)]})
        }
    # ---

    response = request(route, 'GET', payload, scope, ehr_connection, event,custom_header)
    if response["statusCode"]   != 200:
        return {
            'statusCode': 500,
            "headers": default_headers,
            'body' : json.dumps(response)
        }
    
    medications = json.loads(response["body"]).get("medications", [])

    # for medication in medications:
    #     redis_client.rpush(f"{route}:medications", json.dumps(medication))

    # redis_client.expire(f"{route}:medications", 3600)
    redis_client.set(f"{user_uuid}:{route}:medications", json.dumps(medications), ex=3600)

    return {
        'statusCode': 200,
        "headers": default_headers,
        'body' : json.dumps({ "medications": medications[offset-1:(offset-1+limit)]})
    }    
 
 
def put_requests(connection, event):
    print("inside put request function-----------------")
    print("Event inside put requets funtion -------------------",event)
    route = ''
    scope = 'athena/service/Athenanet.MDP.*'
    action = event.get('action')
    payload = json.loads(event.get('payload'))
    practiceId = payload.get("practiceId", "")
    sf_account = payload.get("salesForceAccount", "")
    user_uuid = event.get("uuid", "")
    redis_client = get_redis_client()

    if action == 'UpdatePatient':
        patientId = payload["patientId"] or payload['data'][0]['patientId']
        route = f'/v1/{practiceId}/patients/{patientId}'
    elif action == 'UpdateResourceRecommendations':
        salesforceHost = os.environ['SF_API_PREFIX']
        salesforce_connection = http.client.HTTPSConnection(salesforceHost)
        if payload.get('id') and payload.get('status') and sf_account:
            payload['data'] = {"recordId": payload.get('id'), "status": payload.get('status') }
            update_rec_request = request(f'/services/apexrest/resourceRecommendations/v1/', 'PUT', payload, {}, salesforce_connection, event,{},True)
            
            if update_rec_request.get("statusCode", 400) == 200:
                sf_keys = redis_client.scan_iter(f"*{user_uuid}:*")
                for sf_key in sf_keys:
                    keys = []
                    keys.append(sf_key.decode("utf-8"))
                    for key in keys:
                        if ":rec" in key:
                            redis_client.delete(key)
                return update_rec_request
        else:
            return {
                    'statusCode': 400,
                    "headers": default_headers,
                    'body' : json.dumps({'message':'invalid body'})
            } 
    elif action == 'UpdateFollowUps':
        salesforceHost = os.environ['SF_API_PREFIX']
        salesforceAccountId = payload.get("salesForceAccount", "")
        salesforce_connection = http.client.HTTPSConnection(salesforceHost)
        if (payload.get('id') and payload.get('status')) or (payload.get('ids') and payload.get('status')):

            if (payload.get('id') and payload.get('status')):
                payload['data'] = {"recordId": payload.get('id'), "status": payload.get('status') }
                followup_response = request(f'/services/apexrest/Member/FollowUps/'+salesforceAccountId, 'PATCH', payload, {}, salesforce_connection, event,{},True)

                if followup_response.get("statusCode", 400) == 200:
                    redis_follow_ups_cleanup(user_uuid)
                    return followup_response
            else:
                followup_data = []
                for id in payload.get('ids'):
                    followup_data.append({"recordId": id, "status": payload.get('status')})

                payload['data'] = {"followup":followup_data,"accountId": salesforceAccountId}
                followup_response = request(f'/services/apexrest/Member/FollowUps/Bulk/', 'PATCH', payload, {}, salesforce_connection, event,{},True)

                if followup_response.get("statusCode", 400) == 200:
                    redis_follow_ups_cleanup(user_uuid)
                    return followup_response
        else:
            return {
                    'statusCode': 400,
                    "headers": default_headers,
                    'body' : json.dumps({'message':'invalid body'})
            }             
    else:
        return not_found(action)

    return request(route, 'PUT', payload.data, scope, connection, event)

def redis_follow_ups_cleanup(user_uuid):
    redis_client = get_redis_client()
    sf_keys = redis_client.scan_iter(f"*{user_uuid}:*")
    for sf_key in sf_keys:
        keys = []
        keys.append(sf_key.decode("utf-8"))
        for key in keys:
            if ":followups" in key:
                redis_client.delete(key)

###
def fetch_porter_planvi(payload, scope, connection, event, custom_header, salesforce_connection):
    practiceId = payload.get("practiceId", "")
    departmentId = payload.get("departmentId", "")
    patientId = payload.get("patientId", "")
    visitNumer = payload.get("visitNumber", "")
    caseNumer = payload.get("caseNumber", "")
    sf_account = payload.get("salesForceAccount", "")
    user_uuid = event.get("uuid", "")

    redis_client = get_redis_client()
    
    if (visitNumer != "" and caseNumer != ""):
        if redis_client.get(f"{user_uuid}:{visitNumer}:{caseNumer}:planvi") != None:
            return {'statusCode': 200, "headers": default_headers, 'body' : json.dumps(json.loads(redis_client.get(f"{user_uuid}:{visitNumer}:{caseNumer}:planvi").decode("utf-8"))) }

        encounter_list = []
        encounter_list.append(str(visitNumer))
        merged_dict = {}
        route = f'/services/apexrest/CaseService/v1/{caseNumer}?accountId={sf_account}'  
        case_response = request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True)
        if case_response['body'] is not None:
            merged_dict = json.loads(case_response['body'])
        
        if departmentId != 'Aetna':
            route = f'/v1/{practiceId}/chart/{patientId}/medications?departmentid={departmentId}'
            medication_data = request(route, 'GET', payload, scope, connection, event,custom_header)
            if medication_data['body'] is not None:
                medication_data = json.loads(medication_data['body'])
                medication_data = medication_data['medications']
                data = []
                for k in medication_data:
                    for l in k:
                        if 'encounterid' in l.keys():
                            if str(l['encounterid']) in encounter_list :
                                data.append(l)
                merged_dict['medications'] = data

        redis_client.set(f"{user_uuid}:{visitNumer}:{caseNumer}", json.dumps(merged_dict), ex=3600)
    elif visitNumer == '':
        if redis_client.get(f"{user_uuid}:{caseNumer}:planvi") != None:
            return {'statusCode': 200, "headers": default_headers, 'body' : json.dumps(json.loads(redis_client.get(f"{user_uuid}:{caseNumer}:planvi").decode("utf-8"))) }
        
        merged_dict = {}
        route = f'/services/apexrest/CaseService/v1/{caseNumer}?accountId={sf_account}'
        case_response = request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True)
        if case_response['body'] is not None:
            merged_dict = json.loads(case_response['body'])
        redis_client.set(f"{user_uuid}:{caseNumer}", json.dumps(merged_dict), ex=3600)
    elif caseNumer == '':
        if redis_client.get(f"{user_uuid}:{visitNumer}:planvi") != None:
            return {'statusCode': 200, "headers": default_headers, 'body' : json.dumps(json.loads(redis_client.get(f"{user_uuid}:{visitNumer}:planvi").decode("utf-8"))) }

        encounter_list = []
        encounter_list.append(str(visitNumer))
       
        # route = f'/v1/{practiceId}/patients/{patientId}/documents?departmentid={departmentId}'
        # document_data = request(route, 'GET', payload, scope, connection, event,custom_header)
        data = []
        merged_dict = {}
        # document_data = json.loads(document_data['body'])
        # document_data = document_data['documents']
        # for n in document_data:
        #     if 'encounterid' in n.keys():
        #         if str(n['encounterid']) in encounter_list :
        #             data.append(n)
        # merged_dict['documents'] = data
        # route = f'/v1/{practiceId}/chart/{patientId}/encounters?departmentid={departmentId}'
        # encounter_data = request(route, 'GET', payload, scope, connection, event,custom_header)
        # encounter_data = json.loads(encounter_data['body'])
        # encounter_data = encounter_data['encounters']
        route = f'/v1/{practiceId}/chart/{patientId}/medications?departmentid={departmentId}'
        medication_data = request(route, 'GET', payload, scope, connection, event,custom_header)
        if medication_data['body'] is not None:
            medication_data = json.loads(medication_data['body'])
            medication_data = medication_data['medications']
        # for i in encounter_data :
        #     if ((i['encountertype'] == 'VISIT') and (str(i['encounterid']) in encounter_list)):
        #         data.append(i)
        # merged_dict['visit'] = data
        # data = []
            for k in medication_data:
                for l in k:
                    if 'encounterid' in l.keys():
                        if str(l['encounterid']) in encounter_list :
                            data.append(l)
            merged_dict['medications'] = data
        data = []
        print('1', medication_data )
        ### sf fetch
        parDict = {}
        parDict['accountId'] = payload.get("salesForceAccount", "")
        parDict['page'] = '1'
        parDict['pageSize'] = '100'
        parDict = {i:j for i,j in parDict.items() if j != ''}
        query_params = urllib.parse.urlencode(parDict)
        route = f'/services/apexrest/resourceRecommendations/v1/?{query_params}'
        resource_response = request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True)
        if resource_response['body'] is not None:
            resource_response = json.loads(resource_response['body'])
        ###
        followDict = {}
        followDict['accountId'] = payload.get("salesForceAccount", "")
        followDict['page'] = payload.get('start', 1)
        followDict['pageSize'] = payload.get('limit', 4)
        followDict['status'] = payload.get('status', "")
        followDict = {i:j for i,j in followDict.items() if j != ''}
        query_params = urllib.parse.urlencode(followDict)
        route = f'/services/apexrest/Member/FollowUps/?{query_params}'
        follow_up_response = request(route, 'GET', {}, {}, salesforce_connection, event,custom_header,True)
        if follow_up_response['body'] is not None:
            follow_up_response = json.loads(follow_up_response['body'])
        data = []
        follow_up_response = follow_up_response['followUpList']
        for n in follow_up_response:
            if str(n['visitNumber']) in encounter_list :
                data.append(n)
        merged_dict['followUps'] = data

        recommendations = []

        for rr in resource_response :
            if str(rr['visitNumber']) in encounter_list :
                recommendations.append(rr)
        merged_dict['recommendations-up'] = recommendations  

        redis_client.set(f"{user_uuid}:{visitNumer}", json.dumps(merged_dict), ex=3600)


    return {'statusCode': 200, "headers": default_headers, 'body': json.dumps(merged_dict)}
###
    
def is_dst(date):
    # Set the DST transition dates for the year in question
    dst_start = datetime(date.year, 3, 1)  # DST starts on the 1st Sunday of March
    dst_end = datetime(date.year, 11, 1)  # DST ends on the 1st Sunday of November

    # Calculate the DST start and end dates using timedelta
    dst_start += timedelta(days=(6 - dst_start.weekday() + 7) % 7)  # Next Sunday
    dst_end += timedelta(days=(6 - dst_end.weekday() + 7) % 7)  # Next Sunday

    # Check if the date is within the DST period
    return dst_start <= date < dst_end

def is_valid_id(id):
    return id and id != "" and id != "NC"
