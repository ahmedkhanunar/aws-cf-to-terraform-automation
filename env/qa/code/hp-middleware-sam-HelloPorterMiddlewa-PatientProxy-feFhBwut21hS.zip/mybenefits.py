import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import os
from datetime import datetime

dynamodb = boto3.resource("dynamodb")

benefittable = os.environ['benefittable']
planProgramtable = os.environ['planProgramtable']
benefittable =  dynamodb.Table(benefittable) 
planProgramtable =  dynamodb.Table(planProgramtable) 
memberMappingTable = dynamodb.Table(os.environ["MiddlewareMemberMappingTable"])
memberEnrollmentTable = dynamodb.Table(os.environ["EnrollmentDetailsTable"])
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def get_my_benefits(event, context):
    cognitoId = event['requestContext']['authorizer']['claims']['username']
    bodyData = event.get('queryStringParameters') if event.get('queryStringParameters') != None else {}
    
    if bodyData.get('carereceiverId','') != '':
        
        memberData = get_member_data(bodyData.get('carereceiverId',''))
        
        if memberData is not None:
            cognitoId = memberData['cognitoId']
        else:
            return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    else:
        memberData = get_member_data(cognitoId,True)
        if memberData is not None:
            cognitoId = memberData['cognitoId']
        else:
            return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    payload = get_member_plan_data(memberData['uuid'])
    department_id = memberData.get('departmentId', "")

    if payload is None:
        return {
                'statusCode': "204",
                "headers": headers,
                'body': json.dumps({"error": "Benefit Information Not Found"})
            } 

    if payload.get("ContractID","") == '' :
        return {
            'statusCode': "204",
            "headers": headers,
            'body': json.dumps({"error": "Benefit Information Not Found"})
        }

            # dynamo_uuid = response['Items'][0]
            # if ((int(time.time())) - (int(dynamo_uuid['ts'])) < 3000): 
            #     access_token = dynamo_uuid['token']
            
    data = fetchBenefit(department_id, payload.get("ContractID",""), payload.get("GroupID",""), payload.get("SubGroupID",""), payload.get("PBP",""), payload.get("PlanID",""), payload.get("MetalLevel",""))
    
    newData =[]
    for rec in data:
        procdata = {}
        if 'benefit' in rec:
            procdata['isURL'] = rec.get('isURL', '')
            procdata['benefit'] = rec.get('benefit', '')
            procdata['description'] = rec.get('description', '')
            procdata['program'] = rec.get('program', '')
            procdata['benefit_amt'] = rec.get('benefit_amt', '')
            procdata['sortOrder'] = rec.get('row_id', '')
            planName = rec.get('benefit', '')
            fetchedData = fetchPlan(rec['row_id'])
            newData.append(procdata)
            newData.extend(fetchedData)
        else:
            newData = data
        
        data = json.dumps(newData,cls=DecimalEncoder)


    return {
        'statusCode': "200",
        "headers": headers,
        'body': json.dumps(newData,cls=DecimalEncoder)
        
}

def get_member_data(id,isCognitoId=False):
    
    if isCognitoId:
        memberMappingResponse = memberMappingTable.query(IndexName='cognitoId-index', KeyConditionExpression=Key('cognitoId').eq(id))
    else:
        memberMappingResponse = memberMappingTable.query(KeyConditionExpression=Key('uuid').eq(id))

    if len(memberMappingResponse["Items"]) == 0 or len(memberMappingResponse["Items"]) > 1:
            return None
    return memberMappingResponse["Items"][0]

def  get_member_plan_data(uuid):
    response = memberEnrollmentTable.query(KeyConditionExpression=Key('uuid').eq(uuid))
    if len(response["Items"]) == 0:
            return
            
    return response["Items"][0]
    


def fetchPlan(planLookupId):
    plan_data = {}
    retData =[]
    fe = Key('plan_lookup_id').eq(planLookupId) 
    response = planProgramtable.scan(FilterExpression=fe)
    if len(response['Items'])  > 0:
        resdata = response['Items']

        for resp in resdata:
            
            plan_data['isURL'] ='0'
            plan_data['benefit'] = resp['benefit']
            plan_data['description'] = resp['description']
            plan_data['program'] = resp.get('program', "")
            plan_data['benefit_amt'] = resp['benefit_amt']
            plan_data['sortOrder'] = resp['row_id']
            retData.append(plan_data)
            plan_data = {}
    return retData

import os
import json

def generate_benefit_query(department_id, plan_data):
    #path = "nvirginia-prod/5170568595690779/FileStore/tables/Customer/Shared/Inputs/benefits_mapping.json"
    #path = "benefits_mapping.json"

    s3 = boto3.client('s3')
    bucket_name = os.getenv('BENEFIT_CONFIG_BUCKET', "hpdatabricksroot")
    key = os.getenv('BENEFITS_CONFIG_PATH', "benefits_mapping.json")
    #key = path
    s3_object = s3.get_object(Bucket=bucket_name, Key=key)
    json_content = s3_object['Body'].read().decode('utf-8')
    config = json.loads(json_content)

    configs = config.get(department_id, {})
    print(configs)
    sorted_query = []
    
    

    year = datetime.now().year 
    today = datetime.today().strftime('%d-%m-%Y')
    iso_today = datetime.today().strftime('%Y-%m-%d')



    configs_sorted_dict = dict(sorted(configs.items()))

    for config_key, config_value in configs_sorted_dict.items(): 
        fe = Attr('department_id').eq(department_id)
        if year > 2024:
            fe = fe & (Attr('benefit_expiration_date').gte(today) | Attr('benefit_expiration_date').gte(iso_today)) & Attr('benefit_year').eq(f'{year}')
        base_ids = config_value
        sorted_dict = dict(sorted(base_ids.items()))
        for key, value in sorted_dict.items():
            #if the value is in the benefits table, its required to match i.e. if there is a group id on the benefit, the member MUST have the same id
            if value != '' and key != 'customer':
                fe = fe & Attr(key).exists() & Attr(key).eq(plan_data.get(key, ''))
            elif value == '':
                fe = fe & (Attr(key).not_exists() | Attr(key).eq(''))

        sorted_query.append({ 'rank': config_key, 'query': fe})
    return sorted_query


def fetchBenefit(department_id, contract_id, group_id, subgroup_id, pbp, plan_id, metal_level):
    data = []

    plan_data = {
        "contract_id": contract_id,
        "GroupID": group_id,
        "SubGroupID": subgroup_id,
        "Pbp": pbp,
        "plan_id": plan_id,
        "metal_level": metal_level
    }

    queries = generate_benefit_query(department_id, plan_data)

    data = []

    for item in queries:
        response = benefittable.scan(FilterExpression=item.get('query', ''))

        if len(response['Items'])  > 0:
            # print(response['Items'])
            response_data = response['Items']
            while 'LastEvaluatedKey' in response:
                print(response['LastEvaluatedKey'])
                response = benefittable.scan(ExclusiveStartKey=response['LastEvaluatedKey'],FilterExpression=item.get('query', ''))
                response_data.extend(response['Items'])

            print(response_data)
            data = response_data
            break

    return data

from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return json.JSONEncoder.default(self, obj)