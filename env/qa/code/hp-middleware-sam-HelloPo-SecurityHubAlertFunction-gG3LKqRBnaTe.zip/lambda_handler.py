import json
import boto3
import os
sns = boto3.client('sns')
def lambda_handler(event, context):
   try:
       # Extract SNS message safely
       records = event.get('Records', [])
       sns_message = records[0].get('Sns', {}).get('Message') if records else None
       security_hub_finding = json.loads(sns_message) if sns_message else {}
       # Detail dictionary shortcut
       detail = security_hub_finding.get('detail', {})
       findings = detail.get('findings', [])
       finding = findings[0] if findings else {}
       col_pad = 30
       severity_label = finding.get('Severity', {}).get('Label', 'Unknown')
       title = finding.get('Title', 'No Title')
       region = finding.get('Region', 'us-east-1')
       created_at = finding.get('CreatedAt', 'N/A')
       last_observed = finding.get('LastObservedAt', 'N/A')
       generator_id = finding.get('GeneratorId', '')
       product_fields = finding.get('ProductFields', {})
       resources = finding.get('Resources', [])
       resource = resources[0] if resources else {}
       # Email subject and body
       email_subject = f"SecurityHub {severity_label} - {title}"
       email_body = f"{title}\n\nFinding Overview\n{'='*44}"
       email_body += f"\n{'Severity:'.ljust(col_pad)}{severity_label}"
       email_body += f"\n{'Control:'.ljust(col_pad)}{product_fields.get('ControlId', '')}"
       email_body += f"\n{'Finding:'.ljust(col_pad)}{product_fields.get('aws/securityhub/annotation', '')}"
       email_body += f"\n{'Region:'.ljust(col_pad)}{region}"
       email_body += f"\n{'Found On:'.ljust(col_pad)}{created_at}"
       email_body += f"\n{'Last Observed On:'.ljust(col_pad)}{last_observed}"
       email_body += f"\n{'Resource Type:'.ljust(col_pad)}{resource.get('Type', 'N/A')}"
       email_body += f"\n{'Affected Resource:'.ljust(col_pad)}{resource.get('Id', 'N/A')}"
       email_body += f"\n{'Associated Standards:'.ljust(col_pad)}"
       standards = finding.get('Compliance', {}).get('AssociatedStandards', [])
       for standard in standards:
           email_body += f"{''.ljust(col_pad)}{standard.get('StandardsId', '')}\n"
       link = f"https://{region}.console.aws.amazon.com/securityhub/home?region={region}#{generator_id}"
       email_body += f"\n{'Detailed Link:'.ljust(col_pad)}{link}"
       print("Subject:", email_subject)
       print("Body:", email_body)
       sns.publish(
           Message=email_body,
           Subject=email_subject[:99],
           TopicArn=os.environ.get('TOPIC_ARN', '')
       )
   except Exception as error:
       print("Error:", error)
       sns.publish(
           Message=json.dumps(event, indent=4),
           Subject="AWS SecurityHub Finding",
           TopicArn=os.environ.get('TOPIC_ARN', '')
       )
   return {
       'statusCode': 200,
       'body': json.dumps({"message": "Success"})
   }
