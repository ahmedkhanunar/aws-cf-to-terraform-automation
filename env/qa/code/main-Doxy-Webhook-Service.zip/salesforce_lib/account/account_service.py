import json
from salesforce_lib.core.sf_api_service import *
import sys
import traceback

headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }


def patch_account(message):
    try:
              
        sf_token = generate_access_token_bb()
        salesforce_url = f"https://helloporter22--fsldev.sandbox.my.salesforce.com/services/apexrest/Account/Update/"

        print(f"Bearer {sf_token['token']}")
        
        sf_response = requests.patch(
            salesforce_url,
            json=message,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {sf_token['token']}"
            }
        )
        
        return {
            "statusCode": sf_response.status_code,
            "body": json.dumps({
                "message": "Service Appointment Updated",
            }),
            "headers": headers
        }
        
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "An error occurred while updating service appointment"}),
            "headers": headers
        }