from salesforce_lib.core.sf_api_service import *



class SalesforceAppointmentService:

    def __init__(self, api):
        self.api = api

    def patch_serviceappointment(self, payload):
        
        sf_payload = {
            "serviceappointmentid": payload.appointmentId,
            "athenaappointmentid": payload.athenaAppointmentId,
            "telehealthLink": payload.athenaAppointmentTelehealthLink
        }
        
        url = '/services/apexrest/ServiceAppointment/Update/' 
        response = self.api.PATCH(url, sf_payload)
        return response
