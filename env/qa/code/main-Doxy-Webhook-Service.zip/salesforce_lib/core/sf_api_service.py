"""
Salesforce API Service Module

This module provides classes for interacting with Salesforce's REST API,
including authentication and request handling.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

import os
import jwt
import json
import math
import requests
from enum import Enum
from datetime import datetime
from typing import ClassVar

class ResponseException(Exception):
    """🚫 Exception raised for Salesforce API response errors."""
    
    text: str
    """The error message or response text."""
    
    response: requests.Response
    """The full response object from the request."""
    
    def __init__(self, text: str, response: requests.Response):
        self.text = text
        self.response = response
        
    def __str__(self):
        try:
            if self.response and self.response.text:
                response_data = json.loads(self.response.text)
                if 'error' in response_data and 'error_description' in response_data:
                    return f"Authentication failed: {response_data['error_description']}"
            return self.text
        except:
            return self.text


class GrantType(Enum):
    """🔑 Supported Salesforce OAuth grant types."""
    
    BEARER = 'urn:ietf:params:oauth:grant-type:jwt-bearer'
    """JWT bearer token grant type."""
    
    PASSWORD = 'password'
    """Username-password grant type."""


class SFConnection:
    """🔌 Manages Salesforce API connections and requests."""
    
    sf_user: str
    """Salesforce username loaded from SF_USER environment variable"""
    
    sf_host: str
    """Salesforce instance hostname loaded from SF_HOST environment variable"""
    
    secret: dict
    """Authentication credentials containing keys like clientid, clientsecret, etc."""
    
    grant_type: GrantType
    """OAuth grant type (BEARER or PASSWORD) used for authentication"""
    
    session: requests.Session
    """Persistent HTTP session for making API requests"""
    
    access_token: str
    """Current OAuth access token obtained after authentication"""

    API_VERSION: ClassVar[str] = "v57.0"
    """Salesforce API version used for requests"""

    def __init__(self, secret: dict, grant_type: GrantType):
        """Create a new Salesforce connection.
        
        Example:
            ```python
            secret = {"clientid": "xxx", "clientsecret": "yyy"}
            conn = SFConnection(secret, GrantType.PASSWORD)
            ```
        """
        self.sf_user = os.getenv('SF_USER')
        self.sf_host = os.getenv('SF_HOST')
        self.secret = secret
        self.grant_type = grant_type
        self.session = requests.Session()
        self.access_token = None
        self._authenticate()

    def _authenticate(self) -> dict:
        print("Starting Salesforce authentication...")
        headers = { 
            'Accept-Encoding': 'gzip, deflate, br',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json',
            'Host': self.sf_host
        }            

        params = {}
        if self.grant_type is GrantType.BEARER:
            print("Using Bearer token authentication flow")
            print(f"Secret: {self.secret}")
            if not self.secret or not isinstance(self.secret, dict):
                raise ValueError("Invalid secret provided. Must be a dictionary with required keys.")
            
            required_keys = ['SF_PRIVATE_KEY', 'SF_ISSUER', 'SF_SUBJECT']
            missing_keys = [key for key in required_keys if key not in self.secret]
            if missing_keys:
                raise ValueError(f"Missing required secret keys: {', '.join(missing_keys)}")
            
            try:
                private_key = self.secret["SF_PRIVATE_KEY"]
                
                key_body = private_key
                key_body = key_body.replace("-----BEGIN RSA PRIVATE KEY-----", "")
                key_body = key_body.replace("-----END RSA PRIVATE KEY-----", "")
                key_body = key_body.replace(" ", "")
                key_body = key_body.replace("\\n", "")
                key_body = key_body.replace("\n", "")
                
                formatted_key = ["-----BEGIN RSA PRIVATE KEY-----"]
                
                while key_body:
                    formatted_key.append(key_body[:64])
                    key_body = key_body[64:]
                
                formatted_key.append("-----END RSA PRIVATE KEY-----")
                
                private_key = '\n'.join(formatted_key)
                
                if not private_key.strip().startswith("-----BEGIN"):
                    raise ValueError(
                        "Invalid private key format. Key should start with '-----BEGIN'"
                        "\nPlease check the key format in Secrets Manager"
                    )
                
                audience = "https://test.salesforce.com" if "sandbox" in self.sf_host.lower() else "https://login.salesforce.com"
                # audience = "https://test.salesforce.com/services/oauth2/token"
                claimSet = {
                    "iss": self.secret['SF_ISSUER'],
                    "aud": audience,
                    "sub": self.secret['SF_SUBJECT'],
                    "exp": math.floor(int(datetime.now().timestamp()) + (3 * 600))
                }
                
                try:
                    jwtToken = jwt.encode(claimSet, private_key, algorithm='RS256')
                except Exception as e:
                    raise ValueError(
                        f"Failed to encode JWT token with provided private key: {str(e)}\n"
                        "Please verify the private key format in Secrets Manager"
                    ) from e
                    
                params = {"grant_type": self.grant_type.value, "assertion": jwtToken}
                
            except Exception as e:
                if isinstance(e, ValueError):
                    raise
                raise ValueError(f"Error during JWT token creation: {str(e)}") from e
        elif self.grant_type is GrantType.PASSWORD:
            print("Using Password authentication flow")
            params = {'grant_type': self.grant_type.value,
                'username': self.sf_user,
                'password': self.secret['password'],
                'client_id': self.secret['clientid'],
                'client_secret': self.secret['clientsecret']
                }
        
        test_url = audience+"/services/oauth2/token"
        response = requests.post(test_url, data=params, headers=headers)
        print(f"PROPER RESPONSE: {response.text}")
        jsonResponse = json.loads(response.text)
        if 'access_token' not in jsonResponse:
            error_description = jsonResponse.get('error_description', 'Unknown error')
            raise ResponseException(f"Authentication failed: {error_description}", response)
        
        print("Authentication successful - received access token")
        self.access_token = jsonResponse['access_token']
        self.instance_url = jsonResponse['instance_url']
        return {
            'statusCode': 200,
            'token': self.access_token,
            'instance_url': self.instance_url
        }

    def _handle_authentication(self, request_headers: dict) -> dict:
        """Refresh authentication when token expires.
        
        Args:
            request_headers: The current request headers.
            
        Returns:
            Updated headers with new access token.
        """
        self._authenticate()
        request_headers['Authorization'] = f"Bearer {self.access_token}"
        return request_headers

    def PATCH(self, path: str, parameters: dict = None, headers: dict = None) -> requests.Response:
        """
        Send a PATCH request to Salesforce API.

        Parameters
        ----------
        path : str
            The API endpoint path to send the request to
        parameters : dict, optional
            Request body parameters to send with the request
        headers : dict, optional
            Additional request headers to include

        Returns
        -------
        requests.Response
            The response from the Salesforce API

        Raises
        ------
        ResponseException
            If the request fails or returns an error response
        """
        try:
            salesforce_url = f"https://{self.sf_host}{path}"
            response = requests.patch(
                salesforce_url,
                json=parameters,
                headers={
                    'Content-Type': 'application/json',
                    'Authorization': f"Bearer {self.access_token}"
                }
            )
            return response
        except:
            raise ResponseException(response.text, response)

    def GET(self, path: str) -> requests.Response:
        """
        Send a GET request to Salesforce API.

        Parameters
        ----------
        path : str
            The API endpoint path to send the request to

        Returns
        -------
        requests.Response
            The response from the Salesforce API

        Raises
        ------
        ResponseException
            If the request fails or returns an error response
        """
        try:
            salesforce_url = f"https://{self.sf_host}{path}"
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {self.access_token}"
            }
            
            response = self.session.get(salesforce_url, headers=headers)
            
            if response.status_code == 401:
                headers = self._handle_authentication(headers)
                response = self.session.get(salesforce_url, headers=headers)
            
            try:
                response.json()
                return response
            except json.JSONDecodeError:
                if response.status_code != 200:
                    raise ResponseException(response.text, response)
                return response
                
        except Exception as e:
            if isinstance(e, ResponseException):
                raise
            raise ResponseException(str(e), response if 'response' in locals() else None)

    def POST(self, path: str, parameters: dict = None, headers: dict = None) -> requests.Response:
        """
        Send a POST request to Salesforce API.

        Parameters
        ----------
        path : str
            The API endpoint path to send the request to
        parameters : dict, optional
            Request body parameters to send with the request
        headers : dict, optional
            Additional request headers to include

        Returns
        -------
        requests.Response
            The response from the Salesforce API

        Raises
        ------
        ResponseException
            If the request fails or returns an error response
        """
        try:
            salesforce_url = f"{self.instance_url}{path}"
            request_headers = {
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {self.access_token}"
            }
            if headers:
                request_headers.update(headers)
            # print(f"Calling Request:: with url {salesforce_url}\n and headers{request_headers} & parameters: {parameters}")
            response = self.session.post(
                salesforce_url,
                data=parameters,
                headers=request_headers
            )
            # print(f"Shwoing Response: {response.text}")
            if response.status_code == 401:
                request_headers = self._handle_authentication(request_headers)
                response = self.session.post(salesforce_url, json=parameters, headers=request_headers)
            
            if response.status_code not in [200, 201, 204]:
                raise ResponseException(response.text, response)
            
            return response
        except Exception as e:
            raise ResponseException(str(e), response if 'response' in locals() else None)
        
    def PUT(self, path: str, parameters: dict = None, headers: dict = None) -> requests.Response:
            """
            Send a PUT request to Salesforce API.
            PUT is typically used for full updates of existing resources.

            Parameters
            ----------
            path : str
                The API endpoint path to send the request to.
                This path should usually include the ID of the record being updated.
            parameters : dict, optional
                Request body parameters to send with the request (the updated data).
            headers : dict, optional
                Additional request headers to include.

            Returns
            -------
            requests.Response
                The response from the Salesforce API.

            Raises
            ------
            ResponseException
                If the request fails or returns an error response.
            """
            try:
                salesforce_url = f"{self.instance_url}{path}"
                request_headers = {
                    'Content-Type': 'application/json',
                    'Authorization': f"Bearer {self.access_token}"
                }
                if headers:
                    request_headers.update(headers)

                print(f"Calling PUT Request:: with url {salesforce_url}\n and headers{request_headers} & parameters: {parameters}")
                response = self.session.put( # Key change: using self.session.put
                    salesforce_url,
                    data=parameters, # PUT requests typically send JSON body
                    headers=request_headers
                )
                print(f"Showing PUT Response: {response.text}")

                # Handle 401 Unauthorized - re-authenticate and retry
                if response.status_code == 401:
                    print("PUT: 401 Unauthorized. Attempting to re-authenticate and retry...")
                    request_headers = self._handle_authentication(request_headers)
                    response = self.session.put(salesforce_url, json=parameters, headers=request_headers) # Retry with put
                    # print(f"Showing PUT Retry Response: {response.text}")

                # Check for non-success status codes
                # PUT often returns 200 (OK) or 204 (No Content) for successful updates
                if response.status_code not in [200, 204]:
                    raise ResponseException(response.text, response)

                return response
            except Exception as e:
                # Ensure 'response' is defined before trying to pass it
                raise ResponseException(str(e), response if 'response' in locals() else None)