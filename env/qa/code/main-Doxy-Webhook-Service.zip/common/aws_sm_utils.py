"""
Secret Manager Utilities Module

This module provides utilities for interacting with AWS Secret Manager.

Authors: BBehrens
Company: Porter Cares
Copyright: 2025
"""

import boto3
import json
from botocore.exceptions import ClientError

def get_secret_from_SM(name, region):
    if not name or not region:
        raise ValueError("Secret name and region are required")
        
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region
    )
    
    try:
        response = client.get_secret_value(SecretId=name)
        secret = response['SecretString']
        return json.loads(secret)
    except ClientError as e:
        error_code = e.response['Error']['Code']
        print(f"Failed to get secret. Error code: {error_code}")
        raise
    except json.JSONDecodeError as je:
        print(f"Invalid JSON format in secret: {je}")
        raise