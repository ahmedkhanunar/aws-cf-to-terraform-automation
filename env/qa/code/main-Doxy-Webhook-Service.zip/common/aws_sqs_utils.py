"""
SQS Utilities Module

This module provides utilities for interacting with AWS SQS queues.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

import boto3
import os
from typing import Optional

def write_exception_to_sqs(message: str) -> None:
    """
    Write an exception message to the configured SQS queue.

    Parameters
    ----------
    message : str
        The exception message to write to the queue

    Raises
    ------
    boto3.exceptions.Boto3Error
        If there's an error writing to the queue
    KeyError
        If SQS_EXCEPTION_URL environment variable is not set
    """
    sqs = boto3.client('sqs')
    url = os.environ['SQS_EXCEPTION_URL']
    
    write__to_sqs(url, sqs)
    
def write__to_sqs(region_name: str, sqs_url: str, message: str) -> None:
    """
    Write a message to the passed in SQS queue.

    Parameters
    ----------
    sqs_url : str
        the url of the specific queue to write to
    message : str
        The exception message to write to the queue

    Raises
    ------
    boto3.exceptions.Boto3Error
        If there's an error writing to the queue
    KeyError
        If SQS_URL environment is incorrect
    """
    sqs = boto3.client('sqs', region_name=region_name)
    url = sqs_url
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
