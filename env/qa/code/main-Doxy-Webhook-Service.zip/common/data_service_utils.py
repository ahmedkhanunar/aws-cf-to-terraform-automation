import boto3
from botocore.exceptions import ClientError
from typing import Dict, List, Any, Optional, BinaryIO, Union, Type, TypeVar, Generic
import json
from dataclasses import dataclass, asdict
from pathlib import Path
import mimetypes
## Add Local Imports Here
# TO_DO: Add BaseSubModule to the repo and import here
from common.aws_dynamo_utils import DynamoUtils

T = TypeVar('T')


@dataclass
class Provider:
    provider_name: str
    athena_provider_id: int
    sf_provider_id: str
    
@dataclass
class Department:
    client: str
    athena_department_id: int
    sf_payer_id: str

@dataclass
class AppointmentType:
    athena_appointment_type_id: int
    athena_appointment_type_name: str
    type_name: str
    
@dataclass
class AppointmentReason:
    athena_appointment_reason_id: 2
    athena_appointment_reason_name: str
    reason_name: str

@dataclass
class DataResponse(Generic[T]):
    success: bool
    data: Optional[List[T]] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None

@dataclass
class ServiceOptions:
    partition_key: str
    partition_key_value: str
    sort_key: str
    sort_key_value: str
    identity_key: str

class DataService(Generic[T]):
    def __init__(self, dyn_db: DynamoUtils, options: ServiceOptions, data_class: Type[T]):
        self.dyn_db = dyn_db
        self.options = options
        self.data_class = data_class
        self._get_list_from_source()
        
    def _put_list_to_source(self): 
        self._record['data'] = json.dumps([asdict(o) for o in self.item_list])
        response = self.dyn_db.put_item(self._record)
        return response
    
    def _get_list_from_source(self):
        response = self.dyn_db.get_item(
            self.options.partition_key,
            self.options.partition_key_value,
            self.options.sort_key,
            self.options.sort_key_value
        )

        if not response.success:
            if response.error_code == 'ItemNotFound':
                self._record = {
                    self.options.partition_key: self.options.partition_key_value,
                    self.options.sort_key: self.options.sort_key_value
                }
                self.item_list = []
            else:
                raise ValueError(f'{response.error_code} - {response.error_message}')
        
        else:
            self._record = response.data
            self.item_list = self.parse_list_to(json.loads(response.data['data']))
    
    def get_list(self):
        return self.item_list
    
    def get_list_count(self):
        return len(self.item_list)
    
    def find(self, item: T) -> DataResponse:
        # This is where we will verify the provider is not in the list and add them
        for i in self.item_list:
            if getattr(i, self.options.identity_key) == getattr(item, self.options.identity_key):
                return DataResponse(
                    success=True,
                    data=i
                )

        return DataResponse(
            success=False,
            data=item,
            error_code='NOTFOUND_ERR',
            error_message='Item was not found'
        )
    
    def add(self, item: T, call_save: bool = False) -> DataResponse:
        # This is where we will verify the provider is not in the list and add them
        for i in self.item_list:
            if getattr(i, self.options.identity_key) == getattr(item, self.options.identity_key):
                return DataResponse(
                    success=False,
                    data=item,
                    error_code='DUP_ERR',
                    error_message='Item is already created')
    
        self.item_list.append(item)
        
        if call_save:
            self._put_list_to_source()    
            
        return DataResponse(success=True,
                                data=item)
    
    def add_items(self, items: List[T], call_save: bool = False) -> List[DataResponse]:
        list = []
        
        for i in items:        
            response = self.add(i)
            list.append(response)
            
        if call_save:
            self._put_list_to_source()
        
        return list
            
    def remove(self, item: T, call_save: bool = False) -> DataResponse:
        # This is where we will find and remove the provider based on the sf id
        for i in self.item_list:
            if getattr(i, self.options.identity_key) == getattr(item, self.options.identity_key):
                self.item_list.remove(i)
                return DataResponse(success=True,
                                        data=item)
        
        if call_save:
            self._put_list_to_source()
            
        return DataResponse(success=False,
                                data=item,
                                error_code='NOTFOUND_ERR',
                                error_message='Item was not found')

    def remove_items(self, items: List[T], call_save: bool = False) -> List[DataResponse]:
        # This is where we will process a list of items to remove
        list = []
        
        for i in items:        
            response = self.remove(i)
            list.append(response)
            
        if call_save:
            self._put_list_to_source()
        
        return list
    
    def update(self, item: T, call_save: bool = False) -> DataResponse:
        # This is where we will find and remove the item based on the identifier value
        for idx, i in enumerate(self.item_list):
            if getattr(i, self.options.identity_key) == getattr(item, self.options.identity_key):
                self.item_list[idx] = item
                return DataResponse(success=True,
                                        data=item)
        
        if call_save:
            self._put_list_to_source()
            
        return DataResponse(success=False,
                                data=item,
                                error_code='NOTFOUND_ERR',
                                error_message='Item was not found')

    def update_items(self, items: List[T], call_save: bool = False) -> List[DataResponse]:
        # This is where we will process a list of providers to remove
        list = []
        
        for i in items:        
            response = self.update(i)
            list.append(response)
            
        if call_save:
            self._put_list_to_source()
        
        return list

    def parse_dict_to(self, item: Any) -> T:
        """
        Parse dict to a Provider class
        
        Args:
            item (dict): Item to convert into Provider
        Returns:
            Provider: Object structure
        """
        return self.data_class(**item)
        
    def parse_list_to(self, data: Any) -> list[T]:
        """
        Parse list of dict to a List of Provider classes
        
        Args:
            data list[dict]: list of items to convert
            
        Returns:
            List[Provider]: List of Provider classes
        """
        list = []
        
        for d in data:
            list.append(self.parse_dict_to(d))     
        return list
