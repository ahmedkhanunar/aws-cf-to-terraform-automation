"""
Debug Utilities Module

This module provides debugging utilities for development and troubleshooting.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

import os
from typing import Any

def debug_print(*args: Any, **kwargs: Any) -> None:
    """
    Print debug messages when DEBUG environment variable is set to 'true'.

    Parameters
    ----------
    *args : Any
        Variable length argument list to print
    **kwargs : Any
        Arbitrary keyword arguments passed to print function

    Examples
    --------
    >>> debug_print("Processing request:", request_id)
    >>> debug_print("Error occurred", error=True)
    """
    if os.getenv('DEBUG', 'true').lower() == 'true':
        print(*args, **kwargs) 
        