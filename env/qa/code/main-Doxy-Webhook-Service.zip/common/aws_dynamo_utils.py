"""
Dynamo DB Utilities Module

This module provides utilities for interacting with AWS Dynamo DB.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

import boto3
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError
from dataclasses import dataclass

@dataclass
class DynamoResponse:
    success: bool
    data: Optional[Dict[str, Any]] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    
    def __bool__(self):
        return self.success

class DynamoUtils:
    def __init__(self, table_name: str, region_name: str):
        self.dynamodb = boto3.resource('dynamodb', region_name=region_name)
        self.table = self.dynamodb.Table(table_name)
        
    def put_item(self, item: Dict[str, Any]) -> DynamoResponse:
        """
        Put an item into DynamoDB table
        
        Args:
            item (dict): Item to store in DynamoDB
            
        Returns:
            DynamoResponse: Object containing success status and error details if any
        """
        try:
            self.table.put_item(Item=item)
            return DynamoResponse(
                success=True,
                data=item
            )
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'ConditionalCheckFailedException':
                error_message = 'Item already exists with the same key'
            elif error_code == 'ProvisionedThroughputExceededException':
                error_message = 'DynamoDB table capacity exceeded'
            elif error_code == 'ResourceNotFoundException':
                error_message = f'Table {self.table.name} not found'
            
            return DynamoResponse(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return DynamoResponse(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
        
    def get_item(self, 
                 partition_key: str, 
                 partition_key_value: str,
                 sort_key: Optional[str] = None,
                 sort_key_value: Optional[str] = None) -> DynamoResponse:
        """
        Get an item from DynamoDB table using partition key and optional sort key
        
        Args:
            partition_key: Name of the partition key
            partition_key_value: Value of the partition key
            sort_key: Optional name of the sort key
            sort_key_value: Optional value of the sort key
            
        Returns:
            DynamoResponse: Object containing success status, item data if found, 
                          and error details if any
        """
        try:
            key = {partition_key: partition_key_value}
            if sort_key and sort_key_value:
                key[sort_key] = sort_key_value
            
            response = self.table.get_item(Key=key)
            item = response.get('Item')
            
            if item:
                return DynamoResponse(
                    success=True,
                    data=item
                )
            else:
                error_msg = (f"No item found with {partition_key}={partition_key_value}"
                           f"{f' and {sort_key}={sort_key_value}' if sort_key else ''}")
                return DynamoResponse(
                    success=False,
                    error_code='ItemNotFound',
                    error_message=error_msg
                )
                
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'ResourceNotFoundException':
                error_message = f'Table {self.table.name} not found'
            
            return DynamoResponse(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return DynamoResponse(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
        
    def update_item(self, key: Dict[str, str], update_attrs: Dict[str, Any]) -> DynamoResponse:
        """
        Update an item in DynamoDB table
        
        Args:
            key (dict): Primary key of the item to update
            update_attrs (dict): Attributes to update
            
        Returns:
            DynamoResponse: Object containing success status and error details if any
        """
        try:
            update_expression = "SET "
            expression_values = {}
            
            for attr, value in update_attrs.items():
                update_expression += f"#{attr} = :{attr}, "
                expression_values[f"{attr}"] = value
                
            # Remove trailing comma and space
            update_expression = update_expression[:-2]
            
            expression_names = {f"#{k}": k for k in update_attrs.keys()}
            
            response = self.table.update_item(
                Key=key,
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expression_names,
                ExpressionAttributeValues=expression_values,
                ReturnValues='ALL_NEW'
            )
            
            return DynamoResponse(
                success=True,
                data=response.get('Attributes', {})
            )
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'ConditionalCheckFailedException':
                error_message = f'Item with key {key} does not exist'
            elif error_code == 'ResourceNotFoundException':
                error_message = f'Table {self.table.name} not found'
            
            return DynamoResponse(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return DynamoResponse(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
        
    def delete_item(self, key: Dict[str, str]) -> DynamoResponse:
        """
        Delete an item from DynamoDB table
        
        Args:
            key (dict): Primary key of the the item to delete
            
        Returns:
            DynamoResponse: Object containing success status and error details if any
        """
        try:
            response = self.table.delete_item(
                Key=key,
                ReturnValues='ALL_OLD'
            )
            
            deleted_item = response.get('Attributes')
            if deleted_item:
                return DynamoResponse(
                    success=True,
                    data=deleted_item
                )
            else:
                return DynamoResponse(
                    success=False,
                    error_code='ItemNotFound',
                    error_message=f'No item found with key: {key}'
                )
                
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'ResourceNotFoundException':
                error_message = f'Table {self.table.name} not found'
                
            return DynamoResponse(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return DynamoResponse(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
