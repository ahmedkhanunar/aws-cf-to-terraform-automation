import os
import json
from common.aws_dynamo_utils import DynamoUtils, DynamoResponse

MN_DEPARTMENT = 'mn-departments-map'
MN_PROVIDER = 'mn-providers-map'
MN_REASON = 'mn-reasons-map'
MN_TYPE = 'mn-types-map'

print(os.getenv('DDB_MAPPING'), os.getenv('AWS_REGION'))

dyn_db = DynamoUtils(os.getenv('DDB_MAPPING'), os.getenv('AWS_REGION'))

print('uuid', os.getenv('DDB_PK'), 'mapName', MN_DEPARTMENT)

response = dyn_db.get_item('uuid', os.getenv('DDB_PK'), 'mapName', MN_DEPARTMENT)

print(response)
if response.success:
    department_map = json.loads(response.data['data'])
    
response = dyn_db.get_item('uuid', os.getenv('DDB_PK'), 'mapName', MN_PROVIDER)

if response.success:
    provider_map = json.loads(response.data['data'])

response = dyn_db.get_item('uuid', os.getenv('DDB_PK'), 'mapName', MN_REASON)

if response.success:
    appointment_reason_map = json.loads(response.data['data'])

response = dyn_db.get_item('uuid', os.getenv('DDB_PK'), 'mapName', MN_TYPE)

if response.success:
    appointment_type_map = json.loads(response.data['data'])

#Prod Nurse Visit 101 Preview 60

def map_department_by_sf(sfid):
	print('AthenaAppointment - [DepartmentValue]: ', sfid)
	for department in department_map:
		if department['sf_payer_id'] == sfid:
			print('AthenaAppointment - [DepartmentId]: ', department)
			return department
		
	return "{status: Error, code: ERR01, message: Department Match Error, value: " + sfid + "}"

def map_provider_by_sf(sfid):
	print('AthenaAppointment - [ProviderValue]: ', sfid)
	for provider in provider_map:
		if provider['sf_provider_id'] == sfid:
			return provider
		
	raise ValueError(f"Provider mapping not found for SF ID: {sfid}")

def map_appointment_type_by_sf(sfid):
	print('AthenaAppointment - [AppointmentType]: ', sfid)
	type_name = 'PLACEHOLDER'
	is_telehealth = False
	if sfid.startswith('Tele'):
		print('AthenaAppointment - [AppointmentType:tele]')
		type_name = 'telehealth'
		is_telehealth = True
	elif sfid.startswith('Health'):
		print('AthenaAppointment - [AppointmentType:healthFair]')
		type_name = 'health_fair'
	elif sfid.endswith('Int 3'):        
		print('AthenaAppointment - [AppointmentType:nurseVisit]')
		type_name = 'nurse_visit'
	elif sfid.endswith('Int 5'):
		print('AthenaAppointment - [AppointmentReason:diagVisit]')
		type_name = 'np_diag_visit'
	else:
		print('AthenaAppointment - [AppointmentType:inhome]')
		type_name = 'hra_in_home'

	for appointment_type in appointment_type_map:
		if appointment_type['type_name'] == type_name:
			print('AthenaAppointment - [AppointmentType]: ', appointment_type)
			return appointment_type['athena_appointment_type_id'], is_telehealth

	return "{status: Error, code: ERR02, message: Appointment Type Error, value: " + sfid + "}"

def map_appointment_reason_by_sf(sfid):
	print('AthenaAppointment - [AppointmentReason]: ', sfid)
	reason_name = 'PLACEHOLDER'
	if sfid.startswith('Tele'):
		print('AthenaAppointment - [AppointmentReason:tele]')
		reason_name = 'telehealth'
	elif sfid.startswith('Health'):
		print('AthenaAppointment - [AppointmentReason:healthFair]')
		reason_name = 'follow_up'
	elif sfid.endswith('Int 3'):
		print('AthenaAppointment - [AppointmentReason:nurseVisit]')
		reason_name = 'lab_work'
	elif sfid.endswith('Int 5'):
		print('AthenaAppointment - [AppointmentReason:diagVisit]')
		reason_name = 'np_diag_visit'
	else:
		print('AthenaAppointment - [AppointmentReason:inhome]')
		reason_name = 'new_patient'
  
	for appointment_reason in appointment_reason_map:
		if appointment_reason['reason_name'] == reason_name:
			print('AthenaAppointment - [AppointmentReason]: ', appointment_reason)
			return appointment_reason['athena_appointment_reason_id']

	return "{status: Error, code: ERR03, message: Appointment Reason Error, value: " + sfid + "}"


if __name__ == "__main__":
    
    def run_tests():
        type_name = 'In-Home Visit - Int 3'
        
        response = map_appointment_type_by_sf(type_name)
        print('response: ', response)
        
    
    run_tests()