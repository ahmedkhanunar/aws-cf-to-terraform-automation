import json
import sys
import os
import boto3
import traceback
from mappings_lib.mappings import *
from datetime import datetime
from botocore.exceptions import ClientError
from athena_lib.core.athena_api_service import APIConnection
from athena_lib.appointment_service import AthenaAppointment, AthenaAppointmentService, ProcessType
from salesforce_lib.serviceappointment.serviceappointment_service import SalesforceAppointmentService, SFConnection, GrantType
from common.aws_sm_utils import get_secret_from_SM

def lambda_handler(event, context):
    try:
        print('AthenaAppointment - [event]:', event)

        #HERE IS WHERE WE NEED TO INSTANCIATE THE ATHENA AND SALESFORCE SERVICES
        athenaService = get_AthenaAppointmentService()
        sfService = get_SFAppointmentService()

        for record in event['Records']:
            print('AthenaAppointment - [SQS Message]:', record)

            message = record['body'].encode().decode("utf-8") 
            print('AthenaAppointment - [sqs data]:', message )

            process_message(athenaService, sfService, message)

        return {
            'statusCode': 200,
            'body': json.dumps('Success')
        }
    except Exception as e:
        exec_info = sys.exc_info()
        ex = ''.join(traceback.format_exception(*exec_info))
        print(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))


def process_message(service, sf_service, raw_message):
    try:
        messages = json.loads(raw_message)
        
        if not isinstance(messages, list):
            raise ValueError("Expected messages to be a list format")

        for message in messages:
            print('AthenaAppointment - [process message]: ', json.dumps(message))
            try:
                athena_appointment = load_athenaappointment(message)
                process_type = athena_appointment.check_process_type()
                print(f'AthenaAppointment - [{athena_appointment.appointmentNumber}] - Process_type: ', process_type)
                
                if process_type == ProcessType.CANCEL:
                    print('BRB: CANCEL')
                    appointment = process_cancel(service, athena_appointment)
                    appointment = update_service_appointment(sf_service, appointment)
                elif process_type == ProcessType.CREATE:
                    print(f'AthenaAppointment - [{athena_appointment.appointmentNumber}]: CREATE')
                    appointment = process_create(service, athena_appointment)
                    update_service_appointment(sf_service, appointment)
                elif process_type == ProcessType.RESCHEDULE:
                    print(f'AthenaAppointment - [{athena_appointment.appointmentNumber}]: RESCHEDULE')
                    reschedule_response = process_reschedule(service, athena_appointment)
                    if not reschedule_response['is_duplicate']:
                        update_service_appointment(sf_service, reschedule_response['appointment'])
                else:
                    print(f'AthenaAppointment - [{athena_appointment.appointmentNumber}]: PASSTHROUGH')
                    
            except KeyError as ke:
                print(f"Missing required field in message: {ke}")
                raise
            except Exception as e:
                print(f"Error processing message: {str(e)}")
                raise
                
    except json.JSONDecodeError as je:
        print(f"Invalid JSON format in raw_message: {je}")
        raise
    except Exception as e:
        print(f"Error in process_message: {str(e)}")
        raise

#--------------
#CANCEL
def cancel(service, existing_appointment):
    print('into cancel')
    service.put_appointment_cancel(existing_appointment.athenaAppointmentId, existing_appointment.segment_put_appointment_cancel())
    existing_appointment.set_athenaappointmentid('')
    existing_appointment.set_appointment_telehealth_link('')
    return existing_appointment

#CANCEL PROCESS
def process_cancel(service, appointment):
    print(f'AthenaAppointment - [{appointment.appointmentNumber}] - process_cancel')
    #GET EXISTING APPOINTMENT
    existing_appointment = service.get_appointment_detail(appointment.athenaAppointmentId)

    print(f'AthenaAppointment - [{appointment.appointmentNumber}] - [existing_appointment]: ', existing_appointment)
    if isinstance(existing_appointment, list):
        print(f'AthenaAppointment - [{appointment.appointmentNumber}] - [valid appointment to cancel]')
        #SETUP MAPPED VALUES
        department_map = map_department_by_sf(appointment.payer)
        appointment.set_department_id(department_map['athena_department_id'])
        print('here')
        print(existing_appointment[0]['providerid'])
        print(existing_appointment[0]['date'])
        appointment.set_provider_id(existing_appointment[0]['providerid'])
        appointment.set_start_date(existing_appointment[0]['date'])

        appointment = cancel(service, appointment)
        print('Athena Appointment ID: ', appointment.athenaAppointmentId)
        print('Athena Telehealth Link: ', appointment.athenaAppointmentTelehealthLink)
        
        return appointment

#--------------
#CREATE
def create(service, appointment):
    print(f'AthenaAppointment - [{appointment.appointmentNumber}] - process_create')        
    #CREATE SLOT
    post_payload = appointment.segment_post_appointment_slot()
    appointment_slot = service.post_appointment_slot(post_payload)
    #SET APPOOINTMENT ID
    appointment_slot = appointment_slot['appointmentids'].keys()            
    appointment.set_athenaappointmentid(list(appointment_slot)[0])
    #FILL APPOINTMENT
    service.put_appointment_slot(list(appointment_slot)[0], appointment.segment_put_appointment_slot())
    return appointment

#CREATE PROCESS
def process_create(service, appointment):
    print(f'AthenaAppointment - [{appointment.appointmentNumber}] - process_create')
    department_map = map_department_by_sf(appointment.payer)
    appointment.set_department_id(department_map['athena_department_id'])
    print(appointment.providerId)
    provider_map = map_provider_by_sf(appointment.providerId)
    print(provider_map)   
    
    if isinstance(provider_map, dict):
        appointment.set_provider_id(provider_map['athena_provider_id'])
    else:
        raise ValueError(f"Provider mapping not found for ID: {appointment.providerId}")
    
    appointment_type, is_telehealth = map_appointment_type_by_sf(appointment.workType)
    
    appointment.set_appointment_is_telehealth(is_telehealth)
    appointment.set_appointment_type_id(appointment_type)
    appointment.set_appointment_reason_id(map_appointment_reason_by_sf(appointment.workType))

    existing_appointment = service.get_appointments_booked(appointment.segment_get_appointments_booked())
    is_duplicate = False

    for ea in existing_appointment['appointments']:
        is_duplicate = appointment.check_isDuplicate(ea)
        print(f'AthenaAppointment - [{appointment.appointmentNumber}] - is_duplicate: ', is_duplicate)
        if is_duplicate:
            appointment.set_athenaappointmentid(ea['appointmentid'])
            print(f'AthenaAppointment - [{appointment.appointmentNumber}] - athenaAppointmentId: ', appointment.athenaAppointmentId)
            break
    
    if not is_duplicate:
        appointment = create(service, appointment)

    return appointment

#--------------
#RESCHEDULE
def process_reschedule(service,appointment):
    print(f'AthenaAppointment - [{appointment.appointmentNumber}] - process_reschedule')
    department_map = map_department_by_sf(appointment.payer)
    appointment.set_department_id(department_map['athena_department_id'])
    print(appointment.providerId)
    provider_map = map_provider_by_sf(appointment.providerId)
    print(provider_map)   
    
    if isinstance(provider_map, dict):
        appointment.set_provider_id(provider_map['athena_provider_id'])
    else:
        raise ValueError(f"Provider mapping not found for ID: {appointment.providerId}")
    
    #GET EXISTING APPOINTMENT
    existing_appointment = service.get_appointment_detail(appointment.athenaAppointmentId)
    is_duplicate = False
    if isinstance(existing_appointment, list):
        print(f'AthenaAppointment - [{appointment.appointmentNumber}] - [existing_appointment]: ', existing_appointment)
        if existing_appointment[0]['appointmentstatus'] == 'x':
            appointment.set_athenaappointmentid('')
        
        is_duplicate = appointment.check_isDuplicate(existing_appointment[0])
        print(f'AthenaAppointment - [{appointment.appointmentNumber}] - is_duplicate: ', is_duplicate)
        if not is_duplicate:
            cancel(service, appointment)          
    else:
        print(f'AthenaAppointment - [{appointment.appointmentNumber}] - message: did not find the athena appointment id')
        appointment.set_athenaappointmentid('')
        
    appointment = process_create(service, appointment)

    return {'is_duplicate': is_duplicate, 'appointment': appointment}

#CLEAN APPOINTMENT FROM ATHENA
def clean_appointments_open(service, appointment):
    print(appointment)
    open_response = service.get_appointments_open(appointment.segment_get_appointments_open())
    for app in open_response['appointments']:
        service.delete_appointment_slot(app['appointmentid'])

#UPDATE SF
def update_service_appointment(service, appointment):
    print('Into Patch')
    service.patch_serviceappointment(appointment)

#LOAD APPOINTMENT
def load_athenaappointment(message):
    required_fields = [
        'status', 'startDateTime', 'providerNPI', 'providerId',
        'patientLastName', 'patientFirstName', 'patientDOB',
        'serviceTerritoryTimeZone', 'payer', 'athenaPatientId',
        'athenaAppointmentId', 'appointmentId', 'appointmentNumber',
        'workType'
    ]
    
    missing_fields = [field for field in required_fields if field not in message]
    if missing_fields:
        raise KeyError(f"Missing required fields: {', '.join(missing_fields)}")
        
    return AthenaAppointment(message['status'],
                           message['startDateTime'],
                           message['providerNPI'],
                           message['providerId'],
                           message['patientLastName'],
                           message['patientFirstName'],
                           message['patientDOB'],
                           message['serviceTerritoryTimeZone'],
                           message['payer'],
                           message['athenaPatientId'],
                           message['athenaAppointmentId'],
                           message['appointmentId'],
                           message['appointmentNumber'],
                           message['workType'])

#LOAD SERVICES
def get_AthenaAppointmentService():
    required_vars = {
        "ATHENA_VERSION": os.getenv("ATHENA_VERSION"),
        "ATHENA_CLIENTID": os.getenv("ATHENA_CLIENTID"),
        "ATHENA_CLIENTSECRET": os.getenv("ATHENA_CLIENTSECRET"),
        "ATHENA_PRACTICEID": os.getenv("ATHENA_PRACTICEID")
    }
    
    missing_vars = [var for var, value in required_vars.items() if not value]
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    test = os.getenv('ATHENA_TEST', 'false').lower() == 'true'
    api = APIConnection(
        required_vars["ATHENA_VERSION"],
        required_vars["ATHENA_CLIENTID"],
        required_vars["ATHENA_CLIENTSECRET"],
        required_vars["ATHENA_PRACTICEID"],
        test
    )
    return AthenaAppointmentService(api)

def get_SFAppointmentService():
    required_vars = {
        "SF_SECRET": os.getenv('SF_SECRET'),
        "SF_REGION": os.getenv('SF_REGION'),
        "SF_HOST": os.getenv('SF_HOST')
    }
    print(required_vars)
    missing_vars = [var for var, value in required_vars.items() if not value]
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
        
    secret = get_secret_from_SM(required_vars["SF_SECRET"], required_vars["SF_REGION"])
    print(secret)
    user = os.getenv('SF_USER')  # Optional parameter
    
    grant_type = GrantType.BEARER if required_vars["SF_SECRET"] != '' else GrantType.PASSWORD
    api = SFConnection(secret, grant_type)
    return SalesforceAppointmentService(api)

###


if __name__ == "__main__":

    sfService = get_SFAppointmentService()
    athenaService = get_AthenaAppointmentService()

    test_message = '''[
                        {
                            "workType": "In-Home Visit - Int 4",
                            "status": "Scheduled",
                            "startDateTime": "2025-02-07T13:00:00.000Z",
                            "serviceTerritoryTimeZone": "America/New_York",
                            "providerNPI": null,
                            "providerId": "0HnO30000005NjxKAE",
                            "payer": "Carefirst",
                            "patientLastName": "Bally",
                            "patientFirstName": "Dupla",
                            "patientDOB": "2007-10-11",
                            "lastModifiedBy": "Brian Behrens",
                            "athenaPatientId": "90641",
                            "athenaAppointmentId": "99999",
                            "appointmentNumber": "SA-3733",
                            "appointmentId": "08pO3000001B8svIAC"
                        }
                        ]'''
    
    process_message(athenaService, sfService, test_message)