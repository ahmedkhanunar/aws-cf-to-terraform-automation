from dataclasses import asdict
import os
from common.debug_utils import debug_print
from common.aws_dynamo_utils import DynamoUtils
from common.data_service_utils import DataService, ServiceOptions, Provider

import json

def is_valid_mapping(event_body):
    if not isinstance(event_body, list):
        return False
    for item in event_body:
        if not isinstance(item, dict):
            return False
        # Check for required keys
        if set(item.keys()) != {"provider_name", "athena_provider_id", "sf_provider_id"}:
            return False
        if not isinstance(item["provider_name"], str):
            return False
        if not isinstance(item["athena_provider_id"], int):
            return False
        if not isinstance(item["sf_provider_id"], str):
            return False
    return True


def lambda_handler(event, context):
    """
    AWS Lambda function to save provider data.

    Parameters:
    event (dict): The event data passed to the Lambda function.
    context (object): The context in which the Lambda function is called.

    Returns:
    dict: A response object with status code and body message.
    """
    # Your code here

    debug_print("Starting provider_save_lambda")
    debug_print(f"Event: {event}")

    try:
        # Get data
        body = json.loads(event.get('body', '{}'))
        debug_print(f"Body: {body}")
    except json.JSONDecodeError as e:
        debug_print(f"JSON decode error: {e}")
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid JSON in request body'),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
    if not body:
        debug_print("No body found in the event")
        return {
            'statusCode': 400,
            'body': json.dumps('No data provided')
        }
    
    try:
        debug_print("Processing provider data")
        # Simulate processing the provider data
        if (is_valid_mapping(body)):
            debug_print("Valid mapping found")
        else:
            debug_print("Invalid mapping")
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid mapping data provided'),
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Allow': 'POST',
                    'Access-Control-Allow-Methods': '*',
                    'Access-Control-Allow-Headers': '*'
                }
            }
        debug_print("calling process_call")
        result = process_call(body)
        debug_print(f"Process call result: {result}")

        response_body = json.dumps([asdict(r) for r in result])

        return {
            'statusCode': 200,
            'body': response_body,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
    except Exception as e:
        debug_print(f"Error processing provider data: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing data'),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
    except Exception as e:
        debug_print(f"Error processing provider data: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing data'),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'POST',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }


def process_call(data):
    debug_print(f"Processing data: {data}")
    # Simulate some processing
    try:
        """
        THIS IS FOR HANDLING PROVIDER RECORDS
        """
        
        provider_options = ServiceOptions('uuid', 'f517062b-98e1-4033-b814-5ca91bcd4185',
                                'mapName', 'mn-providers-map',
                                'sf_provider_id')

        dyn_db = DynamoUtils(os.getenv('DDB_MAPPING'), os.getenv('SF_REGION'))

        # Setup ScheduleProviderService
        provider_service = DataService(dyn_db=dyn_db, options=provider_options, data_class=Provider)
        
        providers = data
        debug_print(f"Providers to process: {providers}")
        
        providers = provider_service.parse_list_to(providers)
        result = provider_service.add_items(items=providers, call_save=True)

        response = result
        debug_print(f"Processed result: {response}")
        return response
    
    except Exception as e:
        debug_print(f"Error getting mapping service: {e}")
        return {"status": "error", "message": str(e)}
