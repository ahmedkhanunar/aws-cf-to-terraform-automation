import boto3
import os

def write_exception_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )
