import os
import json
from doxyme_lib.doxy_webhook_service import DoxyWebhookService
from common.aws_sm_utils import get_secret_from_SM
from salesforce_lib.core.sf_api_service import SFConnection, GrantType


def lambda_handler(event, context):
    secret = os.environ.get('DOXYME_SECRET')
    print(f"EVENT {json.dumps(event)}")

    default_headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST, PUT',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

    if 'Records' in event:
        for record in event.get('Records', []):
            try:
                print("Inside Try")

                # SQS body is always a string
                event_body_str = record.get('body', '{}')
                event_body = json.loads(event_body_str)
                
                # check-ins send pid as a single string, need to move it to pidList for what sf expects
                if event_body.get('pid'):
                    event_body['pidList'] = [event_body['pid']]

                # Message attributes
                message_attributes = record.get('messageAttributes', {})
                http_method = message_attributes.get('HttpMethod', {}).get('stringValue')
                secret_key = message_attributes.get('SecretKey', {}).get('stringValue')

                print(f"Received webhook body: {event_body}")

                # Validate secret key
                if secret_key != secret:
                    print("Forbidden: Invalid secret key")
                    return {'statusCode': 403, 'body': 'Forbidden', 'headers': default_headers}

                # Add secret key into body
                event_body["secret-key"] = secret_key

                print("Before Service")
                service = get_DoxyWebhookService()
                print("Service initialized")
                response = service.process_payload(event_body, http_method)

                print("Response------------", json.dumps(response, indent=2))
                return {
                    'statusCode': 200,
                    'body': json.dumps(response),
                    'headers': default_headers
                }

            except json.JSONDecodeError:
                print("Invalid JSON payload.")
                return {'statusCode': 400, 'body': 'Invalid JSON payload', 'headers': default_headers}

            except ValueError as ve:
                print(f"Value error: {str(ve)}")
                return {'statusCode': 400, 'body': str(ve), 'headers': default_headers}

            except Exception as e:
                print(f"Unexpected error: {e}")
                return {
                    'statusCode': 500,
                    'body': f'Internal Server Error: {str(e)}',
                    'headers': default_headers
                }


def get_DoxyWebhookService():
    required_vars = {
        "SF_SECRET": os.getenv('SF_SECRET'),
        "SF_REGION": os.getenv('SF_REGION'),
        "SF_HOST": os.getenv('SF_HOST')
    }
    print(required_vars)

    missing_vars = [var for var, value in required_vars.items() if not value]
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")

    # Fetch Salesforce secret from AWS SM
    secret = get_secret_from_SM(required_vars["SF_SECRET"], required_vars["SF_REGION"])
    print(secret)

    user = os.getenv('SF_USER')  # Optional parameter

    # Decide grant type
    grant_type = GrantType.BEARER if required_vars["SF_SECRET"] != '' else GrantType.PASSWORD

    api = SFConnection(secret, grant_type)
    return DoxyWebhookService(api)
