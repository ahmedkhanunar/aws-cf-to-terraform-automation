import json
import logging
from salesforce_lib.core.sf_api_service import SFConnection, GrantType


class DoxyWebhookService:
    def __init__(self, api):
        self.logger = logging.getLogger(__name__)
        self.api = api

    def process_payload(self, payload: dict, method: str) -> dict:
        try:
            self.logger.info(f"Processed data to send: {payload}, method: {method}")
            path = "/services/apexrest/doxyme/webhook/v1"
            response = getattr(self.api, method)(
                path=path,
                parameters=json.dumps(payload),
                headers={'secret-key': payload.get("secret-key")}
            )
            return {
                "statusCode": response.status_code,
                "body": response.text
            }
        except Exception as e:
            self.logger.error(f"Failed to process payload: {e}", exc_info=True)
            return {
                "statusCode": 500,
                "body": json.dumps({"error": str(e)})
            }
