from datetime import datetime
from dateutil import tz
from athena_lib.core.athena_api_service import *
from enum import Enum


class ProcessType(Enum):
    CREATE = 1
    RESCHEDULE = 2
    CANCEL = 3
    PASSTHROUGH = 4


class AthenaAppointment:
    def __init__(self, 
                status=None,
                startDateTime=None,
                providerNPI=None,
                providerId=None,
                patientLastName=None,
                patientFirstName=None,
                patientDOB=None,
                timeZone=None,
                payer=None,
                athenaPatientId=None,
                athenaAppointmentId=None,
                appointmentId=None,
                appointmentNumber=None,
                workType=None):        
        self.status = status
        self.startDateTime = startDateTime
        self.providerNPI = providerNPI
        self.providerId = providerId
        self.patientLastName = patientLastName
        self.patientFirstName = patientFirstName
        self.patientDOB = patientDOB
        self.timeZone = timeZone
        self.payer = payer
        self.athenaPatientId = athenaPatientId
        self.athenaAppointmentId = athenaAppointmentId
        self.appointmentNumber = appointmentNumber
        self.appointmentId = appointmentId
        self.workType = workType
        self.athenaAppointmentTelehealthLink = None

        #Convert String to datetime and apply timezone to value
        if (self.startDateTime != None):
            start_Date = str.removesuffix(self.startDateTime, 'Z')
            start_Date = datetime.fromisoformat(start_Date)
            start_Date = start_Date.replace(tzinfo=tz.UTC)
            start_Date = start_Date.astimezone(tz.gettz(timeZone))

            self.startDate = start_Date.strftime('%m/%d/%Y')
            self.startTime = start_Date.strftime('%H:%M')

#LOGIC CHECKS
    def check_process_type(self):
        cancel_flags = ['Cannot Complete','None']
        if (self.status in cancel_flags):
        #This is the cancel path
            if (self.athenaAppointmentId != None):
                return ProcessType.CANCEL
            else:
                return ProcessType.PASSTHROUGH
        else:
            if (self.athenaAppointmentId == None):
                return ProcessType.CREATE
            else:
                return ProcessType.RESCHEDULE
            

    def check_isDuplicate(self, existing_appointment):        
        if (int(self.athenaProviderId) == int(existing_appointment['providerid'])
            and self.startDate == existing_appointment['date']
            and self.startTime == existing_appointment['starttime']
            and existing_appointment['appointmentstatus'] != 'x'
            ):
            return True
        else:
            return False

# PROPERTY SETTERS
    def set_department_id(self, departmentId):
        self.athenaDepartmentId = departmentId

    def set_provider_id(self, providerId):
        self.athenaProviderId = providerId

    def set_start_date(self, startDate):
        self.startDate = startDate

    def set_appointment_is_telehealth(self, is_telehealth):
        self.is_telehealth = is_telehealth
        
    def set_appointment_telehealth_link(self, link):
        self.athenaAppointmentTelehealthLink = link
        
    def set_appointment_type_id(self, appointmentTypeId):
        self.athenaAppointmentTypeId = appointmentTypeId

    def set_appointment_reason_id(self, appointmentReasonId):
        self.athenaAppointmentReasonId = appointmentReasonId

    def set_athenaappointmentid(self, athenaappointmentid):
        self.athenaAppointmentId = athenaappointmentid

# STRUCTURE SEGMENTS
    def segment_post_appointment_slot(self):
        return {
                    "departmentid": self.athenaDepartmentId,
                    "providerid": self.athenaProviderId,
                    "appointmenttypeid": self.athenaAppointmentTypeId,
                    "appointmenttime": self.startTime,
                    "appointmentdate": self.startDate
                }
    
    def segment_put_appointment_slot(self):
        return {
                    "reasonid": self.athenaAppointmentReasonId,  
                    "patientid": self.athenaPatientId, 
                    "departmentid": self.athenaDepartmentId,
                    "bookingnote": "Check Regular checkup",
                }

    def segment_put_appointment_cancel(self):
        return {
            "patientid": self.athenaPatientId,
            "appointmentcancelreasonid": "21",
            "cancellationreason": "Testing",
            "ignoreschedulablepermission": True
        }
    
    def segment_get_appointments_booked(self):
        return {
                    "departmentid" : self.athenaDepartmentId,
                    "providerid": self.athenaProviderId,
                    "patientid": self.athenaPatientId,
                    "startdate": self.startDate,
                    "enddate": self.startDate
                }
    
    def segment_get_appointments_open(self):
        return {
                "departmentid" : self.athenaDepartmentId,
                "providerid": self.athenaProviderId,
                "ignoreschedulablepermission": True,
                "startdate": self.startDate,
                "enddate": self.startDate
            }


class AthenaAppointmentService:

    def __init__(self, api):
        self.api = api

    def put_appointment_slot(self, appointmentId, payload):
        url = f'/appointments/{appointmentId}'
        appointment_slot = self.api.PUT(url, payload)
        return appointment_slot

    def put_appointment_cancel(self, appointmentId, payload):
        print('AppointmentId: ', appointmentId)
        print(payload)
        url = f'/appointments/{appointmentId}/cancel'
        returnVal = self.api.PUT(url, payload)
        return returnVal

    def delete_appointment_slot(self, appointmentId):
        url = f'/appointments/{appointmentId}'
        response = self.api.DELETE(url)
        return response

    def get_appointment_detail(self, appointmentId):
        url = f'/appointments/{appointmentId}'
        response = self.api.GET(url)
        return response
    
    def get_appointment_telehealth_link(self, appointmentId):
        url = f'/appointments/{appointmentId}/nativeathenatelehealthroom'
        response = self.api.GET(url)
        return response

    def get_appointments_open(self, payload):
        url = '/appointments/open'
        response = self.api.GET(url, payload)
        return response
    
    def post_appointment_slot(self, payload):
        url = '/appointments/open'
        appointment_slot = self.api.POST(url, payload)
        return appointment_slot
    
    def get_appointments_booked(self, payload):
        url = '/appointments/booked'
        response = self.api.GET(url, payload)
        return response
    
    def get_appointment_types(self, payload):
        url = '/appointmenttypes'
        response = self.api.GET(url, payload)
        return response
    
    def get_appointment_reasons(self, payload):
        url = '/patientappointmentreasons'
        response = self.api.GET(url, payload)
        return response
    
    def get_appointment_cancel_reasons(self, payload):
        url = '/appointmentcancelreasons'
        response = self.api.GET(url, payload)
        return response
    
    def get_departments(self, payload):
        url = '/departments'
        response = self.api.GET(url, payload)
        return response
    
    def get_providers(self, payload):
        url = '/providers'
        response = self.api.GET(url, payload)
        return response


