from datetime import datetime
from dateutil import tz
from athena_lib.core.athena_api_service import *
from enum import Enum

class AthenaPatientService:

    def __init__(self, api):
        self.api = api

    def post_patient(self, payload):
        url = '/patients'
        patient = self.api.POST(url, payload)
        return patient