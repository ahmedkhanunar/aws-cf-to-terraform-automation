import json
import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime
import os
import jwt
dynamodb = boto3.resource("dynamodb")
headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*'
    }

def lambda_handler(event, context):
    print("hello im in here")

    body = json.loads(event.get('body'))
    user_id = body['clientMemberId'] or ""
    firstName = body["firstName"] or ""
    lastName = body["lastName"] or ""
    dateOfBirth = datetime.strptime((body["dob"] or ""), '%Y-%m-%d').date()
    dob = f'{dateOfBirth}'

    if user_id == "":
        return failure_response(300,'No member found.','E001')
      
    uuid, logmsg = get_member_uuid(user_id)

    print("---------", uuid)

    if uuid is None or uuid == '':
        print("2nd uuid indide if stetement ", uuid)
        return failure_response(300,'No member found.', f'E002 : message:{logmsg}')    
    member_table = dynamodb.Table(os.environ['MemberDetailsTable'])
    response = member_table.query(KeyConditionExpression=Key('uuid').eq(uuid))

    #    response = member_table.query(IndexName='ClientMemberId-index', KeyConditionExpression=Key('ClientMemberID').eq(user_id))

    if len(response["Items"]) > 1 or len(response["Items"]) == 0:
        return failure_response(300,'No member found.', f'E003 : message:{logmsg}')
       
    data = response["Items"][0]
    
    if data.get("FirstName", "").lower() != firstName.lower() or data.get('LastName',"").lower() != lastName.lower() or data.get("DateOfBirth", "") != dob:
        return failure_response(300,'No member found.', f'E004 : message:{logmsg}')
        
        
    secretId = os.environ["ACTIVATION_SECRET_ID"]
    region_name = os.environ["REGION"]

    session = boto3.session.Session()
    
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )
    
    session_token = client.get_secret_value(
        SecretId=secretId
    )
    
    stored_secret = json.loads(session_token["SecretString"]).get("SecretString", "")
    encoded_token = jwt.encode({ "uuid": uuid}, stored_secret, algorithm="HS256")

    return {
        'statusCode': "200",
        "headers": {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'GET, OPTIONS, POST',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': '*',
        },
        'body' : json.dumps({'uuid': encoded_token})
    } 

# def get_member_uuid(id):
#     table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
#     member_search = table.query(IndexName='ClientMemberId-index', KeyConditionExpression=Key('ClientMemberId').eq(id))
#     print("Member serch-----------",member_search)
#     if len(member_search.get("Items",[])) == 0:
#         # check enrollment table and match altmember id
#         memberEnrollmentTable = dynamodb.Table(os.environ["EnrollmentDetailsTable"])
#         memberEnrollmentData = memberEnrollmentTable.query(IndexName='AltMemberID-index', KeyConditionExpression=Key('AltMemberID').eq(id))
        
#         if len(memberEnrollmentData.get("Items",[])) == 0 or len(memberEnrollmentData.get("Items",[])) > 1:
#             return None, 'not found in enrollment by amid'
#         member_search = table.query(KeyConditionExpression=Key('uuid').eq(memberEnrollmentData["Items"][0].get("uuid", "")))
#         if len(member_search.get("Items",[])) == 0 or len(member_search["Items"]) > 1:
#             return None, 'not found in mapping by uuid from enrollment'
#     elif len(member_search.get("Items",[])) > 1 or  (len(member_search["Items"]) == 1 and ((member_search["Items"][0].get("cognitoId", "") != "NC") or (member_search["Items"][0].get('cognitoId', "") == ""))) :
#         return None, 'more than 1 was found, id is either blank or does not start with NC'
#     return member_search["Items"][0].get('uuid',''), 'Success'

def get_member_uuid(id):
    table = dynamodb.Table(os.environ['MiddlewareMemberMappingTable'])
    member_search = table.query(
        IndexName='ClientMemberId-index',
        KeyConditionExpression=Key('ClientMemberId').eq(id)
    )
    print("Member search:", member_search)

    items = member_search.get("Items", [])

    if not items:
        # check enrollment table and match altmember id
        memberEnrollmentTable = dynamodb.Table(os.environ["EnrollmentDetailsTable"])
        memberEnrollmentData = memberEnrollmentTable.query(
            IndexName='AltMemberID-index',
            KeyConditionExpression=Key('AltMemberID').eq(id)
        )
        if len(memberEnrollmentData.get("Items", [])) != 1:
            return None, "Not found in enrollment by AltMemberID"

        uuid = memberEnrollmentData["Items"][0].get("uuid", "")
        mapping_lookup = table.query(KeyConditionExpression=Key('uuid').eq(uuid))
        if len(mapping_lookup.get("Items", [])) != 1:
            return None, "Not found in mapping by uuid from enrollment"
        return mapping_lookup["Items"][0].get("uuid", ""), "Success"

    if len(items) > 1:
        return None, "Multiple records found in mapping"

    return items[0].get("uuid", ""), "Success"


def failure_response(statuCode = 400,message='Error while activating member.',error = ''):
    return {
        'statusCode': statuCode,
        'body': json.dumps({'message':message,'errors': str(error)}),
        'headers': headers
    } 

