import json
import http
import boto3
import os
import urllib.parse
from datetime import datetime,timedelta
from boto3.dynamodb.conditions import Key
from httpUtils import request

scope = 'athena/service/Athenanet.MDP.*'
host =  os.environ['EHR_HOST']
connection = http.client.HTTPSConnection(host)
salesforceHost = os.environ['SF_API_PREFIX']
salesforce_connection = http.client.HTTPSConnection(salesforceHost)

default_headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Allow': 'GET, OPTIONS, POST',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Allow-Headers': '*'
}

def lambda_handler(event, context):
    params = event['queryStringParameters']
    uuid = params.get("uuid", "")
    sf_account_id = ""
    athena_id = ""
    department_id = ""
    case_number = str(params.get("caseNumber", ""))
    visit_number = str(params.get("visitNumber", ""))
    
    if case_number is None or case_number == "" or uuid is None or uuid == "":
        return {
            'statusCode': 400,
            'body': json.dumps('missing input, bad request')
        } 
    
    dynamo = boto3.resource('dynamodb')
    mapping_table = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
    response = mapping_table.query(KeyConditionExpression=Key("uuid").eq(uuid))
    if response.get('ResponseMetadata').get('HTTPStatusCode') == 200:
        sf_account_id = response.get('Items')[0].get('SFAccount', "")
        athena_id = response.get('Items')[0].get('athenaId', "")
        department_id = response.get('Items')[0].get('departmentId', "")
        practice_id = os.environ["PRACTICE_ID"]
        
        porter_plan = fetch_porter_plan(practice_id, department_id, athena_id, sf_account_id, visit_number, case_number)

        final_data = {
            "title": "Porter Plan: In-Home Health Risk Assessment",
            "addedBy": porter_plan.get("planOwner", ""),
            "planId": porter_plan.get("planId", ""),
            "text": "Hello, this is the Porter Plan, your personalized passport to positive strides on your healthcare journey. Your Care Guide has spared no detail during the development process of your plan and resources, all to ensure you’re set up for as much health success as possible. Below you’ll find an action plan based off your recent connection to keep you excited and motivated about your health and wellness. And, not to worry, you won’t be doing this alone, your Care Guide will be with you every step of the way. Ready? Let’s go! Your Nurse Practitioner has identified a few areas of adjustment. Here are the recommendations.",
            "followUps": porter_plan.get("followUps", []),
            "medications": porter_plan.get("medications", []),
            "benefits": porter_plan.get("benefits", [])
        }
        
        recommendations_array = porter_plan.get("recommendations", []) if porter_plan.get("recommendations", []) is not None else []
        
        if len(recommendations_array) > 0:
            rec_array = []

            for rec in recommendations_array:
                rec_obj = {}
                rec_obj["type"] = rec.get("type", "")
                rec_obj["status"] = rec.get("status", "")
                rec_obj["helpsWith"] = rec.get("helpsWith", [])
                rec_obj["description"] = rec.get("productDescription", "") or rec.get("serviceDescription", "") or rec.get("materialDescription", "")
                rec_obj["name"] = rec.get("productName", "") or rec.get("serviceType", "") or rec.get("materialTitle", "") or rec.get("recommendationAssociation", "")
                rec_obj["url"] = rec.get("addressOrUrl", "") or rec.get("url", "")
                rec_obj["storeName"] = rec.get("storeName", "")
                rec_obj["address"] = rec.get("address", "")
                rec_obj["price"] = rec.get("estimatedPrice", "")
                rec_obj["website"] = rec.get("websiteOrEmail", "")
                rec_obj["phone"] = rec.get("phone", "")
                rec_obj["educationType"] = rec.get("materialType", "")
                rec_obj["note"] = rec.get("productNotes", "") or rec.get("serviceNotes", "")

                rec_array.append(rec_obj)


            final_data["recommendations"] = rec_array
        
        return {
            'statusCode': 200,
            'body': json.dumps(final_data)
        }
            
        
    else:
        return {
            'statusCode': 401,
            'body': json.dumps('cannot find account given UUID')
        }


def fetch_porter_plan(practice_id, department_id, athena_id, sf_account_id, visit_number, case_number):
    if (visit_number != "" and case_number != ""):
        encounter_list = []
        encounter_list.append(str(visit_number))
        merged_dict = {}

        if department_id == "Aetna" or athena_id == "NC" or athena_id == "":
            medication_data = json.dumps({})
        else:
            route = f'/services/apexrest/CaseService/v1/{case_number}?accountId={sf_account_id}'  
            case_response = request(route, 'GET', {}, {}, salesforce_connection, {}, {},True)
            if case_response['body'] is not None:
                merged_dict = json.loads(case_response['body'])
            route = f'/v1/{practice_id}/chart/{athena_id}/medications?departmentid={department_id}'
            medication_response = request(route, 'GET', {}, scope, connection, {}, {})
            if medication_response.get("statusCode", 400) == 200:
                medication_data = medication_response.get("body", json.dumps({}))
            else:
                return medication_response
        
        print('medication_data: ', medication_data)

        medication_data = json.loads(medication_data)
        medication_data = medication_data.get('medications', [])

        if medication_data:
            data = []
            for k in medication_data:
                for l in k:
                    # if 'encounterid' in l.keys():
                    # if str(l['encounterid']) in encounter_list :
                    data.append(l)
            merged_dict['medications'] = data
        
    elif visit_number == '':
        merged_dict = {}
        route = f'/services/apexrest/CaseService/v1/{case_number}?accountId={sf_account_id}'
        case_response = request(route, 'GET', {}, {}, salesforce_connection, {}, {}, True)
        if case_response['body'] is not None:
            merged_dict = json.loads(case_response['body'])
    elif case_number == '':

        encounter_list = []
        encounter_list.append(str(visit_number))
       
        data = []
        merged_dict = {}

        if department_id == "Aetna" or athena_id == "NC" or athena_id == "":
            medication_data = json.dumps({})
        else:
            route = f'/v1/{practice_id}/chart/{athena_id}/medications?departmentid={department_id}'
            medication_response = request(route, 'GET', {}, scope, connection, {}, {})

            if medication_response.get("statusCode", 400) == 200:
                medication_data = medication_response.get("body", json.dumps({}))
            else:
                return medication_response

        medication_data = json.loads(medication_data)
        medication_data = medication_data.get('medications', [])

        if medication_data:
            data = []
            for k in medication_data:
                for l in k:
                    # if 'encounterid' in l.keys():
                    # if str(l['encounterid']) in encounter_list :
                    data.append(l)
            merged_dict['medications'] = data

        print('1', medication_data )
        ### sf fetch
        parDict = {}
        parDict['accountId'] = sf_account_id
        parDict['page'] = '1'
        parDict['pageSize'] = '100'
        parDict = {i:j for i,j in parDict.items() if j != ''}
        query_params = urllib.parse.urlencode(parDict)
        route = f'/services/apexrest/resourceRecommendations/v1/?{query_params}'
        resource_response = request(route, 'GET', {}, {}, salesforce_connection, {}, {}, True)
        if resource_response['body'] is not None:
            resource_response = json.loads(resource_response['body'])
        ###
        followDict = {}
        followDict['accountId'] = sf_account_id
        followDict['page'] = 1
        followDict['pageSize'] = 4
        followDict['status'] = ""
        followDict = {i:j for i,j in followDict.items() if j != ''}
        query_params = urllib.parse.urlencode(followDict)
        route = f'/services/apexrest/Member/FollowUps/?{query_params}'
        follow_up_response = request(route, 'GET', {}, {}, salesforce_connection, {}, {}, True)
        if follow_up_response['body'] is not None:
            follow_up_response = json.loads(follow_up_response['body'])
        data = []
        follow_up_response = follow_up_response['followUpList']
        for n in follow_up_response:
            if str(n['visitNumber']) in encounter_list :
                data.append(n)
        merged_dict['followUps'] = data

        recommendations = []

        for rr in resource_response :
            if str(rr['visitNumber']) in encounter_list :
                recommendations.append(rr)
        merged_dict['recommendations-up'] = recommendations  
        
    return merged_dict
