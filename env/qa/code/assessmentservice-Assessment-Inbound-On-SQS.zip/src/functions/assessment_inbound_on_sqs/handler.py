import sys
sys.path.append("/opt/python")
import json
from src.functions.common.responses import format_response
from src.functions.common.debug_utils import debug_print
from .process_sqs_message import *


def lambda_handler(event, context):
    debug_print(f"Event: {json.dumps(event)}")
    try:
        # data comes in as a list of records
        for record in event['Records']:
            row = record.get('body', {}).encode().decode("utf-8")
            print('sqs_data: ', row)
            body = json.loads(row)
        
    except json.JSONDecodeError as e:
        debug_print(str(e))
        return format_response(400, {
            'message': 'Invalid JSON in request body',
            'error_type': 'INVALID_REQUEST',
            'error_messgae': str(e)
        })
        
    if not body:
        return format_response(400, {
            'message': 'Request body is empty',
            'error_type': 'MISSING_PARAMETERS'
        })
        
    try:
        debug_print("Calling process_call")
        #body data is a list of records so we are grabbing the top one [0]
        message = body[0]
        result = process_message(message)
        debug_print('Success')
        return format_response(200, result)
    except Exception as e:
        debug_print(str(e))
        return format_response(500, {
            'message': str(e),
            'error_type': type(e).__name__
        })