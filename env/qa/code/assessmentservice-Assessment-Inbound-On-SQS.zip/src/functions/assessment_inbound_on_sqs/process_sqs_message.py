from src.functions.common.debug_utils import debug_print, check_required_vars
from src.functions.common.aws_dynamo_utils import DynamoUtils, DynamoResponse
from src.functions.common.aws_s3_utils import S3Utils,  S3Response
from .athena_service import AthenaService, AthenaConfig
from .convert_to_xml import *
from .xml_to_html import *
from .html_to_pdf import *
import json
from datetime import datetime
from base64 import b64encode
import uuid

today_date = datetime.today().strftime('%Y-%m-%d %H:%M:%S')

def process_message(message):
    debug_print('in process_message')
    payer = map_payer_by_name(message['payerName'])
    debug_print(payer)
    
    # we swap out the name so it's cleaner for filename and s3 path.  SF has bad names for use
    message['payerName'] = payer['payerName']
    
    pdf_file_name = f'{get_file_name(payer, message)}.pdf'
    debug_print("pdf_file_name:", pdf_file_name)
    
    format_tempate_id = get_format_template_id(payer, message)
        
    xml_data = proccess_json(message)
    
    html_data = process_xml(format_tempate_id, xml_data)
        
    process_response = process_html(payer, pdf_file_name, html_data, format_tempate_id)        
    debug_print(process_response)
    
    member = map_member_by_memberid(message['memberId'])
    
    #LEAVING THIS HERE FOR WHEN WE GET THE OTHER API WORKING
    post_member_data(member, payer, message)
    
    if process_response.success and payer['athena_department_id']  != None:
        post_clinical_document(process_response.data.get("key"), payer, member)

    
def map_payer_by_name(payerName: str):
    debug_print('Im creating dyn client')
    dyn_client = DynamoUtils(os.getenv('DDB_MAPPING'), os.getenv('AWS_REGION'))
    
    response = dyn_client.get_item('uuid', os.getenv('DDB_PAYER_PK'), 'mapName', 'pk-payer-map')
    
    debug_print(response)
    
    payers_map = json.loads(response.data['data'])
    
    debug_print(type(payers_map))
    
    for payer in payers_map:
        if payer['matchName'] == payerName:
            debug_print('assessmentservice - [payer]: ', payer)
            return payer
        
def map_member_by_memberid(memberid):
    debug_print('Im looking up member from mw_member_mapping')
    dyn_client = DynamoUtils('mw_member_mapping', os.getenv('AWS_REGION'))
    
    response = dyn_client.query_index(
                    index_name='ClientMemberId-index',
                    key_condition_expression='ClientMemberId = :ClientMemberId',
                    expression_attribute_values={':ClientMemberId': str(memberid)}
                )
    
    if len(response) > 0:
        member = response[0]
    else:
        raise ValueError(f"Did not find a member record for: {memberid}")
    
    return member

def get_file_name(payer, message):
    message['datetimeStamp'] = datetime.now().strftime(payer.get('datetimeFormat', '%Y%m%d%H%M%S'))
    file_name = str(payer['fileNameFormat'])
    for key, value in message.items():
        if f'::{key}::' in file_name:
            debug_print(f'Key: {key}, Value: {value or key}')
            file_name = file_name.replace(f'::{key}::', value or key)
        
    return file_name

def get_format_template_id(payer, message):
    print(message)
    print(message['screenings'][0]['templateId'])
    template_id = str(message['screenings'][0]['templateId'])
    for temp in payer['templates']:
        if temp['hra_template_id'] == template_id:
            return temp['format_template_id']

def get_athena_config():
    required_vars = {
        "ATHENA_TEST": os.getenv('ATHENA_TEST'),
        "ATHENA_PRACTICEID": os.getenv('ATHENA_PRACTICEID'),
        "ATHENA_CLIENTSECRET": os.getenv('ATHENA_CLIENTSECRET'),
        "ATHENA_CLIENTID": os.getenv('ATHENA_CLIENTID'),
        "ATHENA_VERSION": os.getenv('ATHENA_VERSION')
    }
    
    check_required_vars(required_vars)
      
    #check for environment variables
    athena_config = AthenaConfig(version=required_vars['ATHENA_VERSION'],
                                    key=required_vars['ATHENA_CLIENTID'],
                                    secret=required_vars['ATHENA_CLIENTSECRET'],
                                    practice_id=required_vars['ATHENA_PRACTICEID'],
                                    is_test=eval(required_vars['ATHENA_TEST'])    
                                    )
    return athena_config

def get_pdf_from_s3(s3_key: str):
    s3_util = S3Utils(os.getenv('S3_OUTPUT_BUCKET'))
    
    response = s3_util.download_file(s3_key)
    
    debug_print(response)
    
    return response

def post_clinical_document(s3_key: str, payer, member):
    athena_config = get_athena_config()
        
    response = get_pdf_from_s3(s3_key)
    
    document = b64encode(response.data["content"])
    #make the call the Athena
    athena_service = AthenaService(athena_config)
    
    response = athena_service.post_clinical_document(payer["athena_department_id"], member['athenaId'], document)
        
    debug_print(response)
    
def post_member_data(member, payer, message):
    dyn_data = {}
    dyn_data['uuid'] = str(uuid.uuid4())
    dyn_data['athenaId'] = member['athenaId']
    dyn_data['date_posted'] = str(today_date)
    dyn_data['department_id'] = payer['athena_department_id']
    dyn_data['Version'] =""
    dyn_data['template_id'] = message['screenings'][0]['templateId']
    dyn_data['memberName'] = message['memberName']
    dyn_data['memberId'] = str(message['memberId'])
    dyn_data['MBI'] = str(message['mbi'])
    dyn_data['memberLifetimeID'] = str(message['memberLifetimeID'])
    dyn_data['contractId'] = str(message['hContract'])
    dyn_data['completionDate'] = str(message['screenings'][0]['completionDate'])
    dyn_data['raw_data'] = str(message)
    dyn_data['screening_data'] = ''
    dyn_data['screening_id'] = str(message['screenings'][0]['screeningId'])
    
    debug_print('Im creating dyn client')
    dyn_client = DynamoUtils('sf_hra_screening_data', os.getenv('AWS_REGION'))
    
    response = dyn_client.put_item(item=dyn_data)
    
    debug_print(response)