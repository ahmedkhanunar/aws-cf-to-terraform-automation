import lxml.etree as et
import os
from pathlib import Path
from src.functions.common.debug_utils import debug_print

src_path = Path(__file__).parent
    
def process_xml(template_id, xml_data):
    debug_print('In Processing XML')
    xml_file = et.fromstring(xml_data)

    template_path = src_path / template_id / 'hra_xslt.xsl'
    
    xsl_data = et.parse(template_path)

    transform = et.XSLT(xsl_data)

    html_file = transform(xml_file)
        
    return et.tostring(html_file, pretty_print=True, encoding="unicode")
    




