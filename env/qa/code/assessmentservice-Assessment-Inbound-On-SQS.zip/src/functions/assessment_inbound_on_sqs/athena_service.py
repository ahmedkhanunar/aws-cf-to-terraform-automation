from typing import Dict, Any, Optional
from dataclasses import dataclass
import json
from src.functions.common.athena_api_service import APIConnection, ResponseException

@dataclass
class AthenaConfig:
    version: str
    key: str
    secret: str
    practice_id: str
    is_test: bool
    

class AthenaService:
    
    def __init__(self, config: AthenaConfig):
        self.api = APIConnection(config.version,
                                   config.key,
                                   config.secret,
                                   config.practice_id,
                                   config.is_test)
        
   
    def post_clinical_document(self, department_id: int, patient_id: str, doc):
        url = f'/patients/{patient_id}/documents/clinicaldocument'
        data = {
            "departmentid": department_id,
            "documentsubclass": "CLINICALDOCUMENT",
            "attachmentcontents": doc
        }        
        response = self.api.POST(url, data)
        return response