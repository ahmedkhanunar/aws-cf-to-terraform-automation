import json as JS
import xml.etree.ElementTree as ET
import string
from .xml_data_structure import *
from src.functions.common.debug_utils import debug_print

def NullCheck(c):
    return "null" if c is None else c

def get_letter_from_index(num):
    #produces a string from numbers so
    #1->a
    #2->b
    #26->z
    #27->aa
    #28->ab
    #52->az
    #53->ba
    #54->bb

    num2alphadict = dict(zip(range(1, 27), string.ascii_lowercase))
    outval = ""
    numloops = (num-1) //26
    
    if numloops > 0:
        outval = outval + get_letter_from_index(numloops)
        
    remainder = num % 26
    if remainder > 0:
        outval = outval + num2alphadict[remainder]
    else:
        outval = outval + "z"
    return outval

def get_roman_from_index(num):
    roman_map = [
        (1000, 'm'), (900, 'cm'), (500, 'd'), (400, 'cd'),
        (100, 'c'), (90, 'xc'), (50, 'l'), (40, 'xl'),
        (10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')
    ]
    
    result = ''
    for value, symbol in roman_map:
        while num >= value:
            result += symbol
            num -= value
    
    return result

def LoadScreen(s):
    #Load Screen Data   //id, tempId, name, completionDate, agentName, relatedCases
    appointment_date = s['relatedCases'][0].get('appointmentDate', None)
    completion_date = s['completionDate']
    
    date_of_service = completion_date if appointment_date is None else appointment_date
    
    return Screen(NullCheck(s['screeningId']), NullCheck(s['templateId']), NullCheck(s['name']), NullCheck(completion_date), NullCheck(date_of_service), NullCheck(s['agentName']))

def LoadMemeber(m):
    #Load Member Data
    return Member(NullCheck(m['memberId']), NullCheck(m['memberLifetimeID']), NullCheck(m['memberName']),NullCheck(m['payerName']), NullCheck(m['memberDOB']), NullCheck(m['mbi']), NullCheck(m['hContract']))

def LoadQuestion(i, q):
    #print(i)
    #Load Question Data
    id = q['questionId']
    eId = NullCheck(q['externalquestionId'])
    ehrKey = NullCheck(q['ehrKey'])
    section = NullCheck(q['sectionDetail'])
    group = NullCheck(q['groupDetail'])
    qText = q['questionText']
    qNum = str(i)
    return Question(id, eId, ehrKey, section, group, qText, qNum)

def LoadAnswer(a):
    type = NullCheck(a['answerType'])
    answerText = a['answer'] if a['answer'] is not None else a['answerDetails']
    return Answer(type, answerText)

def proccess_json(json_data):
    
    debug_print("in process json")

    cScreen = LoadScreen(json_data['screenings'][0])

    cMember = LoadMemeber(json_data)
    
    root = ET.Element("screening")
    xScreeningId = ET.SubElement(root, "screeningId")
    xScreeningId.text = cScreen.id
    xTemplateId = ET.SubElement(root, "templateId")
    xTemplateId.text = cScreen.tempId
    xScreenName = ET.SubElement(root, "name")
    xScreenName.text = cScreen.name
    xCompletionDateTime = ET.SubElement(root, "completionDateTime")
    xCompletionDateTime.text = cScreen.completionDate
    xDateOfService = ET.SubElement(root, "dateOfService")
    xDateOfService.text = cScreen.dateOfService
    xAgentName = ET.SubElement(root, "agentName")
    xAgentName.text = cScreen.agentName

    xMember = ET.SubElement(root, "member", attrib=cMember.mAttrib)
    xMemberName = ET.SubElement(xMember, "memberName")
    xMemberName.text = cMember.name
    xMemberDOB = ET.SubElement(xMember, "memberDOB")
    xMemberDOB.text = cMember.dob
    xHContract = ET.SubElement(xMember, "hContract")
    xHContract.text = cMember.hContract

    xQuestions = ET.SubElement(root, "questions")
    
    #Loop Main Questions
    for i, d in enumerate(json_data['screenings'][0]['questions']):
        #Load Question Data
        cQuestion = LoadQuestion(i + 1, d)
        xQuestion = ET.SubElement(xQuestions, 'question', attrib=cQuestion.qAttrib)
        
        qn = ET.SubElement(xQuestion, 'questionNumber')
        qn.text = cQuestion.qNumber
        qt = ET.SubElement(xQuestion, 'questionText')
        qt.text = cQuestion.text
        qs = ET.SubElement(xQuestion, 'questionSection')
        qs.text = cQuestion.section
        qg = ET.SubElement(xQuestion, 'questionGroup')
        qg.text = cQuestion.group
        

        #Load Answer Data
        cAnswer = LoadAnswer(d)
        answer = ET.SubElement(xQuestion, 'answer', attrib=cAnswer.aAttrib)
        answer.text = cAnswer.text

        #Check Children Field
        if d['children'] is not None:     
            xChildren = ET.SubElement(xQuestion, 'children')   
            #Loop Sub Questions
            for i, c in enumerate(d['children']):
                #Load Child Question Data
                qNumber = i + 1
                cChild = LoadQuestion(get_letter_from_index(qNumber), c)
                xChild = ET.SubElement(xChildren, 'question', attrib=cChild.qAttrib)
                cqn = ET.SubElement(xChild, 'questionNumber')
                cqn.text = cChild.qNumber
                cqt = ET.SubElement(xChild, 'questionText')
                cqt.text = cChild.text

                cChildAnswer = LoadAnswer(c)
                childAnswer = ET.SubElement(xChild, 'answer', attrib=cChildAnswer.aAttrib)
                childAnswer.text = cChildAnswer.text
                
                if c['children'] is not None:
                    xSubChildren = ET.SubElement(xChild, 'children')
                    #Loop Sub Sub Question
                    for t, s in enumerate(c['children']):
                        qSNumber = t + 1
                        cSubChild = LoadQuestion(get_roman_from_index(qSNumber), s)
                        xSubChild = ET.SubElement(xSubChildren, 'question', attrib=cSubChild.qAttrib)
                        sqn = ET.SubElement(xSubChild, 'questionNumber')
                        sqn.text = cSubChild.qNumber
                        sqt = ET.SubElement(xSubChild, 'questionText')
                        sqt.text = cSubChild.text
                        
                        sChildAnswer = LoadAnswer(s)
                        subAnswer = ET.SubElement(xSubChild, 'answer', attrib=sChildAnswer.aAttrib)
                        subAnswer.text = sChildAnswer.text

    tree = ET.ElementTree(root)

    return ET.tostring(root, encoding="unicode")
