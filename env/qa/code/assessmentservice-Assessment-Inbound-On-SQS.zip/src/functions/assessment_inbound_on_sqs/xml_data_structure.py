
class Screen:
    def __init__(self, id, tempId, name, completionDate, dateOfService, agentName):
        self.id = id
        self.tempId = tempId
        self.name = name
        self.completionDate = completionDate
        self.agentName = agentName
        self.dateOfService = dateOfService

class Member:
    def __init__(self, id, lifeTimeId, name, payerName, dob, mbi, hContract):
        self.id = id
        self.lifeTimeId = lifeTimeId
        self.name = name
        self.payerName = payerName
        self.dob = dob
        self.mbi = mbi
        self.hContract = hContract
        self.mAttrib = {"memberId": id, "lifetimeId": lifeTimeId, "mbi": mbi}
        
class Question:
    def __init__(self, id, eId, ehrKey, section, group, text, qNum = ''):
        self.id = id
        self.eId = eId
        self.ehrKey = ehrKey
        self.section = section
        self.group = group
        self.qAttrib = {"id": id, "externalId": eId, "ehrKey": ehrKey}
        self.text = text
        self.qNumber = qNum

class Answer:
    def __init__(self, type, text):
        self.type = type
        self.aAttrib = {"type": type}
        self.text = text
