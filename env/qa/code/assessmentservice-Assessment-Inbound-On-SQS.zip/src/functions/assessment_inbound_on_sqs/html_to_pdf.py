from pathlib import Path
from src.functions.common.debug_utils import debug_print
from src.functions.common.aws_s3_utils import S3Utils, S3Response
from datetime import datetime
import os
import pdfkit
import subprocess

src_path = Path(__file__).parent

# def html_to_pdf(html_content):    
#     css_path = src_path / 'template' / 'hra.css'
#     debug_print(f"CSS File Path: {str(css_path)}")
#     HTML(string=html_content).write_pdf(stylesheets=[str(css_path)], presentational_hints=True)

    
def process_html(payer, pdf_file_name, html_file, template_id):
    debug_print('In Process HTML')
    output_bucket = os.getenv('S3_OUTPUT_BUCKET')
    output_path = os.getenv('S3_OUTPUT_ROOT')
    output_path = output_path.replace('::payer::', payer['payerName'])
    date_stamp = str(datetime.now().strftime('%Y%m%d'))
    output_path = output_path.replace('::yyyymmdd::', date_stamp)
        
    options = {
        'network-default-ssl-verify': 'false',
        'ignore-ssl-errors': True
    }
    
    pdf_path =f'/tmp/{pdf_file_name}'
    
    s3_util = S3Utils(output_bucket)
        
    #debug_print(html_file)
    css_path = src_path / template_id / 'hra.css'
    debug_print(f"CSS File Path: {str(css_path)}") 
    

    wk_path = os.getenv('WKHTMLTOPDF_PATH', '/opt/bin/wkhtmltopdf')
    pdfkit_config = pdfkit.configuration(wkhtmltopdf=str(wk_path))
    
        
    pdfkit_options = {
    "disable-local-file-access": None,
    "enable-local-file-access": None,
    "print-media-type": None
    }
    
    pdfkit.from_string(html_file, pdf_path, css=css_path, configuration=pdfkit_config, options=pdfkit_options)

    debug_print('Passed pdfkit')
    #pdfkit.from_string(html_file, pdf_path, configuration=pdfkit_config, options=options)
    
    #HTML(string=html_file).write_pdf(pdf_buffer, stylesheets=[str(css_path)], presentational_hints=True)
    
    #pdf_buffer.seek(0)
    
    upload_response = s3_util.upload_file(
        pdf_path,
        f"{output_path}/{pdf_file_name}",
        {'ContentType': 'applciation/pdf'}
    )
        
    return upload_response