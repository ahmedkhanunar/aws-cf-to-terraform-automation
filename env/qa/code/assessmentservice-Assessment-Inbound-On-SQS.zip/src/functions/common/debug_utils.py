"""
Debug Utilities Module

This module provides debugging utilities for development and troubleshooting.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

import os
from typing import Dict, Any

def debug_print(*args: Any, **kwargs: Any) -> None:
    """
    Print debug messages when DEBUG environment variable is set to 'true'.

    Parameters
    ----------
    *args : Any
        Variable length argument list to print
    **kwargs : Any
        Arbitrary keyword arguments passed to print function

    Examples
    --------
    >>> debug_print("Processing request:", request_id)
    >>> debug_print("Error occurred", error=True)
    """
    if os.getenv('DEBUG', 'true').lower() == 'true':
        print(*args, **kwargs) 
  
def check_required_vars(vars_list: Dict[str, any]):
    missing_vars = [var for var, value in vars_list.items() if not value]
    
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    
    return True