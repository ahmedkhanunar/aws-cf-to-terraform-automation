"""
S3 Utilities Module

This module provides utilities for interacting with AWS S3.

Authors: BBehrens, KElder
Company: Porter Cares
Copyright: 2024
"""

from typing import Dict, Any, Optional, BinaryIO, Union
import boto3
from botocore.exceptions import ClientError
from dataclasses import dataclass
import json
from pathlib import Path
import mimetypes


@dataclass
class S3Response:
    success: bool
    data: Optional[Dict[str, Any]] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    
    def __bool__(self):
        return self.success
    
class S3Utils:
    def __init__(self, bucket_name: str):
        self.s3 = boto3.client('s3')
        self.bucket_name = bucket_name
        
    def upload_file(self,
                    file_path: Union[str, Path, BinaryIO],
                    s3_key: str,
                    extra_args: Optional[Dict[str, Any]] = None) -> S3Response:
        """
        Upload a file to S3 bucket
        
        Args:
            file_path: Local file path or file-like object
            s3_key: Destination path in S3
            extra_args: Additional arguments for upload (e.g., ACL, ContentType)
            
        Returns:
            S3Response: Object containing success status and error details if any
        """
        try:
           # Set default content type based on file extension
            if extra_args is None:
                extra_args = {}
            if 'ContentType' not in extra_args and isinstance(file_path, (str, Path)):
                content_type, _ = mimetypes.guess_type(str(file_path))
                if content_type:
                    extra_args['ContentType'] = content_type 
                    
            if isinstance(file_path, (str, Path)):
                self.s3.upload_file(str(file_path), self.bucket_name, s3_key, ExtraArgs=extra_args)
            else:
                self.s3.upload_fileobj(file_path, self.bucket_name, s3_key, ExtraArgs=extra_args)
            
            # Get the URL of the uploaded file
            url = f"https://{self.bucket_name}.s3.amazonaws.com/{s3_key}"
            
            return S3Response(
                success=True,
                data={
                    'url': url,
                    'bucket': self.bucket_name,
                    'key': s3_key
                }
            )
        
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'NoSuchBucket':
                error_message = f'Bucket {self.bucket_name} does not exist'
            elif error_code == 'AccessDenied':
                error_message = 'Access denied to S3 bucket'
                
            return S3Response(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return S3Response(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
            
    def download_file(self,
                      s3_key: str,
                      local_path: Optional[Union[str, Path]] = None) -> S3Response:
        """
        Download a file from S3 bucket
        
        Args:
            s3_key: Path of file in S3
            local_path: Optional local path to save file
            
        Returns:
            S3Response: Object containing success status and error details if any
        """
        try:
            if local_path:
                self.s3.download_file(self.bucket_name, s3_key, str(local_path))
                data = {'local_path': str(local_path)}
            else:
                # If no local path provided, get the file content
                response = self.s3.get_object(Bucket=self.bucket_name, Key=s3_key)
                data = {
                    'content': response['Body'].read(),
                    'metadata': response.get('Metadata', {}),
                    'content_type': response.get('ContentType', 'application/octet-stream')
                }
            
            return S3Response(
                success=True,
                data=data
            )
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'NoSuchKey':
                error_message = f'File {s3_key} does not exist in bucket'
            elif error_code == 'NoSuchBucket':
                error_message = f'Bucket {self.bucket_name} does not exist'
                
            return S3Response(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return S3Response(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
            
    def delete_file(self, s3_key: str) -> S3Response:
        """
        Delete a file from S3 bucket
        
        Args:
            s3_key: Path of file in S3
            
        Returns:
            S3Response: Object containing success status and error details if any
        """
        try:
            # Check if file exists before deleting
            self.s3.head_object(Bucket=self.bucket_name, Key=s3_key)
            
            self.s3.delete_object(Bucket=self.bucket_name, Key=s3_key)
            return S3Response(
                success=True,
                data={'deleted_key': s3_key}
            )
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            if error_code == 'NoSuchKey':
                error_message = f'File {s3_key} does not exist in bucket'
            elif error_code == '404':
                error_message = f'File {s3_key} does not exist in bucket'
                
            return S3Response(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return S3Response(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )
            
    def list_files(self,
                   prefix: str = '',
                   max_keys: int = 1000) -> S3Response:
        """
        List files in S3 bucket with given prefix
        
        Args:
            prefix: Filter results by prefix
            max_keys: Maximum number of keys to return
            
        Returns:
            S3Response: Object containing success status and error details if any
        """
        try:
            response = self.s3.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix,
                MaxKeys=max_keys
            )
            
            files = []
            for obj in response.get('Contents', []):
                files.append({
                    'key': obj['Key'],
                    'size': obj['Size'],
                    'last_modified': obj['LastModified'].isoformat(),
                    'url': f"https://{self.bucket_name}.s3.amazonaws.com/{obj['Key']}"
                })
                
            return S3Response(
                success=True,
                data={
                    'files': files,
                    'is_truncated': response.get('IsTruncated', False),
                    'key_count': response.get('KeyCount', 0)
                }
            )
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            
            return S3Response(
                success=False,
                error_code=error_code,
                error_message=error_message
            )
        except Exception as e:
            return S3Response(
                success=False,
                error_code='UnhandledException',
                error_message=str(e)
            )