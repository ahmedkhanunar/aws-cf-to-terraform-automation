import json

def format_response(status_code: int, body: dict) -> dict:
    """
    Format a standard API response with proper headers and JSON body.
    
    Args:
        status_code: HTTP status code for the response
        body: Dictionary to be JSON encoded as the response body
        
    Returns:
        Dictionary containing the formatted response with status code, headers, and JSON body
    """
    return {
        'statusCode': status_code,
        'headers': {
            "Content-Type": "application/json"
        },
        'body': json.dumps(body)
    }

def format_error_response(status_code, message, error_type=None, details=None):
    error_body = {
        "message": message,
        "error_type": error_type,
        "details": details
    }
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps(error_body)
    }
