import json
import os
import json
from boto3.dynamodb.conditions import Key
from datetime import datetime,timezone
import boto3
from cerberus import Validator
import sys
import traceback


dynamo = boto3.resource("dynamodb")
memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Allow": "GET, OPTIONS, POST",
    "Access-Control-Allow-Methods": "*",
    "Access-Control-Allow-Headers": "*",
}


caregiverStatusSchema = {
    "status": {"type": "string", "required": True, "allowed": ["ACTIVE", "INACTIVE"]},
    "sfRelationshipId": {"type": "string", "required": True},
    "notifyCaregiver": {"type": "boolean", "required": False},
}
caregiverResubmitStatusSchema = {
    "status": {"type": "string", "required": True, "allowed": ["RESEND_INVITE"]},
    "caregiverRequestId": {"type": "string", "required": True},
}


def lambda_handler(event, context):

    return update_caregiver_request_status(event)


def update_caregiver_request_status(event):
    try:
        bodyData = json.loads(event.get("body")) if event.get("body") != None else {}

        validator = Validator(caregiverStatusSchema, allow_unknown=True)
        reubmitValidator = Validator(caregiverResubmitStatusSchema, allow_unknown=True)
        if not (validator.validate(bodyData) or reubmitValidator.validate(bodyData)):
            return failure_response(400, "invalid body")

        dateTimeNow = datetime.now(timezone.utc).isoformat("#", "seconds")

        caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
        if bodyData.get("sfRelationshipId") is not None:
            caregiverRequestDataResponse = caregiverRequestTable.scan(
                FilterExpression=Key("RelationshipSFId").eq(
                    bodyData["sfRelationshipId"]
                )
            )

        else:
            caregiverRequestDataResponse = caregiverRequestTable.query(
                KeyConditionExpression=Key("CaregiverRequestUUID").eq(
                    bodyData["caregiverRequestId"]
                )
            )

        if (
            caregiverRequestDataResponse is None
            or caregiverRequestDataResponse.get("Items") is None
            or len(caregiverRequestDataResponse.get("Items")) == 0
        ):
            return failure_response(404, "Invalid request data.")

        caregiverRequestData = caregiverRequestDataResponse.get("Items")[0]

        memberWithCaregiverRequestData = fetch_caregiver_request_data(
            caregiverRequestData["CarereceiverUUID"],
            "CaregiverMappingList",
            caregiverRequestData["CaregiverRequestUUID"],
        )

        if memberWithCaregiverRequestData is None:
            return failure_response(404, "Invalid request data.")

        caregiverRequestDataIndex = memberWithCaregiverRequestData[
            "caregiverRequestDataIndex"
        ]

        caregiverRequestData = memberWithCaregiverRequestData["caregiverRequestData"]



        if caregiverRequestData.get('Status','') == 'REMOVED':
            return failure_response(404, "Invalid request data.")
        #check existing status for RESEND_INVITE
        if bodyData["status"] == "RESEND_INVITE" and not (caregiverRequestData['Status'] == 'INVITE_SENT' or caregiverRequestData['Status'] == 'INVITE_REJECTED'):
            return failure_response(400,'You can resend invite only for pending caregiver invitation.')
         

        return update_request(
            caregiverRequestData,
            bodyData["status"],
            dateTimeNow,
            caregiverRequestDataIndex,
            bodyData.get("notifyCaregiver", False),
        )

    except Exception as err:
        exec_info = sys.exc_info()
        ex = "".join(traceback.format_exception(*exec_info))
        write_excpetion_to_sqs(json.dumps({"Exception": ex, "Date": datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}))
        
        return failure_response()


def fetch_caregiver_request_data(
    memberUUID, requestTypeListAttribute, caregiverRequestUUID
):

    memberMappingItems = memberMappingTable.get_item(Key={"uuid": memberUUID})
    if (
        memberMappingItems is None
        or memberMappingItems.get("Item") is None
        or len(memberMappingItems.get("Item")) == 0
    ):
        return None

    memberData = memberMappingItems.get("Item")
    attributeListData = memberData.get(requestTypeListAttribute)

    if attributeListData is None or len(attributeListData) == 0:
        return None

    # filter giver caregiver request index
    caregiverRequestDataIndex = [
        i
        for i in range(len(attributeListData))
        if (attributeListData[i]['CaregiverRequestUUID'] == caregiverRequestUUID and not attributeListData[i].get('IsDeleted',False))
    ]

    if caregiverRequestDataIndex is None or len(caregiverRequestDataIndex) == 0:
        return None

    caregiverRequestData = attributeListData[caregiverRequestDataIndex[0]]

    return {
        "memberData": memberData,
        "caregiverRequestDataIndex": caregiverRequestDataIndex[0],
        "caregiverRequestData": caregiverRequestData,
    }


def get_member_details(memberUUID):
    memberDetailTable = dynamo.Table(os.environ['MemberDetailsTable'])
    memberDetailResponse = memberDetailTable.query(KeyConditionExpression=Key('uuid').eq(memberUUID))
    if len(memberDetailResponse["Items"]) == 0 or len(memberDetailResponse["Items"]) > 1:
            return None
    memberDetail = memberDetailResponse["Items"][0]
    
    return memberDetail
    


def get_member_maping_data(cognitoId):
    memberMappingTable = dynamo.Table(os.environ["MiddlewareMemberMappingTable"])
    memberMappingResponse = memberMappingTable.query(
        IndexName="cognitoId-index",
        KeyConditionExpression=Key("cognitoId").eq(cognitoId),
    )
    if (
        len(memberMappingResponse["Items"]) == 0
        or len(memberMappingResponse["Items"]) > 1
    ):
        return None

    return memberMappingResponse["Items"][0]


def update_care_receiver_data(memberId, caregiverRequestUUID, updatedData):
    memberWithCarereceiverRequestData = fetch_caregiver_request_data(
        memberId, "CarereceiverMappingList", caregiverRequestUUID
    )

    if memberWithCarereceiverRequestData is None:
        return failure_response(404, "Invalid request data.")

    carereceiverRequestDataIndex = memberWithCarereceiverRequestData[
        "caregiverRequestDataIndex"
    ]

    carereceiverRequestData = memberWithCarereceiverRequestData["caregiverRequestData"]
    carereceiverRequestData.update(updatedData)
    memberMappingTable.update_item(
        Key={"uuid": memberId},
        UpdateExpression="set CarereceiverMappingList["
        + str(carereceiverRequestDataIndex)
        + "] = :carereceiverMemberData",
        ExpressionAttributeValues={":carereceiverMemberData": carereceiverRequestData},
        ReturnValues="UPDATED_NEW",
    )


def update_request(
    caregiverRequestData, status, dateTimeNow, caregiverMemberDataIndex, notifyCaregiver
):

    if status == "RESEND_INVITE":
        caregiverRequestData["Status"] = "INVITE_SENT"
        caregiverRequestData["IsClicked"] = False
        caregiverRequestData["CreatedDate"] = dateTimeNow
    else:
        caregiverRequestData["Status"] = str(status)

    caregiverRequestData["UpdatedDate"] = dateTimeNow

    memberMappingTable.update_item(
        Key={"uuid": caregiverRequestData["CarereceiverUUID"]},
        UpdateExpression="set CaregiverMappingList["
        + str(caregiverMemberDataIndex)
        + "] = :caregiverMemberData",
        ExpressionAttributeValues={":caregiverMemberData": caregiverRequestData},
        ReturnValues="UPDATED_NEW",
    )

    if status == "RESEND_INVITE":
        if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
            update_care_receiver_data(
            caregiverRequestData["CaregiverUUID"],
            caregiverRequestData["CaregiverRequestUUID"],
            {
                "Status": "INVITE_SENT",
                "CreatedDate": dateTimeNow,
                "UpdatedDate": dateTimeNow,
                "IsClicked": False,
            },
            )
        memberData = get_member_details(caregiverRequestData["CarereceiverUUID"])
        if memberData is not None:
            send_invite_email(caregiverRequestData, memberData)
    else:
      if caregiverRequestData.get('CaregiverUUID') is not None and caregiverRequestData.get('CaregiverUUID') != '':
        update_care_receiver_data(
            caregiverRequestData["CaregiverUUID"],
            caregiverRequestData["CaregiverRequestUUID"],
            {"Status": status, "UpdatedDate": dateTimeNow}
            )
      if status == "INACTIVE" and notifyCaregiver:
        memberData = get_member_details(caregiverRequestData["CarereceiverUUID"])
        if memberData is not None:
            send_deactivation_email(caregiverRequestData, memberData)

    caregiverRequestTable = dynamo.Table(os.environ["CareGiverRequestTable"])
    caregiverRequestTable.put_item(Item=caregiverRequestData)

    return {
        "statusCode": 200,
        "body": json.dumps(
            {"message": "Caregiver request status updated successfully!"}
        ),
        "headers": headers,
    }


def send_invite_email(bodyData, memberData):
    client = boto3.client("ses")
    accept_url = (
        os.environ["WebAppUrl"]
        + "/"
        + bodyData["CarereceiverUUID"]
        + "/caregiver/"
        + bodyData["CaregiverRequestUUID"]
        + "/?status=INVITE_ACCEPTED"
    )
    reject_url = (
        os.environ["WebAppUrl"]
        + "/"
        + bodyData["CarereceiverUUID"]
        + "/caregiver/"
        + bodyData["CaregiverRequestUUID"]
        + "/?status=INVITE_REJECTED"
    )
    requester_name = memberData["FirstName"].capitalize() + " " + memberData["LastName"][0].capitalize()
    body_html = (
        """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      """
        + memberData["FirstName"].capitalize()
        + """ Has Invited You to be Their Caregiver on Porter!
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""
        + requester_name
        + """.</b> has invited you to be their caregiver on Porter. This means you’ll be able to view and assist with appointments, visit notes, medical reports and much more! Click the button below to accept the invite and create your account.
         <br/><br/>If you received this email by mistake, please ignore it and delete the email. 
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                        <a style="font-weight: normal; text-align: center; background:#726F81; color: #fff; padding: 16px 32px;margin-right:20px; border-radius: 100px;" href='"""
        + reject_url
        + """' class="btn org">Decline</a>
									<a style="font-weight: normal; text-align: center; background:#ED7100; color: #fff; padding: 16px 32px; border-radius: 100px;" href='"""
        + accept_url
        + """' class="btn org">Accept Invite</a>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              300 E Lombard St., Suite 840,<br>
                              Baltimore, MD 21202<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>"""
    )
    email_message = {
        "Body": {
            "Html": {
                "Charset": "utf-8",
                "Data": body_html,
            },
        },
        "Subject": {
            "Charset": "utf-8",
            "Data": memberData["FirstName"].capitalize()+ " Has Invited You to be Their Caregiver on Porter!",
        },
    }
    ses_response = client.send_email(
        Destination={
            "ToAddresses": [bodyData["EmailAddress"]],
        },
        Message=email_message,
        Source="no-reply@helloporter.com",
    )


def send_deactivation_email(bodyData, memberData):
    client = boto3.client("ses")
    requester_name = memberData["FirstName"] + " " + memberData["LastName"]
    body_html = (
        """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <html>
  <head>
    <!-- Compiled with Bootstrap Email version: 1.3.1 -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no, date=no, address=no, email=no">
    <style type="text/css">
      body,table,td{font-family:Helvetica,Arial,sans-serif !important}.ExternalClass{width:100%}.ExternalClass,.ExternalClass p,.ExternalClass span,.ExternalClass font,.ExternalClass td,.ExternalClass div{line-height:150%}a{text-decoration:none}*{color:inherit}a[x-apple-data-detectors],u+#body a,#MessageViewBody a{color:inherit;text-decoration:none;font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit}img{-ms-interpolation-mode:bicubic}table:not([class^=s-]){font-family:Helvetica,Arial,sans-serif;mso-table-lspace:0pt;mso-table-rspace:0pt; border-spacing:0px;border-collapse:collapse}table:not([class^=s-]) td{border-spacing:0px;border-collapse:collapse}@media screen and (max-width: 600px){.w-full,.w-full>tbody>tr>td{width:100% !important}.w-24,.w-24>tbody>tr>td{width:96px !important}.w-40,.w-40>tbody>tr>td{width:160px !important}.p-lg-10:not(table),.p-lg-10:not(.btn)>tbody>tr>td,.p-lg-10.btn td a{padding:0 !important}.p-3:not(table),.p-3:not(.btn)>tbody>tr>td,.p-3.btn td a{padding:12px !important}.p-6:not(table),.p-6:not(.btn)>tbody>tr>td,.p-6.btn td a{padding:24px !important}*[class*=s-lg-]>tbody>tr>td{font-size:0 !important;line-height:0 !important;height:0 !important}.s-4>tbody>tr>td{font-size:16px !important;line-height:16px !important;height:16px !important}.s-6>tbody>tr>td{font-size:24px !important;line-height:24px !important;height:24px !important}.s-10>tbody>tr>td{font-size:40px !important;line-height:40px !important;height:40px !important}} 
      /* Custom Button Styling */ .btn {padding: 16px 32px; border-radius: 100px;} .btn.org {background:#ED7100; color: #fff;}
    </style>
  </head>
  <body class="bg-light" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
    <table class="bg-light body" valign="top" role="presentation" border="0" cellpadding="0" cellspacing="0" style="outline: 0; width: 100%; min-width: 100%; height: 100%; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; font-family: Helvetica, Arial, sans-serif; line-height: 24px; font-weight: normal; font-size: 16px; -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; color: #000000; margin: 0; padding: 0; border-width: 0;" bgcolor="#f7fafc">
      <tbody>
        <tr>
          <td valign="top" style="line-height: 24px; font-size: 16px; margin: 0;" align="left" bgcolor="#f7fafc">
            <table class="container" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
              <tbody>
                <tr>
                  <td align="center" style="line-height: 24px; font-size: 16px; margin: 0; padding: 0 16px;">
                    <!--[if (gte mso 9)|(IE)]>
                      <table align="center" role="presentation">
                        <tbody>
                          <tr>
                            <td width="600">
                    <![endif]-->
                    <table align="center" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 600px; margin: 0 auto;">
                      <tbody>
                        <tr>
                          <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-24" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 146px; border-style: none; border-width: 0;" width="96">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="card p-6 p-lg-10 space-y-4" role="presentation" border="0" cellpadding="0" cellspacing="0" style="border-radius: 6px; border-collapse: separate !important; width: 100%; overflow: hidden; border: 1px solid #e2e8f0;" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; width: 100%; margin: 0; padding: 40px;" align="left" bgcolor="#ffffff">
                                    <h1 class="h3 fw-700" style="padding-top: 0; padding-bottom: 0; font-weight: 700 !important; vertical-align: baseline; font-size: 28px; line-height: 33.6px; margin: 0;" align="left">
                                      This Email is to Notify You that the Following Member has Deactivated Your Caregiver Access to there health dashboard. 
                                    </h1>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <p class="" style="line-height: 24px; font-size: 16px; width: 100%; margin: 0 0 24px 0;" align="left">
                                       <b>"""
        + requester_name
        + """</b></br> 
                                        No further action is needed from you at this point. If you feel this was by mistake, please reach out to the member. 
                                    </p>
                                    <table class="s-4 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                                      <tbody>
                                        <tr>
                                          <td style="line-height: 16px; font-size: 16px; width: 100%; height: 16px; margin: 0;" align="left" width="100%" height="16">
                                            &#160;
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
         	                         </tr>
                              </tbody>
                            </table>
                            <table class="s-10 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 40px; font-size: 40px; width: 100%; height: 40px; margin: 0;" align="left" width="100%" height="40">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="ax-center" role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 16px; margin: 0;" align="left">
                                    <img class="w-40" src="https://www.helloporter.com/wp-content/uploads/2023/04/porter_logo_dark.png" style="height: auto; line-height: 100%; outline: none; text-decoration: none; display: block; width: 90px; border-style: none; border-width: 0;" width="160">
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="text-muted text-center" style="color: #718096;" align="center">
                              <p>Porter Cares, Inc.<br>
                              300 E Lombard St., Suite 840,<br>
                              Baltimore, MD 21202<br></p>
                            <p><a href="https://www.helloporter.com">www.helloporter.com</a></p>
                            </div>
                            <table class="s-6 w-full" role="presentation" border="0" cellpadding="0" cellspacing="0" style="width: 100%;" width="100%">
                              <tbody>
                                <tr>
                                  <td style="line-height: 24px; font-size: 24px; width: 100%; height: 24px; margin: 0;" align="left" width="100%" height="24">
                                    &#160;
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    <!--[if (gte mso 9)|(IE)]>
                    </td>
                  </tr>
                </tbody>
              </table>
                    <![endif]-->
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>"""
    )
    email_message = {
        "Body": {
            "Html": {
                "Charset": "utf-8",
                "Data": body_html,
            },
        },
        "Subject": {
            "Charset": "utf-8",
            "Data": f"Caregiver request",
        },
    }
    ses_response = client.send_email(
        Destination={
            "ToAddresses": [bodyData["EmailAddress"]],
        },
        Message=email_message,
        Source="no-reply@helloporter.com",
    )


def failure_response(
    statuCode=400, message="Error while updating caregiver request.", error=""
):
    return {
        "statusCode": statuCode,
        "body": json.dumps({"message": message, "errors": str(error)}),
        "headers": headers,
    }

def write_excpetion_to_sqs(message):
    sqs = boto3.client('sqs')  #client is required to interact with 
    url = os.environ['SQS_EXCEPTION_URL']
    
    sqs.send_message(
        QueueUrl=url,
        MessageBody=message
    )