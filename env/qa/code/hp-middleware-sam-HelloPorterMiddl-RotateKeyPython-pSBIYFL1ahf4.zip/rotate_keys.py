import os
import boto3
import time
import logging
from enum import Enum
import datetime
import dateutil.tz
import json
import urllib3
from base64 import b64encode
from nacl import encoding, public

timestamp = int(round(time.time() * 1000))
log = logging.getLogger()
log.setLevel(logging.INFO)

def lambda_handler(event, context):
  log.info('Starting Key Rotation function.')
  
  dryrun = str(os.getenv('DRY_RUN')).lower() == 'true'
  environment_str = os.getenv('ENVIRONMENT').upper()

  iam_client = boto3.client('iam')
  action_queue = get_actions_for_account(iam_client)
  
  total_actions = len(action_queue)
  log.info(f'There are {total_actions} actions')

  if action_queue:
    log_actions(action_queue, dryrun)

    if dryrun:
      send_notification(action_queue, dryrun, environment_str)
    else:
      execute_actions(action_queue, iam_client)
      send_notification(action_queue, dryrun, environment_str)

  log.info('---------------------------')
  log.info('Key Rotation function has completed.')

def get_actions_for_account(iam_client):
  # Initialize values
  list_of_exempted_users_str = os.getenv('IAMUSERS_DONOT_ROTATE')
  if len(list_of_exempted_users_str) > 0:
      list_of_exempted_users = list_of_exempted_users_str.split(",")
  else:
      list_of_exempted_users = []

  action_queue = []

  # Get all Users in AWS Account
  users = iam_client.list_users()['Users']
  if not users:
    log.info('There are no users in this account.')
  else:
    total_users = len(users)

    log.info(
      f'Starting user loop. There are {total_users}'
      f' users to evaluate in this account.')
    log.info('---------------------------')

    for user in users:
      user_name = user['UserName']

      # handle exemptions
      if user_name in list_of_exempted_users:
        log.info(
          f'--User [{user_name}] is exempt.'
          f' Skipping validation check.')
        continue
      else:
        log.info(f'--User [{user_name}] is not exempt.')
  
      access_key_metadata = iam_client.list_access_keys(UserName=user["UserName"])['AccessKeyMetadata']

      user_actions = get_actions_for_keys(access_key_metadata, iam_client)

      action_queue += user_actions

  return action_queue

def get_actions_for_keys(access_key_metadata, iam_client):
  action_queue = []
  keys = []

  # Installation being time between rotation and deactivation
  installation_grace_period = int(os.getenv('INSTALLATION_GRACE_PERIOD', 7))

  # Recovery between deactivation and deletion
  recovery_grace_period = int(os.getenv('RECOVERY_GRACE_PERIOD', 7))

  # how many days ahead of time to warn users of pending actions
  pending_action_warn_period = int(os.getenv('PENDING_ACTIVATION_WARN_PERIOD', 7))

  # The number of days after which a key should be rotated
  # Default = 90 days
  rotation_period = int(os.getenv('KEYROTATION_MAX_AGE', 90))

  # Cache current time to avoid race conditions
  now = datetime.datetime.now(tz=dateutil.tz.gettz('US/Eastern'))
  warn_period = datetime.timedelta(days=pending_action_warn_period)
  installation_grace_period = datetime.timedelta(days=installation_grace_period)
  recovery_grace_period = datetime.timedelta(days=recovery_grace_period)

  for key in access_key_metadata:
      # Populate lastused and expiration dates
      try:
          key['LastUsedDate'] = iam_client.get_access_key_last_used(
              AccessKeyId=key['AccessKeyId']
              )['AccessKeyLastUsed']['LastUsedDate']
      except:
          log.info("--Key has not been used before.")
          key['LastUsedDate'] = None
          
      key['ExpireDate'] = key['CreateDate'] + \
          datetime.timedelta(days=rotation_period)

      # if the key is expired and has never been used, just delete it
      if key['LastUsedDate'] is None \
              and key['ExpireDate'] <= now:
          reason = ActionReasons.UNUSED_EXPIRED_KEY
          log.info(
              f'ROTATE_AND_DELETE {key["UserName"]}: {key["AccessKeyId"]} '
              f'-- {reason.value}')
          action_queue.append({
              'action': 'ROTATE_AND_DELETE',
              'key': key,
              'reason': reason
          })
          continue

      # if the key is about to expire and has never been used, warn
      if key['LastUsedDate'] is None \
              and key['ExpireDate'] <= now + warn_period:
          reason = ActionReasons.UNUSED_KEY_PENDING_DELETION
          log.info(
              f'WARN {key["UserName"]}: {key["AccessKeyId"]} '
              f'-- {reason.value}')
          action_queue.append({
              'action': 'WARN',
              'action_date': key['ExpireDate'],
              'key': key,
              'reason': reason
          })

      keys.append(key)

  if len(keys) == 0:
      log.info('Skipping, no keys to evaluate.')

  elif len(keys) == 1:
      key = keys[0]

      if key['Status'] == 'Active':
          log.info('--Key Logic: [Active, Null]')
          # rotate expiring key
          if key['ExpireDate'] <= now:
              reason = ActionReasons.EXPIRED_ACTIVE_KEY
              # key is expired and needs to be rotated
              log.info(
                  f'ROTATE {key["UserName"]}: {key["AccessKeyId"]}'
                  f'-- {reason.value}')
              action_queue.append({
                  'action': 'ROTATE',
                  'key': key,
                  'reason': reason
              })

          # warn if key is about to expire
          elif key['ExpireDate'] <= now + warn_period:
              reason = ActionReasons.KEY_PENDING_ROTATION
              log.info(
                  f'WARN {key["UserName"]}: {key["AccessKeyId"]}'
                  f'-- {reason.value}')
              action_queue.append({
                  'action': 'WARN',
                  'action_date': key['ExpireDate'],
                  'key': key,
                  'reason': reason
              })

      elif key['Status'] != 'Active':
          log.info('--Key Logic: [Inactive, Null]')
          # all we can do here is calculate grace period based on creation
          rotation_date = key['CreateDate']
          delete_date = rotation_date + \
                        installation_grace_period + \
                        recovery_grace_period

          # recovery period has ended
          if delete_date <= now:
              reason = ActionReasons.RECOVER_GRACE_PERIOD_END
              log.info(
                  f'DELETE {key["UserName"]}: '
                  f'{key["AccessKeyId"]} '
                  f'-- {reason.value}')
              action_queue.append({
                  'action': 'DELETE',
                  'key': key,
                  'reason': reason
              })
          # warn of pending deletion
          elif delete_date <= now + warn_period:
              reason = ActionReasons.KEY_PENDING_DELETION
              log.info(
                  f'WARN {key["UserName"]}: {key["AccessKeyId"]}'
                  f'-- {reason.value}')
              action_queue.append({
                  'action': 'WARN',
                  'action_date': delete_date,
                  'key': key,
                  'reason': reason
              })
          # nothing to do, key is valid
          else:
              log.info('Skipping, key is valid.')
              print('Skipping, key is valid.')

  elif len(keys) == 2:
      num_active = len([k for k in keys if k['Status'] == 'Active'])
      if num_active == 0:
          log.info('--Key Logic: [Inactive,Inactive]')
          num_expired = len([k for k in keys if k['ExpireDate'] <= now])

          if num_expired == 2:
              # both keys are inactive and expired, just delete them
              for key in keys:
                  reason = ActionReasons.RECOVER_GRACE_PERIOD_END
                  log.info(
                      f'DELETE {key["UserName"]}: '
                      f'{key["AccessKeyId"]} '
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'DELETE',
                      'key': key,
                      'reason': reason
                  })
          elif num_expired == 1:
              # maybe someone deactivated the new key accidentally?
              # respect the recovery grace period on the inactive key
              inactive_keys_by_create_date = sorted(
                  keys, key=lambda x: x['CreateDate'])
              expired_key = inactive_keys_by_create_date[0]
              unexpired_key = inactive_keys_by_create_date[1]
              # use the creation date of the unexpired key
              # to guess when the expired key was deactivated
              expired_key_rotation_date = unexpired_key['CreateDate']
              expired_key_delete_date = \
                  expired_key_rotation_date + \
                  installation_grace_period + \
                  recovery_grace_period
              unexpired_key_rotation_date = unexpired_key['ExpireDate']

              # delete the expired key if grace period is over
              if expired_key_delete_date <= now:
                  reason = ActionReasons.RECOVER_GRACE_PERIOD_END
                  log.info(
                      f'DELETE {expired_key["UserName"]}: '
                      f'{expired_key["AccessKeyId"]} '
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'DELETE',
                      'key': expired_key,
                      'reason': reason
                  })
                  # warn if other key is about to be rotated
                  if unexpired_key_rotation_date <= now + warn_period:
                      rotate_reason = ActionReasons.KEY_PENDING_ROTATION
                      log.info(
                          f'WARN {unexpired_key["UserName"]}: '
                          f'{unexpired_key["AccessKeyId"]}'
                          f'-- {rotate_reason.value}')
                      action_queue.append({
                          'action': 'WARN',
                          'action_date': unexpired_key_rotation_date,
                          'key': unexpired_key,
                          'reason': rotate_reason
                      })

              # also warn if unexpired key is about to expire and be rotated
              # expired will be deleted due to conflict
              elif unexpired_key_rotation_date <= now + warn_period:
                  queue = get_delete_rotate_queue(expired_key, unexpired_key, unexpired_key_rotation_date)
                  for q in queue:
                    action_queue.append(q)

              # warn if the grace period is about to end
              elif expired_key_delete_date <= now + warn_period:
                  reason = ActionReasons.KEY_PENDING_DELETION
                  log.info(
                      f'WARN {expired_key["UserName"]}: '
                      f'{expired_key["AccessKeyId"]}'
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': expired_key_delete_date,
                      'key': expired_key,
                      'reason': reason
                  })

          else:
              # nothing to do, both keys have not expired
              # pending expirations don't need warnings,
              # nothing will change until end of grace period
              log.info('Skipping, keys are both valid.')

      elif num_active == 1:
          # we have a key in the recycle bin, waiting to be deleted
          log.info('--Key Logic: [Active, Inactive]')
          if keys[0]['Status'] == 'Active':
              active_key = keys[0]
              inactive_key = keys[1]
          else:
              active_key = keys[1]
              inactive_key = keys[0]

          active_key_rotate_date = active_key['ExpireDate']

          if active_key_rotate_date <= now:
              # the edge case where the active key is expired
              # we should only encounter this on first deploy
              # we have to delete the inactive one
              # so we can rotate the active one
              delete_reason = ActionReasons.EXPIRED_INACTIVE_KEY_CONFLICT
              rotate_reason = ActionReasons.EXPIRED_ACTIVE_KEY
              log.info(
                  f'DELETE {inactive_key["UserName"]}: '
                  f'{inactive_key["AccessKeyId"]} '
                  f'-- {delete_reason.value}')
              log.info(
                  f'ROTATE {active_key["UserName"]}: '
                  f'{active_key["AccessKeyId"]} '
                  f'-- {rotate_reason.value}')
              action_queue.append({
                  'action': 'DELETE',
                  'key': inactive_key,
                  'reason': delete_reason
              })
              action_queue.append({
                  'action': 'ROTATE',
                  'key': active_key,
                  'reason': delete_reason
              })

          else:
              # check if the recovery grace period on the inactive key has passed
              # the trick here is that we use the creation date of the active key
              # to guess when the inactive key was deactivated
              if inactive_key['LastUsedDate'] is not None:
                  # if the key has a more recent last used date use that instead
                  rotation_date = max([active_key['CreateDate'],
                                        inactive_key['LastUsedDate']])
              else:
                  rotation_date = active_key['CreateDate']
              inactive_key_delete_date = rotation_date + \
                                          installation_grace_period + \
                                          recovery_grace_period

              # delete inactive key if grace period is over
              if inactive_key_delete_date <= now:
                  reason = ActionReasons.RECOVER_GRACE_PERIOD_END
                  log.info(
                      f'DELETE {inactive_key["UserName"]}: '
                      f'{inactive_key["AccessKeyId"]} '
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'DELETE',
                      'key': inactive_key,
                      'reason': reason
                  })
                  # warn if active key is about to be rotated
                  if active_key_rotate_date <= now + warn_period:
                      reason = ActionReasons.KEY_PENDING_ROTATION
                      log.info(
                          f'WARN {active_key["UserName"]}: '
                          f'{active_key["AccessKeyId"]}'
                          f'-- {reason.value}')
                      action_queue.append({
                          'action': 'WARN',
                          'action_date': active_key_rotate_date,
                          'key': active_key,
                          'reason': reason
                      })

              # also warn if active key is about to expire
              # inactive key will be deleted due to conflict
              elif active_key_rotate_date <= now + warn_period:
                  delete_reason = ActionReasons.KEY_PENDING_DELETION_CONFLICT
                  rotate_reason = ActionReasons.KEY_PENDING_ROTATION
                  log.info(
                      f'WARN {inactive_key["UserName"]}: '
                      f'{inactive_key["AccessKeyId"]}'
                      f'-- {delete_reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': active_key_rotate_date,
                      'key': inactive_key,
                      'reason': delete_reason
                  })
                  log.info(
                      f'WARN {active_key["UserName"]}: '
                      f'{active_key["AccessKeyId"]}'
                      f'-- {rotate_reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': active_key_rotate_date,
                      'key': active_key,
                      'reason': rotate_reason
                  })

              # warn if inactive key is about to expire
              elif inactive_key_delete_date <= now + warn_period:
                  reason = ActionReasons.KEY_PENDING_DELETION
                  log.info(
                      f'WARN {inactive_key["UserName"]}: '
                      f'{inactive_key["AccessKeyId"]}'
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': inactive_key_delete_date,
                      'key': inactive_key,
                      'reason': reason
                  })

      elif num_active == 2:
          log.info('--Key Logic: [Active, Active]')
          # This means that either a key has been rotated and we are in the
          # install period, or it means that the user has two active keys that
          # need to be evaluated

          num_expired = len([k for k in keys if k['ExpireDate'] <= now])

          if num_expired == 2:
              # This is the catch 22, we have to pick one key to deactivate
              # both are expired and both have been used
              # we have no way to track the grace period if both keys are expired
              # we have to delete one and rotate the other

              delete_reason = ActionReasons.EXPIRED_ACTIVE_KEY_CONFLICT_LRU
              rotate_reason = ActionReasons.EXPIRED_ACTIVE_KEY

              # we choose to delete the least recently used key
              queue = get_lru_delete_rotate_queue (keys, delete_reason, rotate_reason)
              for q in queue:
                action_queue.append(q)
              
              delete_reason = ActionReasons.FORCED_ROTATION_CONFLICT_LRU
              rotate_reason = ActionReasons.FORCED_ROTATION

              # we choose to delete the least recently used key
              queue = get_lru_delete_rotate_queue (keys, delete_reason, rotate_reason)
              for q in queue:
                action_queue.append(q)

          elif num_expired == 1:
              # only one expired
              if keys[0]['ExpireDate'] <= now:
                  expired_key = keys[0]
                  unexpired_key = keys[1]
              else:
                  expired_key = keys[1]
                  unexpired_key = keys[0]

              # we assume the creation date of the other key
              # is the date the key was rotated
              expired_key_rotation_date = unexpired_key['CreateDate']
              expired_key_deactivation_date = expired_key_rotation_date + \
                                              installation_grace_period
              unexpired_key_rotation_date = unexpired_key['ExpireDate']

              # deactivate the expired key if the grace period is ended
              if expired_key_deactivation_date <= now:
                  reason = ActionReasons.INSTALL_GRACE_PERIOD_END
                  log.info(
                      f'DEACTIVATE {expired_key["UserName"]}: '
                      f'{expired_key["AccessKeyId"]} '
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'DEACTIVATE',
                      'key': expired_key,
                      'reason': reason
                  })
                  # warn if the unexpired key is about to expire
                  if unexpired_key_rotation_date <= now + warn_period:
                      reason = ActionReasons.KEY_PENDING_ROTATION
                      log.info(
                          f'WARN {unexpired_key["UserName"]}: '
                          f'{unexpired_key["AccessKeyId"]}'
                          f'-- {reason.value}')
                      action_queue.append({
                          'action': 'WARN',
                          'action_date': unexpired_key_rotation_date,
                          'key': unexpired_key,
                          'reason': reason
                      })

              # warn if the unexpired key is about to be rotated
              # the expired key will be deleted due to conflict
              elif unexpired_key_rotation_date <= now + warn_period:
                  queue = get_delete_rotate_queue(expired_key, unexpired_key, unexpired_key_rotation_date)
                  for q in queue:
                    action_queue.append(q)

              # warn if the expired key is about to be deactivated
              elif expired_key_deactivation_date <= now + warn_period:
                  reason = ActionReasons.KEY_PENDING_DEACTIVATION
                  log.info(
                      f'WARN {expired_key["UserName"]}: '
                      f'{expired_key["AccessKeyId"]}'
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': expired_key_deactivation_date,
                      'key': expired_key,
                      'reason': reason
                  })

          elif num_expired == 0:
              log.info('Keys are both valid.')
              # it's harder than it seems to warn of pending actions
              keys_by_expire_date = sorted(
                  keys, key=lambda x: x['ExpireDate'])
              older_key = keys_by_expire_date[0]
              newer_key = keys_by_expire_date[1]
              older_key_expire_date = older_key['ExpireDate']
              newer_key_rotation_date = newer_key['ExpireDate']

              # warn if newer key is about to expire
              # older will be deleted due to conflict
              if newer_key_rotation_date <= now + warn_period:
                  delete_reason = ActionReasons.KEY_PENDING_DELETION_CONFLICT
                  rotate_reason = ActionReasons.KEY_PENDING_ROTATION
                  log.info(
                      f'WARN {older_key["UserName"]}: '
                      f'{older_key["AccessKeyId"]}'
                      f'-- {delete_reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': newer_key_rotation_date,
                      'key': older_key,
                      'reason': delete_reason
                  })
                  log.info(
                      f'WARN {newer_key["UserName"]}: '
                      f'{newer_key["AccessKeyId"]}'
                      f'-- {rotate_reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': newer_key_rotation_date,
                      'key': newer_key,
                      'reason': rotate_reason
                  })

              # warn if first key will expire
              # it can't be rotated due to conflict
              elif older_key_expire_date <= now + warn_period:
                  reason = ActionReasons.KEY_PENDING_EXPIRATION_CONFLICT
                  log.info(
                      f'WARN {older_key["UserName"]}: '
                      f'{older_key["AccessKeyId"]}'
                      f'-- {reason.value}')
                  action_queue.append({
                      'action': 'WARN',
                      'action_date': older_key_expire_date,
                      'key': older_key,
                      'reason': reason
                  })

  # Return compiled list of remediation options
  return action_queue

def get_lru_delete_rotate_queue(keys, delete_reason, rotate_reason):
  queue = []
  if keys[0]['LastUsedDate'] and keys[1]['LastUsedDate']:
      lru_keys = sorted(keys, key=lambda x: x['LastUsedDate'])
      key_to_delete = lru_keys[0]
      key_to_rotate = lru_keys[1]
      log.info(f"--Key [{key_to_delete['AccessKeyId']}]:"
                f"[{key_to_delete['LastUsedDate']}] was last used "
                f"before Key [{key_to_rotate['AccessKeyId']}]:"
                f"[{key_to_rotate['LastUsedDate']}].")
  # or the one that hasn't ever been used
  elif keys[0]['LastUsedDate']:
      key_to_delete = keys[1]
      key_to_rotate = keys[0]
      log.info(f"--Key [{key_to_delete['AccessKeyId']}] "
                f"has never been used.")
  elif keys[1]['LastUsedDate']:
      key_to_delete = keys[0]
      key_to_rotate = keys[1]
      log.info(f"--Key [{key_to_delete['AccessKeyId']}] "
                f"has never been used.")
  # or the one that was created first if none have been used
  elif keys[0]['CreateDate'] <= keys[1]['CreateDate']:
      key_to_delete = keys[0]
      key_to_rotate = keys[1]
      log.info(f"--Key [{key_to_delete['AccessKeyId']}]:"
                f"[{key_to_delete['CreateDate']}] is older "
                f"than Key [{key_to_rotate['AccessKeyId']}]:"
                f"[{key_to_rotate['CreateDate']}].")
  else:
      key_to_delete = keys[1]
      key_to_rotate = keys[0]
      log.info(f"--Key [{key_to_delete['AccessKeyId']}]:"
                f"[{key_to_delete['CreateDate']}] is older "
                f"than Key [{key_to_rotate['AccessKeyId']}]:"
                f"[{key_to_rotate['CreateDate']}].")

  log.info(
      f'DELETE {key_to_delete["UserName"]}: '
      f'{key_to_delete["AccessKeyId"]} '
      f'-- {delete_reason.value}')
  log.info(
      f'ROTATE {key_to_rotate["UserName"]}: '
      f'{key_to_rotate["AccessKeyId"]} '
      f'-- {rotate_reason.value}')
  queue.append({
      'action': 'DELETE',
      'key': key_to_delete,
      'reason': delete_reason
  })
  queue.append({
      'action': 'ROTATE',
      'key': key_to_rotate,
      'reason': rotate_reason
  })

  return queue

def get_delete_rotate_queue(expired_key, unexpired_key, unexpired_key_rotation_date):
  queue = []
  delete_reason = ActionReasons.KEY_PENDING_DELETION_CONFLICT
  rotate_reason = ActionReasons.KEY_PENDING_ROTATION
  log.info(
      f'WARN {expired_key["UserName"]}: '
      f'{expired_key["AccessKeyId"]}'
      f'-- {delete_reason.value}')
  queue.append({
      'action': 'WARN',
      'action_date': unexpired_key_rotation_date,
      'key': expired_key,
      'reason': delete_reason
  })
  log.info(
      f'WARN {unexpired_key["UserName"]}: '
      f'{unexpired_key["AccessKeyId"]}'
      f'-- {rotate_reason.value}')
  queue.append({
      'action': 'WARN',
      'action_date': unexpired_key_rotation_date,
      'key': unexpired_key,
      'reason': rotate_reason
  })

  return queue

class ActionReasons(Enum):
  UNUSED_EXPIRED_KEY = 'Expired key has never been used.'
  EXPIRED_ACTIVE_KEY = 'Active key has expired.'
  FORCED_ROTATION = 'Forced active key rotation.'
  EXPIRED_ACTIVE_KEY_CONFLICT_LRU = 'Expired active key with conflict, ' \
                                    'least recently used.'
  EXPIRED_INACTIVE_KEY_CONFLICT = 'Expired key with conflict, already ' \
                                  'inactive.'
  FORCED_ROTATION_CONFLICT_LRU = 'Forced active key rotation with conflict, ' \
                                  'least recently used.'
  FORCED_INACTIVE_KEY_CONFLICT = 'Forced rotation with conflict, already ' \
                                  'inactive.'
  INSTALL_GRACE_PERIOD_END = 'Installation grace period has ended.'
  RECOVER_GRACE_PERIOD_END = 'Recovery grace period has ended.'
  KEY_PENDING_ROTATION = 'Key will be rotated soon.'
  KEY_PENDING_DEACTIVATION = 'Key will be deactivated soon, ' \
                              'please install new key.'
  KEY_PENDING_DELETION = 'Key will be permanently deleted soon, ' \
                          'please validate new key.'
  KEY_PENDING_EXPIRATION_CONFLICT = 'Key will expire soon, cannot be ' \
                                    'rotated due to presence of other key.'
  KEY_PENDING_DELETION_CONFLICT = 'Key will be permanently deleted soon, ' \
                                  'due to conflict.'
  UNUSED_KEY_PENDING_DELETION = 'Key will be permanently deleted soon, ' \
                                'key is about to expire and has never' \
                                ' been used.'

def log_actions(action_queue, dryrun=False):
  if not action_queue:
    log.info("No actions to be taken on this account.")
    return

  for action_spec in action_queue:
    action = action_spec['action']
    key_metadata = action_spec['key']
    access_key_id = key_metadata["AccessKeyId"]
    reason = action_spec['reason'].value

    if action == 'ROTATE':
      if dryrun:
        log.info(
            f"Would create new key to replace {access_key_id}"
            f" -- {reason}")
      else:
        log.info(
            f"Creating new key to replace {access_key_id}"
            f" -- {reason}")
    elif action == 'DEACTIVATE':
      if dryrun:
        log.info(
            f"Would deactivate {access_key_id}"
            f" -- {reason}")
      else:
        log.info(
            f"Deactivating {access_key_id}"
            f" -- {reason}")
    elif action == 'DELETE':
      if dryrun:
        log.info(
            f"Would delete {access_key_id}"
            f" -- {reason}")
      else:
        log.info(
            f"Deleting {access_key_id}"
            f" -- {reason}")
    elif action == 'ROTATE_AND_DELETE':
      if dryrun:
        log.info(
            f"Would delete and rotate {access_key_id}"
            f" -- {reason}")
      else:
        log.info(
            f"Deleting and Rorating {access_key_id}"
            f" -- {reason}")
    elif action == 'WARN':
      log.info(
          f"Warning {access_key_id}"
          f" -- {reason}")
    else:
      log.info(f" ** Unrecognized Action {action}")

def execute_actions(action_queue, iam_client):
  action_queue_meta = []
  for action_spec in action_queue:
    action = action_spec['action']
    key_metadata = action_spec['key']

    if action == 'ROTATE':
      new_access_key = rotate_key(key_metadata, iam_client)
      action_spec['new_keyid'] = new_access_key['AccessKeyId']
      action_spec['new_keysecret'] = new_access_key['SecretAccessKey']

      update_github_secret (new_access_key)
      update_terraform_variable (new_access_key)
    elif action == 'DEACTIVATE':
      deactivate_key(key_metadata, iam_client)
    elif action == 'DELETE':
      delete_key(key_metadata, iam_client)
    elif action == 'ROTATE_AND_DELETE':
      delete_key(key_metadata, iam_client)
      new_access_key = rotate_key(key_metadata, iam_client)
      action_spec['new_keyid'] = new_access_key['AccessKeyId']
      action_spec['new_keysecret'] = new_access_key['SecretAccessKey']

      update_github_secret (new_access_key)
      update_terraform_variable (new_access_key)
    
    action_queue_meta.append(action_spec)
    

def rotate_key(key_metadata, iam_client):
  user_name = key_metadata['UserName']
  access_key_id = key_metadata['AccessKeyId']
  log.info(f'Rotating user {user_name} key {access_key_id}')

  # Create new access key
  new_access_key = iam_client.create_access_key(UserName=user_name)['AccessKey']
  new_access_key_str = json.dumps(new_access_key, indent=4, sort_keys=True, default=str)
  log.info(f'New Access Keys for {user_name}: {new_access_key_str}')
  return {'AccessKeyId': new_access_key['AccessKeyId'], 'SecretAccessKey': new_access_key['SecretAccessKey'], 'UserName': new_access_key['UserName']}

def deactivate_key(key_metadata, iam_client):
  user_name = key_metadata['UserName']
  access_key_id = key_metadata['AccessKeyId']
  log.info(f'Deactivating user {user_name} key {access_key_id}')

  iam_client.update_access_key(UserName=user_name, AccessKeyId=access_key_id, Status='Inactive')

def delete_key(key_metadata, iam_client):
  user_name = key_metadata['UserName']
  access_key_id = key_metadata['AccessKeyId']
  log.info(f'Deleting user {user_name} key {access_key_id}')

  iam_client.delete_access_key(UserName=user_name, AccessKeyId=access_key_id)

def send_notification (action_queue, dryrun, environment_str):
  now = datetime.datetime.now(datetime.timezone.utc)
  if dryrun:
    subject = f"{environment_str} DRYRUN: Porter AWS Access Key Rotation"
  else:
    subject = f"{environment_str} Porter AWS Access Key Rotation"

  message = "\n" + subject + "\n\n"
  message += "User".ljust(25, ' ') + "Action".ljust(25, ' ') + "Access Key".ljust(25, ' ') + "Comments".ljust(75, ' ')
  message += "\n" + "-".ljust(150, '-')

  send_notification = False
  for action_spec in action_queue:
    action = action_spec['action']
    key_metadata = action_spec['key']
    user_name = key_metadata['UserName']
    access_key_id = key_metadata["AccessKeyId"]
    reason = action_spec['reason']

    if action != 'WARN':
      comment = reason.value
      if action == 'ROTATE_AND_DELETE' or action == 'ROTATE':
        new_keyid = action_spec.get('new_keyid', 'X')
        new_keysecret = action_spec.get('new_keysecret', 'X')
        comment += f". New Key ID: {new_keyid}, Key Secret: {new_keysecret}"
      message += "\n" + user_name.ljust(25, ' ') + action.ljust(25, ' ') + access_key_id.ljust(25, ' ') + comment.ljust(75, ' ')
      send_notification = True
    else:
      send_notification = str(os.getenv('KEYROTATION_SEND_WARN_EMAIL')).lower() == 'true'
      action_date = action_spec['action_date']
      delta = action_date - now
      delta_days = round(delta.total_seconds() / 86400)
      comment = reason.value
      if reason == ActionReasons.KEY_PENDING_ROTATION:
        comment = f'Key will expire in {delta_days} days and will be rotated'
      elif reason == ActionReasons.KEY_PENDING_DEACTIVATION:
        comment = f'Key will deactivated in {delta_days} days'
      elif reason == ActionReasons.KEY_PENDING_DELETION:
        comment = f'Key will permanently deleted in {delta_days} days'
      elif reason == ActionReasons.UNUSED_KEY_PENDING_DELETION:
        comment = f'Key has never been used and will permanently deleted in {delta_days} days'
      elif reason == ActionReasons.KEY_PENDING_EXPIRATION_CONFLICT:
        comment = f'Key cannot be rotated because another key exists for the user'
      elif reason == ActionReasons.KEY_PENDING_DELETION_CONFLICT:
        comment = f'Key will be permanently deleted in {delta_days} days due to a conflict with another key for the user' 

      message += "\n" + user_name.ljust(25, ' ') + action.ljust(25, ' ') + access_key_id.ljust(25, ' ') + comment.ljust(75, ' ')

  log.info(message)

  if send_notification == True:
    sns_client = boto3.client('sns')
    response = sns_client.publish(
      TopicArn=os.getenv('TOPIC_ARN'),
      Message=message,
      Subject=subject
    )

    log.info("Message sent to SNS Topic: " + response['MessageId'])

def update_github_secret (access_key):
  iam_github_username = os.getenv('GITHUB_AWS_USERNAME')
  github_token = os.getenv('GITHUB_PUBLIC_KEY')
  github_repos_str = os.getenv('GITHUB_REPOSITORIES')
  if len(github_repos_str) > 0:
      github_repos = github_repos_str.split(",")
  else:
      github_repos = []
  github_keyid_varname = os.getenv('GITHUB_AWS_ACCESS_KEYID')
  github_keysecret_varname = os.getenv('GITHUB_AWS_ACCESS_KEYSECRET')
  
  current_username = access_key["UserName"]
  log.info(f"update_github_secret - username: {current_username}")

  if current_username == iam_github_username:
    log.info(f"update_github_secret - Repositories: {github_repos_str}")
    log.info(f"update_github_secret - Github KeyID: {github_keyid_varname}")
    log.info(f"update_github_secret - Github KeySecret: {github_keysecret_varname}")

    http = urllib3.PoolManager()
    # Update AWS Access Key and Secret in GitHub Repositories
    for repo in github_repos:
      log.info (f"Updating secret for repository - {repo}")

      repo_req_url = "https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/public-key"
      github_req_headers = {
        "User-Agent": "helloporter/aws-key-rotation/2.0", 
        "Accept": "application/vnd.github+json", 
        "Authorization": "Bearer " + github_token, 
        "X-GitHub-Api-Version": "2022-11-28"
      }
      repo_res = http.request ("GET", repo_req_url, headers=github_req_headers)
      if repo_res.status == 200:
        github_pubkey = json.loads(repo_res.data)
        log.info(f"--GitHub Key for Repo {repo}: " + json.dumps(github_pubkey))

        # Encrypt AWS Access Key ID and Secret
        aws_access_keyid = access_key['AccessKeyId']
        aws_access_keysecret = access_key['SecretAccessKey']

        log.info(f"-- Encrypting AWS Access KeyID {aws_access_keyid}")
        enc_access_keyid = github_encrypt_secrets(github_pubkey['key'], aws_access_keyid)
        log.info(f"-- Encrypted AWS Access KeyID {enc_access_keyid}")

        log.info(f"-- Encrypting AWS Access KeySecret {aws_access_keysecret}")
        enc_access_keysecret = github_encrypt_secrets(github_pubkey['key'], aws_access_keysecret)
        log.info(f"-- Encrypted AWS Access KeySecret {enc_access_keysecret}")

        # Update AWS Access KeyID and Secret to GitHub
        keyid_res = http.request ("PUT", 
          "https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/" + github_keyid_varname,
          body=json.dumps({"key_id": github_pubkey['key_id'], "encrypted_value": enc_access_keyid}),
          headers=github_req_headers
        )
        if keyid_res.status == 201 or keyid_res.status == 204:
          log.info(f"-- AWS Access KeyID {github_keyid_varname} updated successfully")
        else:
          log.info(f"-- Error while updating {github_keyid_varname} value: " + str(keyid_res.status) + ", Response: " + str(keyid_res.data))

        keysecret_res = http.request ("PUT", 
          "https://api.github.com/repos/hello-porter/" + repo + "/actions/secrets/" + github_keysecret_varname,
          body=json.dumps({"key_id": github_pubkey['key_id'], "encrypted_value": enc_access_keysecret}),
          headers=github_req_headers
        )
        if keysecret_res.status == 201 or keyid_res.status == 204:
          log.info(f"-- AWS Access KeySecret {github_keysecret_varname} updated successfully")
        else:
          log.info(f"-- Error while updating {github_keysecret_varname} value: " + str(keysecret_res.status) + ", Response: " + str(keysecret_res.data))
      else:
        log.info(f"-- GitHub Key for Repo {repo}: Error while fetching, Status: " + str(repo_res.status) + ", Response: " + str(repo_res.data))
  else:
    log.info(f"update_github_secret - username: {current_username} is not a GitHub user")

def update_terraform_variable (access_key):
  iam_terraform_username = os.getenv('TERRAFORM_AWS_USERNAME')
  terraform_token = os.getenv('TERRAFORM_API_TOKEN')
  terraform_keyid_varname = os.getenv('TF_AWS_ACCESS_KEYID')
  terraform_keysecret_varname = os.getenv('TF_AWS_ACCESS_KEYSECRET')

  current_username = access_key["UserName"]
  log.info(f"update_terraform_variable - username: {current_username}")

  if current_username == iam_terraform_username:
    log.info(f"update_terraform_variable - Terraform KeyID: {terraform_keyid_varname}")
    log.info(f"update_terraform_variable - Terraform KeySecret: {terraform_keysecret_varname}")

    http = urllib3.PoolManager()

    keyid_res = http.request ("PATCH", 
      "https://app.terraform.io/api/v2/vars/" + terraform_keyid_varname,
      body=json.dumps({"data":{"id":terraform_keyid_varname,"attributes":{"value":access_key['AccessKeyId']},"type":"vars"}}),
      headers={"Content-Type": "application/vnd.api+json", "Authorization": "Bearer " + terraform_token}
    )

    if keyid_res.status == 201 or keyid_res.status == 204:
      log.info(f"-- AWS Access KeyID {terraform_keyid_varname} updated successfully")
    else:
      log.info(f"-- Error while updating {terraform_keyid_varname} value: " + str(keyid_res.status) + ", Response: " + str(keyid_res.data))

    keysecret_res = http.request ("PATCH", 
      "https://app.terraform.io/api/v2/vars/" + terraform_keysecret_varname,
      body=json.dumps({"data":{"id":terraform_keysecret_varname,"attributes":{"value":access_key['SecretAccessKey']},"type":"vars"}}),
      headers={"Content-Type": "application/vnd.api+json", "Authorization": "Bearer " + terraform_token}
    )

    if keysecret_res.status == 201 or keysecret_res.status == 204:
      log.info(f"-- AWS Access KeySecret {terraform_keysecret_varname} updated successfully")
    else:
      log.info(f"-- Error while updating {terraform_keysecret_varname} value: " + str(keysecret_res.status) + ", Response: " + str(keysecret_res.data))
  else:
    log.info(f"update_terraform_variable - username: {current_username} is not a Terraform user")

def github_encrypt_secrets(public_key: str, secret_value: str) -> str:
  public_key = public.PublicKey(public_key.encode("utf-8"), encoding.Base64Encoder())
  sealed_box = public.SealedBox(public_key)
  encrypted = sealed_box.encrypt(secret_value.encode("utf-8"))
  return b64encode(encrypted).decode("utf-8")