from base64 import b64encode
import datetime
import json
from codecs import getencoder
import dateutil.parser
import uuid
import requests
import http.client
import secrets
import string
import time
dynamo_uuid=''
from io import StringIO
import mimetypes
from codecs import encode
from dateutil.parser import parse
import os
import re
import boto3
from boto3.dynamodb.conditions import Key
from functions_process import createMemberData, createEnrollmentData, createHomeAddData, createContactData, createMailingAddData
from sf_generate_token import generateAccessTokenSF
region_name = 'us-east-1'
createEHRFlag = ''
MBI = ''
File=''
response_status =''
acc_create = ''
mbi = ''
# programName = 'CF-TRC-2023'
# payer = "Carefirst"
practice = "Athena Health"
current_data = datetime.datetime.today().strftime('%Y-%m-%d')


###

session = requests.Session()
session.trust_env = False
 

def lambda_handler(event, context):
    authHost = os.environ.get('authHost')
    sf_file_api = os.environ.get('sf_file_api')
    client_id = os.environ.get('client_id')
    sf_profilesync_url = os.environ.get('sf_profilesync_url')
    queue_url = os.environ.get('queue_url')
    for record in event["Records"]:
        row = record['body']
        row = json.loads(row)
        key_list = row.keys()
    
    
        def get_secret():
            secretId = os.environ["ATHENA_ID"]
            region_name = os.environ["REGION"]
    
            session = boto3.session.Session()
            
            client = session.client(
                service_name='secretsmanager',
                region_name=region_name,
            )
            
            session_token = client.get_secret_value(
                SecretId=secretId
            )
            
            return json.loads(session_token["SecretString"]).get(secretId, "")
            
        #### changes for date
        def is_date(date, fuzzy=False):
            if str(date) == 'None' or str(date) == '' or str(date) is None:
                date=''
            try: 
                dt = parse(date)
                parse(date, fuzzy=fuzzy)
                val = True
                if dt.strftime('%Y') == '9999':
                    val = False
                return val
            except ValueError:
                return False
        
        
        ###
        
        def formatDate(date):
            #str(row['DateOfBirth'])
            date = str(date)
            dt = datetime.datetime.strptime(date, "%Y-%m-%d").strftime("%m/%d/%Y")
            return dt
    
        def formatDateSF(date) :
            dt =''
            if str(date) == 'None' or str(date) == '' or str(date) is None:
                date=''
            else:
                date = str(date)
                dt = parse(date)
                dt = dt.strftime('%Y-%m-%d')
            return dt
        
        def formatGender(gender):
        
            if gender.lower() == 'male' or gender.lower() ==  'm':
                gender = 'Male'
            if gender.lower() == 'female' or gender.lower() ==  'f':
                gender = 'Female'
            return gender
        
        sf_token = generateAccessTokenSF()
        region_name = 'us-east-1'
        sqs = boto3.client('sqs', region_name=region_name)
        
    
    
        headers = {
                    'Content-Type': 'application/json', # "application/x-www-form-urlencoded" , #
                    'Authorization': 'Bearer ' + sf_token
                }
    
    
        
        
        def basic_auth(username, password):
            token = b64encode(f"{username}:{password}".encode('utf-8')).decode("ascii")
            return f'Basic {token}'
        
        def generateEHRToken():
            token_data = {}
            auth_1 = basic_auth(client_id, get_secret())
            payload = 'grant_type=client_credentials&scope=athena/service/Athenanet.MDP.*'
            conn = http.client.HTTPSConnection(authHost)
            headers = { 
               'Authorization' : auth_1,
               'content-type': "application/x-www-form-urlencoded"
            }
            response = tokentable.query(KeyConditionExpression=Key('id').eq('EHR'))
            if len(response['Items'])  > 0:
                token_response = response['Items'][0]
                if ((int(time.time())) - (int(token_response['ts'])) < 3000): 
                    access_token = token_response['token']
                    print('from table')
                else:
                    conn.request("POST", "/oauth2/v1/token", payload, headers)
                    res = conn.getresponse()
                    data = res.read()
                    data = json.loads(data)
                    token_data['token'] = data['access_token']
                    access_token = data['access_token']
                    token_data['id'] = 'EHR'
                    token_data['ts'] = str(int(time.time()))
                    tokentable.put_item(Item=token_data)
                    print('creating')
            else:
                print('empty')
                conn.request("POST", "/oauth2/v1/token", payload, headers)
                res = conn.getresponse()
                data = res.read()
                data = json.loads(data)
                token_data['token'] = data['access_token']
                access_token = data['access_token']
                token_data['id'] = 'EHR'
                token_data['ts'] = str(int(time.time()))
                tokentable.put_item(Item=token_data)
                print('creating-2')
            return access_token
        
        # def postEHRPatient(payload_data):
        #     tokendata = generateEHRToken()
        #     #print(tokendata)
        #     #time.sleep(1)
        #     print(tokendata, 'checking ehr token')
        #     # if(tokendata):
        #     #     tokendata = tokendata
        #     # else:
        #     #     time.sleep(3)
        #     #     print('waiting....')
        #     #     tokendata = generateEHRToken()
    
                
        #     patientURL =  os.environ.get('patientURL')
            
        #     post_headers = {
        #         "Accept": "application/json",
        #         "Authorization" : "Bearer " + tokendata ,
        #         "Content-Type" : "application/x-www-form-urlencoded"
        #     }
        #     response = requests.request("POST", patientURL, headers=post_headers, data=payload_data)
        #     print(response)
        #     return response.text
            
        
        
        
        region_name = 'us-east-1'
        dynamodb = boto3.resource('dynamodb', region_name=region_name)
        membertable = dynamodb.Table(os.environ['MemberDetailsTable'])
        tokentable = dynamodb.Table(os.environ['MemberTestToken'])
        enroltable =  dynamodb.Table(os.environ['EnrollmentDetailsTable']) 
        addresstable =  dynamodb.Table(os.environ['MemberAddressTable']) 
        contacttable =  dynamodb.Table(os.environ['MemberContactTable']) 
        mappingtable =  dynamodb.Table(os.environ['MiddlewareMemberMappingTable']) 
        exceptiontable =  dynamodb.Table(os.environ['MemberFileExceptionsTable']) 
        
        customerTable =  dynamodb.Table(os.environ['MemberCustomerDetailsTable']) 
        programTable =  dynamodb.Table(os.environ['MemberProgramDetailsTable']) 
        ###
        current_date = datetime.datetime.today().strftime('%Y,%m,%d')
        password_auto = secrets.token_urlsafe(32)
       
        
        def formatphone(phonenumber):
            
            print('phone', phonenumber )
            if phonenumber == '' or phonenumber is  None or phonenumber == 'None':
                phonenumber = '9999999999'
            else:
                phonenumber = str(phonenumber)
                phonenumber = re.sub('\D', '', phonenumber)
            print('phone after', phonenumber )
            
            return phonenumber
        
        def checkMemberLifeID(MemberLifeID):
            MBITocheck = MemberLifeID
            response = membertable.query(KeyConditionExpression=Key('MemberLifetimeID').eq(MBITocheck), IndexName='MemberLifetimeID-index')
            if len(response['Items'])  > 0:
                resp = True
            else:
                resp = False
                #dynamo_uuid = response['Items'][0]['uu
            return resp

        
        def checkMBI(MBI):
            MBITocheck = MBI
            response = membertable.query(KeyConditionExpression=Key('MBI').eq(MBITocheck), IndexName='MBI-index')
            if len(response['Items'])  > 0:
                resp = True
            else:
                resp = False
                #dynamo_uuid = response['Items'][0]['uu
            return resp
        
        # def checkMapping(MBI):
        #     MBITocheck = MBI
        #     response = mappingtable.query(KeyConditionExpression=Key('MBI').eq(MBITocheck), IndexName='MBI-index')
        #     if len(response['Items'])  > 0:
        #         dynamo_uuid = response['Items'][0]
        #     else:
        #         dynamo_uuid =''
        
        #     return dynamo_uuid
            
        def checkMapping(MBI):
            MBITocheck = MBI
            response = membertable.query(KeyConditionExpression=Key('MemberLifetimeID').eq(MBITocheck), IndexName='MemberLifetimeID-index')
            if len(response['Items'])  > 0:
                dynamo_uuid = response['Items'][0]
            else:
                dynamo_uuid =''
            return dynamo_uuid
        
        def getEhrSFTag(uuid):
            uuid = uuid
            response = mappingtable.query(KeyConditionExpression=Key('uuid').eq(uuid))
            if len(response['Items'])  > 0:
                mapped_dt = response['Items'][0]
            else:
                mapped_dt =''
            return mapped_dt
            
        
        def checkProgran(programName, Customer):
            programName = programName
            Customer = Customer
            #response = customerTable.query(KeyConditionExpression=Key('ProgramName').eq(programName), IndexName='ProgramName-index')
            fe = Key('ProgramName').eq(programName) & (Key('Customer').eq(Customer))  
            response = customerTable.scan(FilterExpression=fe)
            if len(response['Items'])  > 0:
                dynamo_uuid = response['Items'][0]
                customer = dynamo_uuid['Customer']
                practice_id = dynamo_uuid['PracticeID']
                departmentid = dynamo_uuid['DepartmentID']
            else:
                customer =''
                practice_id = ""
                departmentid = ""
            return customer, practice_id, departmentid
            
    
        
        def getUuid(email_to_check):
            EmailTocheck = email_to_check
            response = membertable.query(KeyConditionExpression=Key('EmailAddress').eq(EmailTocheck), IndexName='EmailAddress-index')
            if len(response['Items'])  > 0:
                dynamo_uuid = response['Items'][0]
            else:
                dynamo_uuid =''
            return dynamo_uuid
        
        def getUuid2(MBITocheck):
            MBITocheck = MBITocheck
            #response = membertable.query(KeyConditionExpression=Key('EmailAddress').eq(EmailTocheck), IndexName='EmailAddress-index') 
            response = membertable.query(KeyConditionExpression=Key('MemberLifetimeID').eq(MBITocheck), IndexName='MemberLifetimeID-index')
            if len(response['Items'])  > 0:
                dynamo_uuid = response['Items'][0]['uuid']
            else:
                dynamo_uuid =''
            return dynamo_uuid
    
        def getData(fname, lname, DOB):
            fname = str(fname)
            lname = str(lname)
            DOB = str(DOB)
            DOB = parse(DOB)
            DOB = DOB.strftime('%Y-%m-%d')
            fe = Key('FirstName').eq(fname) & (Key('LastName').eq(lname)) & (Key('DateOfBirth').eq(DOB)) 
            response = membertable.scan(FilterExpression=fe)
            if len(response['Items'])  > 1:
                dynamo_uuid = response['Items']
            else:
                dynamo_uuid =''
            return dynamo_uuid
    
        def postEHRPatient(payload_data, practice_id):
            tokendata = generateEHRToken()
            print(tokendata, 'checking ehr token')
            patientURL_sub =  os.environ.get('patientURL')
            new_update = '/'.join(patientURL_sub.rsplit('/',)[0:-2])
            patientURL = str(new_update) + "/"  + str(practice_id) + "/" + "patients"
            post_headers = {
                "Accept": "application/json",
                "Authorization" : "Bearer " + tokendata ,
                "Content-Type" : "application/x-www-form-urlencoded"
            }
            print('patient url is :', patientURL)
            response = session.request("POST", patientURL, headers=post_headers, data=payload_data)
            print(response)
            return response.text


        def processDataSource(row, key_list):
            print(type(row), 'printing type')
            mbi = str(row['MBI'])
            process_status =''
            #for index, row in df.iterrows():
            programName = row['program_name']
            print(programName)
            #programName = "CF-TRC-2023"
            Customer = row['customer_name']
            customer, practice_id, departmentid = checkProgran(programName, Customer)
            if departmentid != "":
                dynamo_uuid = uuid.uuid4()
                ClientMemberId = str(row['ClientMemberID'])
                ClientMemberId = str(ClientMemberId)
                mbi = str(row['MBI'])
                MemberLifeID = str(row['MemberLifeID'])
                mbi = str(mbi)
                if checkMemberLifeID(MemberLifeID) == True:
                    mapping = {}
                    process_status = 'Member Idetifier already exist'
                    existingUUID = getUuid2(MemberLifeID)
                    existingUUID = str(existingUUID)
                    print('pulling uuid', existingUUID)
                    program_details = {"uuid" : existingUUID,  "ProgramName" : str(programName), "Customer" : customer, "Active":1, "DateImported" : current_data}
                    programTable.put_item(Item=program_details)
                    enrollmentData = createEnrollmentData(row, key_list, existingUUID)
                    print(enrollmentData)
                    enroltable.put_item(Item=enrollmentData)
                    map_exist = getEhrSFTag(existingUUID)
                    if map_exist == '':
                        mapping = {"uuid" : str(existingUUID),  "ucAccountId" : "NC", "SFAccount" : "NC", "athenaId" : "NC", "cognitoId": "NC", "departmentId" : departmentid, "ClientMemberId" : ClientMemberId,  "DateImported" : current_data}
                        print('mapping not exist will insert row in mapping')
                        mappingtable.put_item(Item=mapping)
                    else:
                        print('skipping duplicate mapping')
                    HomeAddData = createHomeAddData(row, key_list, existingUUID)
                    addresstable.put_item(Item=HomeAddData)
                    MailingAddData = createMailingAddData(row, key_list, existingUUID)
                    addresstable.put_item(Item=MailingAddData)
                    ContactmentData = createContactData(row, key_list, existingUUID)
                    contacttable.put_item(Item=ContactmentData)
                    exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "middleware_processing", "status" : "Duplicate MBI", "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                    #sqs.send_message(QueueUrl=queue_url,MessageBody=(str({"mbi" : mbi, "stage" : "middleware_processing", "status" : "Duplicate MBI", "filename" : str(row["File"]) , "captured_date" : str(current_date) })))
                elif checkMemberLifeID(MemberLifeID) == False:
                    print(dynamo_uuid)
                    memberData = createMemberData(row, key_list, dynamo_uuid)
                    print(memberData)
                    membertable.put_item(Item=memberData)
                    #time.sleep(1)
                    enrollmentData = createEnrollmentData(row, key_list, dynamo_uuid)
                    print(enrollmentData)
                    enroltable.put_item(Item=enrollmentData)
                    HomeAddData = createHomeAddData(row, key_list, dynamo_uuid)
                    addresstable.put_item(Item=HomeAddData)
                    MailingAddData = createMailingAddData(row, key_list, dynamo_uuid)
                    addresstable.put_item(Item=MailingAddData)
                    ContactmentData = createContactData(row, key_list, dynamo_uuid)
                    contacttable.put_item(Item=ContactmentData)
                    mapping = {"uuid" : str(dynamo_uuid),  "ucAccountId" : "NC", "SFAccount" : "NC", "athenaId" : "NC", "cognitoId": "NC", "departmentId" : departmentid, "ClientMemberId" : ClientMemberId,  "DateImported" : current_data}
                    print(mapping)
                    mappingtable.put_item(Item=mapping)
                    program_details = {"uuid" : str(dynamo_uuid),  "ProgramName" : str(programName), "Customer" : customer, "Active":1, "DateImported" : current_data}
                    programTable.put_item(Item=program_details)
                    #time.sleep(1)
                    process_status = 'New account added'
                else:
                    exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "middleware_processing", "status" : "Index throughput issue", "filename" : str(row["File"]) , "captured_date" : str(current_date)})

            else:
                exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "middleware_processing", "status" : "No Matching program in customer table", "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                sqs.send_message(QueueUrl=queue_url,MessageBody=(str({"mbi" : mbi, "stage" : "middleware_processing", "status" : "No Matching program in customer", "filename" : str(row["File"]) , "captured_date" : str(current_date) })))
            return  process_status
        
        
        
        ########## new SF function
        def createSFDataFile(row):
            print(type(row))
            #row = json.loads(row)
            row = {k: v or '' for (k, v) in row.items()}
            mbistatus=''
            accountObject = {}
            pcpdata = {}
            sf_list =[]
            mbi = str(row['MBI'])
            programName = row['program_name']
            #programName = "CF-TRC-2023"
            Customer = row['customer_name']
            customer, practice_id, departmentid = checkProgran(programName, Customer)
            if departmentid != "":
                print('mbi', mbi)
                MemberLifetimeID = str(row['MemberLifeID'])
                phone_number = formatphone(row['TelephoneNumber1'])
                phone_number = re.sub('\D', '', phone_number)
                proxy_email = "invalid_" + MemberLifetimeID + "@helloporter.com"
                uuidData = checkMapping(MemberLifetimeID)
                if uuidData =='':
                    mbistatus = 'does not exist process file first'
                else:
                    uuid_ft = uuidData['uuid']
                    mappingData = getEhrSFTag(uuid_ft)
                    SFTag = mappingData['SFAccount']
                    map_uuid = mappingData['uuid']
                    if SFTag != '':
                        if (row['EmailAddress']):
                                email_address = row['EmailAddress']
                        else:
                            email_address = proxy_email
                        accountObject ={}
                        accountObject["mbiNumber"] = int(row['MemberLifeID'])
                        accountObject["lastName"] = (row['LastName'])
                        accountObject["firstName"] = (row['FirstName'])
                        accountObject["middleName"] = (row['MiddleName'])
                        #accountObject["mbiNumber"] = int(row['MBI'])
                        enrollStartDate1 = formatDateSF(row['EligibilityStartDate']) 
                        valid  = is_date(enrollStartDate1)
                        if valid == True:
                            accountObject["eligStartDate"] = formatDateSF(row['EligibilityStartDate']) 
                        accountObject["dob"] = formatDateSF(row['DateOfBirth']) 
                        accountObject["gender"] =  formatGender(row['Gender'])
                        accountObject["address1"] =  row['HomeStreet1']
                        accountObject["address2"] =  row['HomeStreet2']
                        accountObject["city"] =  row['HomeCity']
                        accountObject["state"] = row['HomeState']
                        accountObject["zip"] = int(row['HomeZip'])
                        accountObject["phone"] =  phone_number
                        if len(row['CMSNumber']) > 5:
                            cntr = ''
                        else:
                            cntr = row['CMSNumber']
                        accountObject["hContract"] = cntr
                        accountObject["memberId"] = row['ClientMemberID']
                        #accountObject["lastVisit"] = "1989-01-01"
                        accountObject["email"] = email_address
                        accountObject["programName"] = programName
                        accountObject["payer"] = customer
                        ####
                        accountObject["uuid"] = map_uuid
                        accountObject["shippingStreet"] = row['MailingStreet1'] + ' ' + row['MailingStreet2']
                        accountObject["shippingCity"] = str(row['MailingCity'])
                        accountObject["shippingState"] = str(row['MailingState'])
                        accountObject["shippingZip"] = str(row['MailingZip'])
                        accountObject["shippingCountry"] = "US"
                        #accountObject["primaryInsuranceCarrier"] = ''
                        accountObject["primarySubscriberFirstName"] = str(row['FirstName'])
                        accountObject["primarySubscriberLastName"] = str(row['LastName'])
                        accountObject["primarySubscriberDOB"] = formatDateSF(row['DateOfBirth']) 
                        accountObject["primaryInsuranceMemberID"] = row["ClientMemberID"]
                        enrollStartDate = formatDateSF(row['EligibilityStartDate']) 
                        valid  = is_date(enrollStartDate)
                        if valid == True:
                            accountObject["enrollmentStartDate"] = formatDateSF(row['EligibilityStartDate']) 
                        enrollEndDate = formatDateSF(row['EligibilityEndDate']) 
                        valid  = is_date(enrollEndDate)
                        if valid == True:
                            accountObject["enrollmentEndDate"] = formatDateSF(row['EligibilityEndDate']) 
                        #accountObject["disenrollmentDate"] = "Carefirst" //
                        #accountObject["benefitStatus"] = "" //
                        accountObject["primaryInsuranceContractNumber"] =  row["CMSNumber"] 
                        accountObject["planID"] = row['SubGroupID']  
                        accountObject["planBenefitID"] =  row['PBPNumber'] 
                        #accountObject["planNetworkType"] = "" //
                        accountObject["groupName"] = row['GroupName'] 
                        accountObject["groupID"] = row['GroupID'] 
                        #accountObject["primaryPolicySpecifics"] = "" //
                        #accountObject["primaryPlanGroupInformation"] = "" //
                        ####
                        pcpdata = {}
                        # pcpdata["memberId"] = row['ClientMemberID']
                        # pcpdata["name"] =  row['FirstName'] + ' ' + row['LastName']
                        # effDate = formatDateSF(row['PCPStartDate'])
                        # valid  = is_date(effDate)
                        # if valid == True:
                        #     pcpdata["effDate"] = formatDateSF(row['PCPStartDate'])
                        # pcpdata["npi"] = row['ClientProviderID']
                        # pcpdata["practice"] = "Athena Health"
                        accountObject["pcp"] = pcpdata
                        sf_list.append(accountObject)
                        #sf_list = str(sf_list)
                        sf_list = json.dumps(sf_list)
                        #sf_list = json.loads(sf_list)
                        print(sf_list)
                        response = session.post(sf_file_api, data=sf_list , headers=headers)
                        resp = str(response)
                        print(response)
                        response = response.text
                        print(response)
                        
                        jsonResponse = json.loads(response)
                        if len(jsonResponse) > 0:
                            print(type(jsonResponse))
                            if type(jsonResponse) is list:
                                resData = jsonResponse[0]
                                if resData['StatusCode'] == 200:
                                    sf_id = resData['Id']
                                    mappingData['SFAccount']  = str(sf_id)
                                    print(mappingData)
                                    mappingtable.put_item(Item=mappingData)
                                    print(sf_id)
                                elif resData['StatusCode'] != 200 :
                                    exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "SF Account creation", "status" : response, "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                            elif resp != '<Response [200]>':
                                exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "SF Account creation", "status" : response, "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                        print(response)
                        mbistatus = 'SF account created'
                    else:
                        mbistatus = 'No records to be created'
            else:
                exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "SF Account creation", "status" : "Program Name/customerName not matching  or invalid departmentID", "filename" : str(row["File"]) , "captured_date" : str(current_date)})

            return mbistatus
        
        ######
        def createSFData(data):
            sfPayload = {}
            accountObject = {}
            Addresses =[]
            mailingAddress = {}
            homeAddress = {}
            insuranceCompanies =[]
            insurance = {}
            mbistatus =''
            #for index, row in df.iterrows():
            phone_number = str(row['TelephoneNumber1'])
            phone_number = re.sub('\D', '', phone_number)
            mbi = str(row['MBI'])
            print('printing mbi' , mbi)
            proxy_email = "proxy_" + mbi + "@porter.com"
            mappingData = checkMapping(mbi)
            if mappingData =='':
                mbistatus = 'does not exist process file first'
            else:
                SFTag = mappingData['SFAccount']
                map_uuid = mappingData['uuid']
                if SFTag == 'NC':
                    if (row['EmailAddress']):
                        email_address = row['EmailAddress']
                    else:
                        email_address = proxy_email
                    dt = parse(str(row['DateOfBirth']))
                    dt = dt.strftime('%m/%d/%Y')
                    print('BOD', dt)
                    accountObject["ucAccountId"] =  str(map_uuid)
                    accountObject["firstName"] = str(row['FirstName'])
                    accountObject["lastName"] = row['LastName']
                    accountObject["shortRef"] = ""
                    accountObject["email"] = str(email_address)
                    accountObject["dob"] = dt.strip() ### #row['DateOfBirth'] #str(formatDate(row['DateOfBirth']))
                    accountObject["sex"] =  formatGender(row['Gender'])
                    accountObject["phone"] = phone_number #row['TelephoneNumber1']
                    #accountObject["membership"] = mbi
                    homeAddress["nickname"] = 'Home'
                    homeAddress["firstName"] = str(row['FirstName'])
                    homeAddress["lastName"] = row['LastName']
                    homeAddress["street1"] = row['HomeStreet1']
                    homeAddress["street2"] = row['HomeStreet2']
                    homeAddress["city"] = row['HomeCity']
                    homeAddress["state"] = row['HomeState']
                    homeAddress["zip"] = row['HomeZip']
                    homeAddress["countryCode"] = 'US'
                    homeAddress["phone"] = row['TelephoneNumber1']
                    homeAddress["email"] = ''
                    homeAddress["type"] = 'default'
                    homeAddress["ucAddressId"] = ''
                    mailingAddress["nickname"] = 'mailing'
                    mailingAddress["firstName"] = str(row['FirstName'])
                    mailingAddress["lastName"] = row['LastName']
                    mailingAddress["street1"] = row['MailingStreet1']
                    mailingAddress["street2"] = row['MailingStreet2']
                    mailingAddress["city"] = row['MailingCity'] 
                    mailingAddress["state"] = row['MailingState']
                    mailingAddress["zip"] = row['MailingZip']
                    mailingAddress["countryCode"] = 'US'
                    mailingAddress["phone"] = row['TelephoneNumber1']
                    mailingAddress["email"] = ''
                    mailingAddress["type"] = ''
                    mailingAddress["ucAddressId"] = ''
                    Addresses.append(homeAddress)
                    Addresses.append(mailingAddress)
                    accountObject['Addresses'] = Addresses
                    #accountObject['Addresses'] = ''
                    insurance['policyHolderFirstName'] = str(row['FirstName'])
                    insurance['policyHolderLastName'] = row['LastName']
                    insurance['policyHolderDOB'] = dt
                    insurance['memberId'] = row['ClientMemberID']
                    insurance['carrier']   =''  #PreferredPlanName NetworkProvider ClientProviderID EligibilityGroup PlanID  SubscriberId
                    insurance['contractNumber'] = ''   
                    insuranceCompanies.append(insurance)
                    accountObject['insuranceCompanies'] = insuranceCompanies
                    sfPayload = {}
                    requestObject= {}
                    requestObject['accountObject'] = accountObject
                    sfPayload["requestObject"] = requestObject
                    sfPayload = json.dumps(sfPayload)
                    response = session.put(sf_profilesync_url, data=sfPayload , headers=headers)
                    print(response)
                    response = response.text
                    jsonResponse = json.loads(response)
                    print(jsonResponse)
                    if 'status'  in jsonResponse.keys():
                        if jsonResponse['status']== 'Success!':
                            sfAccountId = jsonResponse['accountObject']['sfAccountId']
                            print(sfAccountId)
                            mappingData['SFAccount']  = str(sfAccountId)
                            mappingtable.put_item(Item=mappingData)
                            mbistatus = 'SF account created'
                    else:
                        exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "Salesforce_account_creation", "status" : response.text, "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                        sqs.send_message(QueueUrl=queue_url,MessageBody=(str({"mbi" : mbi, "stage" : "Salesforce_account_creation", "status" : response.text , "filename" : str(row["File"]) , "captured_date" : str(current_date)})))
                        mbistatus = 'Error creating EHR Account'
                else:
                    mbistatus = 'No records to be created'
        
            return mbistatus
    
    
    
    
        def createEHR(data):
            mbistatus=''
            mbi = str(row['MBI'])
            programName = row['program_name']
            Customer = row['customer_name']
            customer, practice_id, departmentid = checkProgran(programName, Customer)
            if practice_id !="":
                mbistatus = []
                #for index, row in df.iterrows():
                mbi = str(row['MBI'])
                MemberLifetimeID = str(row['MemberLifeID'])
                uuidData = checkMapping(MemberLifetimeID)
                print(uuidData)
                if uuidData =='':
                    status = mbi + ' does not exist process file first'
                    mbistatus.append(status)
                else:
                    scanned = getData(str(row['FirstName']),str(row['LastName']), str(row['DateOfBirth']))
                    uuid_ft = uuidData['uuid']
                    mappingData = getEhrSFTag(uuid_ft)
                    ehrTag = mappingData['athenaId']
                    if scanned =='':
                        ehrTag = mappingData['athenaId']
                        if ehrTag == 'NC':
                            dt = parse(str(row['DateOfBirth']))
                            dt = dt.strftime('%m/%d/%Y')
                            print('EHR DOB', dt)
                            print(ehrTag, ' ', mbi)
                            payload_data = {}
                            #print(row)
                            #payload_data["middlename"] = row['MiddleName']
                            #payload_data["povertylevelfamilysize"] = ""
                            payload_data["lastname"] =  row['LastName']
                            payload_data["countrycode"] = "US"
                            payload_data["zip"] = str(row['HomeZip'])
                            #clinicalordertypegroupid=
                            payload_data["sex"] = str(row['Gender'])
                            payload_data["contactpreference_billing_phone"] = (row['TelephoneNumber1'])
                            payload_data["contactpreference_announcement_email"] = str(row['EmailAddress'])
                            #payload_data["ethnicitycodes"] = row['Race']
                            payload_data["contactpreference_appointment_phone"] = (row['TelephoneNumber1'])
                            payload_data["city"] = row['HomeCity']
                            payload_data["contactname"] = str(row['LastName']) + " " + str(row['FirstName'])
                            payload_data["contactmobilephone"] = (row['TelephoneNumber1'])
                            #payload_data["mobilephone"] = (row['TelephoneNumber1'])
                            payload_data["departmentid"]  = str(departmentid)
                            #payload_data["primaryproviderid"] = row['ClientProviderID']
                            payload_data["primarydepartmentid"] = str(departmentid)
                            payload_data["contacthomephone"] = (row['TelephoneNumber1'])
                            #payload_data["homephone"] = row['TelephoneNumber1']
                            payload_data["state"] = (row['HomeState'])
                            #payload_data["race"] =  row['Race']
                            payload_data["dob"] = dt #row['DateOfBirth'] # dt #data['DateOfBirth']
                            payload_data["contactpreference_appointment_email"] = (row['EmailAddress'])
                            payload_data["firstname"] = str(row['FirstName'])
                            payload_data["email"] = (row['EmailAddress'])
                            payload_data["address1"] = (row['HomeStreet1'])
                            payload_data["address2"] = row['HomeStreet2']
                            payload_data["genderidentity"] = (row['Gender']) if (row['Gender']) else ''
                            print(payload_data)
                            response_data = postEHRPatient(payload_data, practice_id) 
                            mbistatus.append(response_data)
                            
                            response_data = json.loads(response_data)
                            print("printing EHR response", response_data)
                            if "error" in response_data:
                                exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "EHR_account_creation", "status" : response_data , "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                                sqs.send_message(QueueUrl=queue_url,MessageBody=(str({"mbi" : mbi, "stage" : "EHR_account_creation", "status" : response_data , "filename" : str(row["File"]) , "captured_date" : str(current_date)})))
                                mbistatus = 'Error creating EHR Account'
                            elif  "patientid" in response_data[0]:
                                mappingData['athenaId']  = response_data[0]['patientid']
                                mappingtable.put_item(Item=mappingData)
                                print(mappingData)
        
                        else:
                            mbistatus = 'No records to be created'
                    else:
                        exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "EHR_account_creation", "status" : "Duplicate - first name last name , DOB" , "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                        sqs.send_message(QueueUrl=queue_url,MessageBody=(str({"mbi" : mbi, "stage" : "EHR_account_creation", "status" : "Duplicate - first name last name , DOB" , "filename" : str(row["File"]) , "captured_date" : str(current_date)})))
                        mbistatus = 'Error creating EHR Account'
    
            else:
                exceptiontable.put_item(Item={"mbi" : mbi, "stage" : "EHR_account_creation", "status" : "Invalid practice id" , "filename" : str(row["File"]) , "captured_date" : str(current_date)})
                        
            return mbistatus
        
        
        AccehrTag = row['AccehrTag']
        AccsfTag = row['AccsfTag']
        if row =='':
            response_status = 'Empty Message'
        else:
            print(row)
            response_status = processDataSource(row, key_list)
            print('account creation ')
            print('Printing tags' , AccehrTag , AccsfTag)
            if AccehrTag == 'EHR':
                print('executing EHR')
                response_status = createEHR(row) 
            if AccsfTag == 'SF':
                print('executing SF')
                sf = createSFDataFile(row)
                print(sf)
    
        responseObj = {}
        responseObj['statusCode'] = 200
        responseObj['headers'] = {}
        responseObj['headers']['Content-Type'] = 'application/json'
        responseObj['body'] = json.dumps(response_status)


          
    
       
      
    # TODO implement
    return responseObj

