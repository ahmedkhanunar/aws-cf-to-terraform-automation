import http.client
import jwt 
import math
from datetime import datetime
import requests
import boto3
import json
import os




def get_sf_secrets():
    secretId = os.environ["SF_SECRETS_NAME"]
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=os.environ["REGION"])
    session_token = client.get_secret_value(SecretId=secretId)
    return json.loads(session_token["SecretString"])




def generateAccessTokenSF():
    secrets = get_sf_secrets()
    claimSet = { "iss": secrets['SF_ISSUER'], "aud": "https://"+secrets['SF_HOST']+"/services/oauth2/token", "sub": secrets['SF_SUBJECT'], "exp": math.floor(int(datetime.now().timestamp()) + (3 * 600)) }
    jwtToken = jwt.encode(claimSet, secrets["SF_PRIVATE_KEY"].replace("\\n", "\n"), algorithm='RS256')
    headers = { 'Accept-Encoding': 'gzip', 'Content-Type': 'application/x-www-form-urlencoded' }
    params = { "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": jwtToken }
    response = session.post("https://"+secrets['SF_HOST']+ "/services/oauth2/token", data=params , headers=headers)
    response = response.text
    jsonResponse = json.loads(response)
    return jsonResponse['access_token']
    
data = generateAccessTokenSF()
print(data)






