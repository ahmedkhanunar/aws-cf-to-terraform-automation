process.env.SOLUTION_ID = 'SOMOCK';
process.env.SOLUTION_VERSION = 'v1.0.0';
process.env.METRICS_ANONYMOUS_UUID = 'uuid';
process.env.AWS_REGION = 'us-east-1';
process.env.IS_SECONDARY_REGION = 'No';
