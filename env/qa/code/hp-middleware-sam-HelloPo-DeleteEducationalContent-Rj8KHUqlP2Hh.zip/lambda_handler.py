import json
import boto3
import os

dynamo = boto3.resource('dynamodb')
table = dynamo.Table(os.environ.get('EducationalContentFavouritesTable'))

def lambda_handler(event, context):
    print(event.get('body'))

    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Allow': 'GET, OPTIONS, POST',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*',
    }

    try:
        key = json.loads(event.get('body', '{}'))
        table.delete_item(Key=key)
        status_code = 200
        body = { "message": "Favourite deleted successfully!" }
    except Exception as e:
        status_code = 400
        body = { "error": str(e) }

    return {
        'statusCode': status_code,
        'headers': headers,
        'body': json.dumps(body)
    }
