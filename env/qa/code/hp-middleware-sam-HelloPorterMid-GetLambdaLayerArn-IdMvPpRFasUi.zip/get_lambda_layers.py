import json
import boto3
import os
from crhelper import CfnResource

helper = CfnResource()

@helper.create
@helper.update
def sum_2_numbers(event, _):
    client = boto3.client('lambda')
    all_layers = client.list_layers()['Layers']
    
    for layer in all_layers:
        layer_name = layer['LayerName']
        layer_arn = layer['LatestMatchingVersion']['LayerVersionArn']
        print (layer_name + " == " + layer_arn)
        helper.Data[layer_name] = layer_arn

@helper.delete
def no_op(_, __):
    pass

def handler(event, context):
    helper(event, context)
