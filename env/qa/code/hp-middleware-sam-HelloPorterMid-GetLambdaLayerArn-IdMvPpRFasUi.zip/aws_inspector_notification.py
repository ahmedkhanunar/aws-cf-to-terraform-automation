import boto3
import json
import os
def lambda_handler(event, context):
   try:
       # Extract SNS message safely
       records = event.get('Records', [])
       sns_message = records[0].get('Sns', {}).get('Message') if records else None
       inspector_finding = json.loads(sns_message) if sns_message else {}
       col_pad = 50
       # Detail dictionary shortcut
       detail = inspector_finding.get('detail', {})
       # Prepare subject and body
       email_subject = f"AWS Inspector: {detail.get('title', 'No Title')}"
       email_body = detail.get('title', 'No Title') + "\n" + "=" * 35 + "\n\n"
       email_body += f"Finding ARN: {detail.get('findingArn', 'N/A')}\n\n"
       email_body += detail.get('description', 'No Description') + "\n\n"
       email_body += "Finding Overview\n" + "=" * 35 + "\n"
       email_body += f"{'Severity:'.ljust(col_pad)}{detail.get('severity', 'N/A')}\n"
       email_body += f"{'Type:'.ljust(col_pad)}{detail.get('type', 'N/A')}\n"
       email_body += f"{'Fix Available:'.ljust(col_pad)}{detail.get('fixAvailable', 'N/A')}\n"
       email_body += f"{'Exploit Available:'.ljust(col_pad)}{detail.get('exploitAvailable', 'N/A')}\n"
       if 'exploitabilityDetails' in detail:
           exploit_dt = detail.get('exploitabilityDetails', {}).get('lastKnownPublicExploitAt', '')
           email_body += f"{'Last known public exploit at:'.ljust(col_pad)}{exploit_dt}\n"
       email_body += f"{'Created at:'.ljust(col_pad)}{detail.get('firstObservedAt', 'N/A')}\n"
       # Affected packages
       email_body += "\nAffected Packages\n" + "=" * 35 + "\n"
       packages = detail.get('packageVulnerabilityDetails', {}).get('vulnerablePackages', [])
       for pkg in packages:
           email_body += f"{'**Name:'.ljust(col_pad)}{pkg.get('name', 'N/A')}\n"
           email_body += f"{'Installed Version:'.ljust(col_pad)}{pkg.get('version', 'N/A')}\n"
           email_body += f"{'Fixed Version:'.ljust(col_pad)}{pkg.get('fixedInVersion', 'N/A')}\n"
           email_body += f"{'Package Manager:'.ljust(col_pad)}{pkg.get('packageManager', 'N/A')}\n"
           email_body += f"{'Remediation:'.ljust(col_pad)}{pkg.get('remediation', 'N/A')}\n"
           if 'filePath' in pkg:
               email_body += f"{'File Path:'.ljust(col_pad)}{pkg.get('filePath')}\n"
           email_body += "\n"
       # Resources affected
       email_body += "\nResource Affected:\n" + "=" * 35 + "\n"
       for res in detail.get('resources', []):
           email_body += f"{'Type:'.ljust(col_pad)}{res.get('type', 'N/A')}\n"
           email_body += f"{'ID:'.ljust(col_pad)}{res.get('id', 'N/A')}\n"
       # Publish message to SNS
       sns = boto3.client('sns')
       response = sns.publish(
           TopicArn=os.environ.get('TOPIC_ARN', ''),
           Message=email_body,
           Subject=email_subject
       )
       print("Message published to SNS.")
       print(response)
   except Exception as e:
       print("Error:", str(e))
       # Fallback: publish raw event
       sns = boto3.client('sns')
       fallback_msg = f"Failed to parse Inspector finding. Raw event:\n{json.dumps(event, indent=4)}"
       fallback_response = sns.publish(
           TopicArn=os.environ.get('TOPIC_ARN', ''),
           Message=fallback_msg,
           Subject="AWS Inspector Finding"
       )
       print("Fallback message sent.")
       print(fallback_response)