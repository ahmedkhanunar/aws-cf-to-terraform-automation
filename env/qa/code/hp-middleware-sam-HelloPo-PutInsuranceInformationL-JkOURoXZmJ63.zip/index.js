const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "GET /account/{ultraCommerceAccountId}/care-givers":
        body = await dynamo
          .get({
            TableName: process.env.AccountTable,
            Key: {
              ultraCommerceAccountId: event.pathParameters.ultraCommerceAccountId,
              type: "CareGiver"
            }
          })
          .promise();
        break;
      case "GET /account/care-givers":
        body = await dynamo.scan({ TableName: process.env.AccountTable }).promise();
        break;
      case "POST /account/{ultraCommerceAccountId}/care-givers":
      case "PUT /account/{ultraCommerceAccountId}/care-givers":
      case "DELETE /account/{ultraCommerceAccountId}/care-givers":
        await dynamo
          .put({
            TableName: process.env.AccountTable,
            Item: {
              ultraCommerceAccountId:    event.pathParameters.ultraCommerceAccountId,
              type: "CareGiver",
              details: event.pathParameters.careGivers
            }
          })
          .promise();
        body = `Put/POST/DELETE item ${event.pathParameters.ultraCommerceAccountId}`;
        break;
        case "GET /account/{ultraCommerceAccountId}/insurance-information":
          body = await dynamo
            .get({
              TableName: process.env.AccountTable,
              Key: {
                ultraCommerceAccountId: event.pathParameters.ultraCommerceAccountId,
                type: "InsuranceInformation"
              }
            })
            .promise();
          break;
        case "GET /account/insurance-information":
          body = await dynamo.scan({ TableName: process.env.AccountTable }).promise();
          break;
        case "POST /account/{ultraCommerceAccountId}/care-givers":
        case "PUT /account/{ultraCommerceAccountId}/care-givers":
        case "DELETE /account/{ultraCommerceAccountId}/care-givers":
          await dynamo
            .put({
              TableName: process.env.AccountTable,
              Item: {
                ultraCommerceAccountId:    event.pathParameters.ultraCommerceAccountId,
                type: "InsuranceInformation",
                details: event.pathParameters.careGivers
              }
            })
            .promise();
          body = `Put/POST/DELETE item ${event.pathParameters.ultraCommerceAccountId}`;
          break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};