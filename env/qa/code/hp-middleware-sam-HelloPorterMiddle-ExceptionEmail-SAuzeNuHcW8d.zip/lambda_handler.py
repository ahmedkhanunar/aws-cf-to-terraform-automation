import json
import boto3
import os

def lambda_handler(event, context):
    env = os.environ["ENV"]
    from_email = f"ITOperations@HelloPorter.com"
    client = boto3.client('ses')
    records = event['Records']
    content = ''
    for record in records:
        content = record['body']
        content = content + get_email_body_content(content)
        
    body_html = f"""<html>
        <head></head>
        <body>
          <h2>Porter Middleware Exception</h2>
            {content}
        </body>
        </html>
                    """

    email_message = {
        'Body': {
            'Html': {
                'Charset': 'utf-8',
                'Data': body_html,
            },
        },
        'Subject': {
            'Charset': 'utf-8',
            'Data': f"{env} Middleware Exception has occurred",
        },
    }

    ses_response = client.send_email(
        Destination={
            'ToAddresses': ['ITOperations@HelloPorter.com'],
        },
        Message=email_message,
        Source=from_email,
    )
    
    return     {
        'statusCode': 200,
        'body': json.dumps(content)
    }


def get_email_body_content(message):
    return f"<br/><p>{message}</p> "